using System.Net;
using System.Net.NetworkInformation;
using System.Net.Sockets;
using System.Runtime.InteropServices;
using System.Text.Json;
using WiFiGameHub.Models;
using WiFiGameHub.Networking;
using WiFiGameHub.Services;

namespace WiFiGameHub.Forms;

public sealed class MultiplayerForm : Form
{
    private static readonly Color Canvas = Color.FromArgb(15, 16, 28);
    private static readonly Color Surface = Color.FromArgb(27, 28, 45);
    private static readonly Color Card = Color.FromArgb(21, 22, 38);
    private static readonly Color MutedText = Color.FromArgb(158, 165, 190);
    private static readonly Color Purple = Color.FromArgb(145, 92, 246);
    private static readonly Color Blue = Color.FromArgb(69, 150, 255);
    private readonly TextBox _playerName = new();
    private readonly TextBox _portText = new();
    private readonly TextBox _hostAddressText = new();
    private readonly TextBox _roomIdText = new();
    private readonly ComboBox _gameChoice = new();
    private readonly ListView _roomList = new();
    private readonly ListBox _playerList = new();
    private readonly Label _connectionStatus = new();
    private readonly Label _roomIdLabel = new();
    private readonly Button _copyRoomIdButton = new();
    private readonly Button _hostButton = new();
    private readonly Button _joinButton = new();
    private readonly Button _joinByIdButton = new();
    private readonly Button _startGameButton = new();
    private readonly Button _leaveRoomButton = new();
    private readonly Label _lobbyStateLabel = new();
    private readonly Label _roomPanelTitle = new();
    private readonly Action<string>? _openGame;
    private readonly Action? _onBack;
    private readonly System.Windows.Forms.Timer _announcementTimer = new() { Interval = 1800 };
    private readonly System.Windows.Forms.Timer _refreshTimer = new() { Interval = 1000 };
    private readonly LanRoomDirectory _discoveredRooms = new();
    private readonly MultiplayerSession _session;
    private LanDiscovery? _discovery;
    private GameRoom? _hostedRoom;
    private DateTime _discoveryStartedUtc;
    private bool _hasReceivedAnnouncement;
    private bool _closing;

    public event Action<string, string>? DiscoveryStatusChanged;

    public MultiplayerForm(MultiplayerSession? session = null, Action<string>? openGame = null, Action? onBack = null)
    {
        _session = session ?? new MultiplayerSession();
        _openGame = openGame;
        _onBack = onBack;
        Text = "Game Lobby";
        BackColor = Canvas;
        ForeColor = Color.White;
        FormBorderStyle = FormBorderStyle.None;
        Dock = DockStyle.Fill;
        Padding = new Padding(12);
        var root = new TableLayoutPanel { Dock = DockStyle.Fill, ColumnCount = 1, RowCount = 3, BackColor = BackColor, Padding = Padding.Empty };
        root.RowStyles.Add(new RowStyle(SizeType.Absolute, 72));
        root.RowStyles.Add(new RowStyle(SizeType.Absolute, 146));
        root.RowStyles.Add(new RowStyle(SizeType.Percent, 100));

        var header = new Panel { Dock = DockStyle.Fill, BackColor = Canvas };
        var backButton = new Button { Text = "←  Back", Size = new Size(78, 30), Location = new Point(0, 9), Visible = _onBack is not null };
        StyleButton(backButton, Color.FromArgb(39, 38, 58));
        backButton.Dock = DockStyle.None;
        backButton.Click += (_, _) => _onBack?.Invoke();
        header.Controls.Add(backButton);
        header.Controls.Add(new Label { Text = "MULTIPLAYER LOBBY", ForeColor = Color.White, Font = new Font("Segoe UI", 18F, FontStyle.Bold), AutoSize = true, Location = new Point(88, 0) });
        _connectionStatus.Text = "Searching for rooms...";
        _connectionStatus.ForeColor = MutedText;
        _connectionStatus.Font = new Font("Segoe UI", 8.5F);
        _connectionStatus.AutoSize = true;
        _connectionStatus.Location = new Point(90, 37);
        header.Controls.Add(_connectionStatus);
        _lobbyStateLabel.Text = "LAN ROOM DISCOVERY";
        _lobbyStateLabel.ForeColor = Blue;
        _lobbyStateLabel.Font = new Font("Segoe UI", 8F, FontStyle.Bold);
        _lobbyStateLabel.AutoSize = true;
        _lobbyStateLabel.Anchor = AnchorStyles.Top | AnchorStyles.Right;
        _lobbyStateLabel.Location = new Point(Width - 360, 12);
        header.Controls.Add(_lobbyStateLabel);
        _roomIdLabel.Text = string.Empty;
        _roomIdLabel.ForeColor = Color.FromArgb(220, 218, 241);
        _roomIdLabel.Font = new Font("Segoe UI", 9F, FontStyle.Bold);
        _roomIdLabel.AutoSize = true;
        _roomIdLabel.Anchor = AnchorStyles.Top | AnchorStyles.Right;
        _roomIdLabel.Location = new Point(Width - 360, 40);
        _roomIdLabel.Visible = false;
        header.Controls.Add(_roomIdLabel);
        _copyRoomIdButton.Text = "Copy ID";
        StyleButton(_copyRoomIdButton, Color.FromArgb(48, 42, 69));
        _copyRoomIdButton.Dock = DockStyle.None;
        _copyRoomIdButton.Size = new Size(78, 28);
        _copyRoomIdButton.Anchor = AnchorStyles.Top | AnchorStyles.Right;
        _copyRoomIdButton.Location = new Point(Width - 104, 8);
        _copyRoomIdButton.Visible = false;
        _copyRoomIdButton.Click += (_, _) => CopyRoomId();
        header.Controls.Add(_copyRoomIdButton);
        header.Resize += (_, _) =>
        {
            _lobbyStateLabel.Left = Math.Max(220, header.ClientSize.Width - _lobbyStateLabel.Width - 100);
            _roomIdLabel.Left = Math.Max(220, header.ClientSize.Width - _roomIdLabel.Width - 100);
            _copyRoomIdButton.Left = header.ClientSize.Width - _copyRoomIdButton.Width;
        };

        var toolbar = new TableLayoutPanel { Dock = DockStyle.Fill, ColumnCount = 5, RowCount = 3, BackColor = Surface, Padding = new Padding(12), Margin = new Padding(0, 0, 0, 12) };
        toolbar.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 26));
        toolbar.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 20));
        toolbar.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 16));
        toolbar.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 19));
        toolbar.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 19));
        toolbar.RowStyles.Add(new RowStyle(SizeType.Absolute, 24));
        toolbar.RowStyles.Add(new RowStyle(SizeType.Absolute, 34));
        toolbar.RowStyles.Add(new RowStyle(SizeType.Absolute, 34));
        toolbar.Controls.Add(CreateFieldLabel("PLAYER NAME"), 0, 0);
        toolbar.Controls.Add(CreateFieldLabel("GAME"), 1, 0);
        toolbar.Controls.Add(CreateFieldLabel("HOST PORT"), 2, 0);
        toolbar.Controls.Add(CreateFieldLabel("HOST ADDRESS"), 3, 0);
        toolbar.Controls.Add(CreateFieldLabel("ROOM ID"), 4, 0);
        _playerName.Text = AppPreferences.Current.PlayerName;
        StyleTextBox(_playerName);
        toolbar.Controls.Add(_playerName, 0, 1);
        _gameChoice.DropDownStyle = ComboBoxStyle.DropDownList;
        _gameChoice.Items.AddRange(new object[] { "Tic Tac Toe", "Ludo", "Chess", "Chat Only", "Carrom" });
        _gameChoice.SelectedIndex = 0;
        StyleCombo(_gameChoice);
        toolbar.Controls.Add(_gameChoice, 1, 1);
        _portText.Text = AppPreferences.Current.NetworkPort.ToString();
        StyleTextBox(_portText);
        toolbar.Controls.Add(_portText, 2, 1);
        StyleTextBox(_hostAddressText);
        _hostAddressText.PlaceholderText = "e.g. 192.168.1.10";
        toolbar.Controls.Add(_hostAddressText, 3, 1);
        StyleTextBox(_roomIdText);
        _roomIdText.PlaceholderText = "Paste room ID";
        toolbar.Controls.Add(_roomIdText, 4, 1);
        _hostButton.Text = "Create Room";
        StyleButton(_hostButton, Purple);
        _hostButton.Click += async (_, _) => await ToggleHostAsync();
        toolbar.Controls.Add(_hostButton, 3, 2);
        _joinButton.Text = "Join Selected Room";
        StyleButton(_joinButton, Blue);
        _joinButton.Click += async (_, _) => await JoinSelectedRoomAsync();
        toolbar.Controls.Add(_joinButton, 4, 2);
        _joinByIdButton.Text = "Join by ID";
        StyleButton(_joinByIdButton, Blue);
        _joinByIdButton.Click += async (_, _) => await JoinByIdAsync();
        toolbar.Controls.Add(_joinByIdButton, 0, 2);
        toolbar.SetColumnSpan(_joinByIdButton, 3);

        var content = new TableLayoutPanel { Dock = DockStyle.Fill, ColumnCount = 2, RowCount = 1, BackColor = BackColor };
        content.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 59));
        content.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 41));
        _roomList.Dock = DockStyle.Fill;
        _roomList.View = View.Details;
        _roomList.FullRowSelect = true;
        _roomList.MultiSelect = false;
        _roomList.HideSelection = false;
        _roomList.BorderStyle = BorderStyle.None;
        _roomList.BackColor = Card;
        _roomList.ForeColor = Color.FromArgb(230, 231, 244);
        _roomList.Font = new Font("Segoe UI", 9F);
        _roomList.Columns.Add("HOST PLAYER", 180);
        _roomList.Columns.Add("GAME", 130);
        _roomList.Columns.Add("OPEN SLOTS", 100);
        _roomList.Columns.Add("STATUS", 110);
        _roomList.Resize += (_, _) => ResizeRoomColumns();
        _playerList.Dock = DockStyle.Fill;
        StyleList(_playerList);
        _playerList.DrawMode = DrawMode.OwnerDrawFixed;
        _playerList.ItemHeight = 38;
        _playerList.DrawItem += PlayerList_DrawItem;
        var rosterPanel = CreatePlayerLobbyPanel();
        _gameChoice.SelectedIndexChanged += (_, _) =>
        {
            if (!_session.IsActive)
            {
                _roomPanelTitle.Text = $"ROOM LOBBY  ·  {_gameChoice.SelectedItem?.ToString()?.ToUpperInvariant()}";
                RefreshLobbyControls();
                UpdateJoinButton();
            }
        };
        var roomsPanel = CreateListPanel("AVAILABLE ROOMS  ·  Select a room to join", _roomList);
        roomsPanel.Margin = new Padding(0, 0, 10, 0);
        content.Controls.Add(roomsPanel, 0, 0);
        content.Controls.Add(rosterPanel, 1, 0);
        root.Controls.Add(header, 0, 0);
        root.Controls.Add(toolbar, 0, 1);
        root.Controls.Add(content, 0, 2);
        Controls.Add(root);

        _roomList.SelectedIndexChanged += (_, _) => UpdateJoinButton();
        _announcementTimer.Tick += (_, _) => BroadcastHostedRoom();
        Load += (_, _) => StartDiscovery();
        _refreshTimer.Tick += (_, _) => RefreshRoomList();
        VisibleChanged += (_, _) =>
        {
            if (Visible && _discovery is not null)
            {
                _refreshTimer.Start();
                RefreshRoomList();
            }
            else
            {
                _refreshTimer.Stop();
            }
        };
        _joinButton.Enabled = false;
        _session.StateChanged += Session_StateChanged;
        _session.StatusChanged += Session_StatusChanged;
        _session.ConnectionChanged += Session_ConnectionChanged;
        Disposed += (_, _) => Cleanup();
        if (_session.CurrentState is { } currentState)
        {
            RefreshRoomSessionState(currentState);
            UpdateRoomId();
        }
        RefreshLobbyControls();
    }

    private void StartDiscovery()
    {
        try
        {
            _discovery = new LanDiscovery();
            _discovery.RoomDiscovered += HandleRoomDiscovered;
            _discovery.StartListening();
            _discoveryStartedUtc = DateTime.UtcNow;
            _refreshTimer.Start();
            _connectionStatus.Text = "Searching for rooms...";
            _lobbyStateLabel.Text = "SEARCHING FOR ROOMS";
            DiscoveryStatusChanged?.Invoke("Searching", "LAN discovery is active");
        }
        catch (SocketException exception)
        {
            _connectionStatus.Text = $"Connection failed: LAN discovery unavailable. Check UDP 45455 firewall access and router client isolation. ({exception.Message})";
            _lobbyStateLabel.Text = "DISCOVERY UNAVAILABLE";
            DiscoveryStatusChanged?.Invoke("Unavailable", "LAN discovery could not start");
        }
    }

    public void SelectGame(string game)
    {
        var displayName = game switch
        {
            "TicTacToe" or "Tic Tac Toe" => "Tic Tac Toe",
            "Chat" or "Chat Only" => "Chat Only",
            "Chess" => "Chess",
            "Ludo" => "Ludo",
            "Carrom" => "Carrom",
            _ => throw new ArgumentException("Choose Chess, Ludo, Tic Tac Toe, Carrom, or Chat Only.", nameof(game))
        };

        if (_session.IsActive)
        {
            var sessionGame = displayName switch { "Tic Tac Toe" => "TicTacToe", "Chat Only" => "Chat", _ => displayName };
            _connectionStatus.Text = _session.Game == sessionGame
                ? $"Connected to the {_session.Game} room."
                : "Disconnect from the current room before selecting another game.";
            return;
        }

        _gameChoice.SelectedItem = displayName;
        _roomPanelTitle.Text = $"ROOM LOBBY  ·  {displayName.ToUpperInvariant()}";
    }

    private async Task JoinByIdAsync()
    {
        if (_session.IsActive && !_session.IsHost)
        {
            _session.Disconnect();
            _joinByIdButton.Text = "Join by ID";
            _connectionStatus.Text = "Disconnected from room.";
            _playerList.Items.Clear();
            UpdateRoomId();
            RefreshLobbyControls();
            return;
        }
        if (_session.IsHost)
        {
            _connectionStatus.Text = "Close your hosted room before joining another room.";
            return;
        }
        var host = _hostAddressText.Text.Trim();
        var roomId = _roomIdText.Text.Trim();
        if (string.IsNullOrWhiteSpace(host) || host.Length > 255)
        {
            _connectionStatus.Text = "Enter the host computer's IP address or name.";
            return;
        }
        if (string.IsNullOrWhiteSpace(roomId) || roomId.Length > 64)
        {
            _connectionStatus.Text = "Enter a valid room ID (1–64 characters).";
            return;
        }
        if (!int.TryParse(_portText.Text, out var port) || port is < 1 or > 65535)
        {
            _connectionStatus.Text = "Enter a valid host port from 1 to 65535.";
            return;
        }
        var playerName = _playerName.Text.Trim();
        if (string.IsNullOrWhiteSpace(playerName) || playerName.Length > 32)
        {
            _connectionStatus.Text = "Enter a player name (1–32 characters).";
            return;
        }

        var selectedGame = _gameChoice.SelectedItem?.ToString() ?? "Tic Tac Toe";
        var game = selectedGame switch { "Ludo" => "Ludo", "Chess" => "Chess", "Carrom" => "Carrom", "Chat Only" => "Chat", _ => "TicTacToe" };
        _joinByIdButton.Enabled = false;
        _connectionStatus.Text = "Connecting to room...";
        try
        {
            await _session.JoinAsync(host, port, roomId, game, playerName);
            _joinByIdButton.Text = "Disconnect";
            UpdateRoomId();
        }
        catch (Exception exception) when (exception is SocketException or IOException or InvalidOperationException or OperationCanceledException or ArgumentException)
        {
            _connectionStatus.Text = $"Could not join room: {exception.Message}";
        }
        finally
        {
            _joinByIdButton.Enabled = true;
        }
    }

    private void CopyRoomId()
    {
        if (!_session.IsActive || string.IsNullOrWhiteSpace(_session.RoomId))
        {
            _connectionStatus.Text = "Create or join a room before copying its ID.";
            return;
        }

        try
        {
            Clipboard.SetText(_session.RoomId);
            _connectionStatus.Text = "Room ID copied to clipboard.";
        }
        catch (ExternalException exception)
        {
            _connectionStatus.Text = $"Could not copy room ID: {exception.Message}";
        }
    }

    private void UpdateRoomId()
    {
        var hasRoom = _session.IsActive && !string.IsNullOrWhiteSpace(_session.RoomId);
        _roomIdLabel.Text = hasRoom ? $"Room ID  {_session.RoomId}" : string.Empty;
        _roomIdLabel.Visible = hasRoom;
        _copyRoomIdButton.Visible = hasRoom;
        _copyRoomIdButton.Enabled = hasRoom;
        RefreshLobbyControls();
    }

    private Panel CreatePlayerLobbyPanel()
    {
        var panel = new TableLayoutPanel
        {
            Dock = DockStyle.Fill,
            ColumnCount = 1,
            RowCount = 3,
            BackColor = Surface,
            Padding = new Padding(12),
            Margin = Padding.Empty
        };
        panel.RowStyles.Add(new RowStyle(SizeType.Absolute, 26));
        panel.RowStyles.Add(new RowStyle(SizeType.Percent, 100));
        panel.RowStyles.Add(new RowStyle(SizeType.Absolute, 68));

        _roomPanelTitle.Text = $"ROOM LOBBY  ·  {_gameChoice.SelectedItem?.ToString()?.ToUpperInvariant() ?? "TIC TAC TOE"}";
        _roomPanelTitle.Dock = DockStyle.Fill;
        _roomPanelTitle.ForeColor = Color.FromArgb(220, 218, 241);
        _roomPanelTitle.Font = new Font("Segoe UI", 8.5F, FontStyle.Bold);
        _roomPanelTitle.TextAlign = ContentAlignment.MiddleLeft;
        var title = _roomPanelTitle;
        var tabs = new TabControl
        {
            Dock = DockStyle.Fill,
            Font = new Font("Segoe UI", 8.5F, FontStyle.Bold),
            Padding = new Point(9, 4),
            DrawMode = TabDrawMode.OwnerDrawFixed,
            SizeMode = TabSizeMode.Fixed,
            ItemSize = new Size(74, 25)
        };
        tabs.DrawItem += (_, eventArgs) => DrawLobbyTab(tabs, eventArgs);
        var playersPage = new TabPage("Players") { BackColor = Card, Padding = new Padding(6) };
        _playerList.BackColor = Card;
        playersPage.Controls.Add(_playerList);
        var chatPage = new TabPage("Chat") { BackColor = Card, Padding = new Padding(2) };
        chatPage.Controls.Add(new GameChatPanel(_session));
        tabs.TabPages.Add(playersPage);
        tabs.TabPages.Add(chatPage);

        var actions = new TableLayoutPanel
        {
            Dock = DockStyle.Fill,
            ColumnCount = 2,
            RowCount = 1,
            BackColor = Surface,
            Padding = new Padding(0, 5, 0, 0)
        };
        actions.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 58));
        actions.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 42));
        _startGameButton.Text = "Start Game";
        StyleButton(_startGameButton, Purple);
        _startGameButton.Enabled = false;
        _startGameButton.Click += (_, _) => OpenRoomGame();
        _leaveRoomButton.Text = "Leave Room";
        StyleButton(_leaveRoomButton, Color.FromArgb(48, 42, 69));
        _leaveRoomButton.Enabled = false;
        _leaveRoomButton.Click += (_, _) => LeaveRoom();
        actions.Controls.Add(_startGameButton, 0, 0);
        actions.Controls.Add(_leaveRoomButton, 1, 0);

        panel.Controls.Add(title, 0, 0);
        panel.Controls.Add(tabs, 0, 1);
        panel.Controls.Add(actions, 0, 2);
        return panel;
    }

    private void RefreshLobbyControls()
    {
        var state = _session.IsActive ? _session.CurrentState : null;
        var connectedPlayers = state?.Players.Count(player => player.Connected) ?? 0;
        var hasRoom = _session.IsActive && state is not null;
        _hostButton.Enabled = true;
        _joinByIdButton.Enabled = true;
        var displayGame = _session.IsActive
            ? GetDisplayGame(_session.Game)
            : _gameChoice.SelectedItem?.ToString() ?? "Tic Tac Toe";
        _roomPanelTitle.Text = $"ROOM LOBBY  ·  {displayGame.ToUpperInvariant()}";
        _leaveRoomButton.Enabled = hasRoom;
        _leaveRoomButton.Visible = hasRoom;
        _leaveRoomButton.Text = _session.IsHost ? "Close Room" : "Leave Room";
        _startGameButton.Visible = hasRoom && _session.Game != "Chat";
        if (!hasRoom || _session.Game == "Chat")
        {
            _startGameButton.Enabled = false;
            _startGameButton.Text = "Start Game";
            _lobbyStateLabel.Text = _session.IsActive ? "ROOM CONNECTED" : "LAN ROOM DISCOVERY";
            _lobbyStateLabel.ForeColor = _session.IsActive ? Color.FromArgb(77, 194, 143) : Blue;
            return;
        }

        var enoughPlayers = connectedPlayers >= 2;
        _startGameButton.Text = _session.IsHost ? "Start Game" : "Open Game";
        _startGameButton.Enabled = _session.IsHost ? enoughPlayers : state!.Started;
        _lobbyStateLabel.Text = state!.Started ? "GAME IN PROGRESS" : enoughPlayers ? "PLAYERS CONNECTED" : "WAITING FOR PLAYERS";
        _lobbyStateLabel.ForeColor = state.Started || enoughPlayers
            ? Color.FromArgb(77, 194, 143)
            : Color.FromArgb(244, 190, 62);
    }

    private void OpenRoomGame()
    {
        if (!_session.IsActive || _session.CurrentState is not { } state || _session.Game == "Chat")
        {
            _connectionStatus.Text = "Create or join a game room first.";
            return;
        }

        if (_session.IsHost && state.Players.Count(player => player.Connected) < 2)
        {
            _connectionStatus.Text = "Waiting for another connected player before starting.";
            return;
        }
        if (!_session.IsHost && !state.Started)
        {
            _connectionStatus.Text = "Waiting for the host to start the game.";
            return;
        }
        if (_openGame is null)
        {
            _connectionStatus.Text = "Game navigation is unavailable in this lobby.";
            return;
        }

        _openGame(_session.Game);
    }

    private static string GetDisplayGame(string game) => game switch
    {
        "TicTacToe" => "Tic Tac Toe",
        "Chat" => "Chat Only",
        _ => game
    };

    private void LeaveRoom()
    {
        if (!_session.IsActive)
        {
            return;
        }

        if (_session.IsHost)
        {
            CleanupHost();
            _hostButton.Text = "Create Room";
            _connectionStatus.Text = "Hosted room closed.";
        }
        else
        {
            _session.Disconnect();
            _joinButton.Text = "Join Selected Room";
            _joinByIdButton.Text = "Join by ID";
            _connectionStatus.Text = "You left the room.";
        }
        _playerList.Items.Clear();
        UpdateRoomId();
        RefreshLobbyControls();
    }

    private void PlayerList_DrawItem(object? sender, DrawItemEventArgs e)
    {
        if (e.Index < 0 || e.Index >= _playerList.Items.Count)
        {
            return;
        }

        var selected = (e.State & DrawItemState.Selected) == DrawItemState.Selected;
        using var background = new SolidBrush(selected ? Color.FromArgb(43, 36, 61) : Card);
        e.Graphics.FillRectangle(background, e.Bounds);
        using var marker = new SolidBrush(selected ? Purple : Blue);
        e.Graphics.FillEllipse(marker, e.Bounds.X + 11, e.Bounds.Y + (e.Bounds.Height - 8) / 2, 8, 8);
        using var textBrush = new SolidBrush(Color.FromArgb(230, 231, 244));
        using var font = new Font("Segoe UI", 9F, FontStyle.Bold);
        using var format = new StringFormat { LineAlignment = StringAlignment.Center, Trimming = StringTrimming.EllipsisCharacter };
        var text = _playerList.Items[e.Index]?.ToString() ?? string.Empty;
        e.Graphics.DrawString(text, font, textBrush,
            new RectangleF(e.Bounds.X + 28, e.Bounds.Y, Math.Max(0, e.Bounds.Width - 34), e.Bounds.Height),
            format);
        e.DrawFocusRectangle();
    }

    private static void DrawLobbyTab(TabControl tabs, DrawItemEventArgs e)
    {
        if (e.Index < 0 || e.Index >= tabs.TabPages.Count)
        {
            return;
        }

        var selected = tabs.SelectedIndex == e.Index;
        using var background = new SolidBrush(selected ? Color.FromArgb(60, 45, 93) : Surface);
        using var textBrush = new SolidBrush(selected ? Color.White : MutedText);
        using var font = new Font("Segoe UI", 8F, FontStyle.Bold);
        using var format = new StringFormat { Alignment = StringAlignment.Center, LineAlignment = StringAlignment.Center };
        e.Graphics.FillRectangle(background, e.Bounds);
        e.Graphics.DrawString(tabs.TabPages[e.Index].Text, font, textBrush, e.Bounds, format);
    }

    private async Task ToggleHostAsync()
    {
        if (_session.IsHost)
        {
            CleanupHost();
            _hostButton.Text = "Create Room";
            _connectionStatus.Text = "Hosted room closed.";
            return;
        }
        if (!int.TryParse(_portText.Text, out var port) || port is < 1 or > 65535)
        {
            _connectionStatus.Text = "Enter a valid TCP port from 1 to 65535.";
            return;
        }

        var playerName = _playerName.Text.Trim();
        if (string.IsNullOrWhiteSpace(playerName))
        {
            _connectionStatus.Text = "Enter a player name before creating a room.";
            return;
        }

        var gameName = _gameChoice.SelectedItem?.ToString() ?? "Tic Tac Toe";
        var game = gameName switch { "Ludo" => "Ludo", "Chess" => "Chess", "Carrom" => "Carrom", "Chat Only" => "Chat", _ => "TicTacToe" };
        var gameType = game switch { "Ludo" => GameType.Ludo, "Chess" => GameType.Chess, "Carrom" => GameType.Carrom, "Chat" => GameType.Chat, _ => GameType.TicTacToe };

        try
        {
            _session.StartHost(game, port, playerName);
            _hostedRoom = new GameRoom(game == "Chat" ? "Chat Only" : $"{gameName} Room", gameType)
            {
                Id = _session.RoomId,
                HostIp = GetLocalIPv4Address(),
                Port = port
            };
            _hostedRoom.AddPlayer(new Player(playerName, isHost: true) { Id = _session.LocalPlayerId, ConnectionIp = _hostedRoom.HostIp });
            if (_discovery is null)
            {
                StartDiscovery();
            }
            _hostButton.Text = "Close Room";
            _connectionStatus.Text = $"Hosting {_hostedRoom.Name}. Allow TCP port {port} through Windows Firewall for other PCs.";
            UpdateRoomId();
            _announcementTimer.Start();
            BroadcastHostedRoom();
            UpdateHostedPlayerList();
        }
        catch (SocketException exception)
        {
            _hostedRoom = null;
            _connectionStatus.Text = $"Could not host on port {port}: {exception.Message}";
        }
        catch (InvalidOperationException exception)
        {
            _hostedRoom = null;
            _connectionStatus.Text = $"Could not host: {exception.Message}";
        }
        await Task.CompletedTask;
    }

    private async Task JoinSelectedRoomAsync()
    {
        if (_session.IsActive && !_session.IsHost)
        {
            _session.Disconnect();
            _joinButton.Text = "Join Room";
            _connectionStatus.Text = "Disconnected from room.";
            _playerList.Items.Clear();
            UpdateRoomId();
            RefreshLobbyControls();
            return;
        }

        if (_roomList.SelectedItems.Count == 0 || _roomList.SelectedItems[0].Tag is not LanRoomAnnouncement room)
        {
            _connectionStatus.Text = _discoveredRooms.Count == 0 ? "No rooms found." : "Select a room to join.";
            return;
        }

        var name = _playerName.Text.Trim();
        if (string.IsNullOrWhiteSpace(name))
        {
            _connectionStatus.Text = "Enter a player name before joining.";
            return;
        }

        _joinButton.Enabled = false;
        _connectionStatus.Text = "Joining room...";
        try
        {
            await _session.JoinAsync(room.HostIp, room.Port, room.RoomId, room.Game, name);
            _connectionStatus.Text = "Joining room...";
            UpdateRoomId();
        }
        catch (Exception exception) when (exception is SocketException or IOException or InvalidOperationException or OperationCanceledException)
        {
            _connectionStatus.Text = $"Connection failed: {exception.Message}";
        }
        finally
        {
            _joinButton.Enabled = true;
        }
    }

    private void HandleRoomDiscovered(LanRoomAnnouncement announcement)
    {
        if (_hostedRoom?.Id == announcement.RoomId)
        {
            return;
        }

        PostToUi(() =>
        {
            _hasReceivedAnnouncement = true;
            _discoveredRooms.Upsert(announcement);
            RefreshRoomList();
        });
    }

    private void RefreshRoomList()
    {
        var rooms = _discoveredRooms.RemoveExpired();

        var selectedId = _roomList.SelectedItems.Count > 0 ? (_roomList.SelectedItems[0].Tag as LanRoomAnnouncement)?.RoomId : null;
        _roomList.BeginUpdate();
        _roomList.Items.Clear();
        foreach (var room in rooms.OrderBy(room => room.RoomName))
        {
            var openSlots = Math.Max(0, room.MaxPlayers - room.CurrentPlayers);
            var status = openSlots == 0 ? "Full" : room.Status;
            var item = new ListViewItem(room.HostName);
            item.SubItems.Add(room.Game switch { "Ludo" => "Ludo", "Chess" => "Chess", "Carrom" => "Carrom", "Chat" => "Chat Only", _ => "Tic Tac Toe" });
            item.SubItems.Add(openSlots.ToString());
            item.SubItems.Add(status);
            item.Tag = room;
            _roomList.Items.Add(item);
            if (room.RoomId == selectedId)
            {
                item.Selected = true;
            }
        }
        _roomList.EndUpdate();
        if (!_session.IsActive && selectedId is null)
        {
            _playerList.Items.Clear();
        }
        if (!_session.IsActive)
        {
            _connectionStatus.Text = rooms.Count > 0
                ? "Room found."
                : _hasReceivedAnnouncement || DateTime.UtcNow - _discoveryStartedUtc >= TimeSpan.FromSeconds(4)
                    ? "No rooms found. Check same Wi-Fi, UDP 45455 firewall access, and router client isolation."
                    : "Searching for rooms...";
            _lobbyStateLabel.Text = rooms.Count > 0
                ? "ROOMS AVAILABLE"
                : _hasReceivedAnnouncement || DateTime.UtcNow - _discoveryStartedUtc >= TimeSpan.FromSeconds(4)
                    ? "NO ROOMS FOUND"
                    : "SEARCHING FOR ROOMS";
            _lobbyStateLabel.ForeColor = rooms.Count > 0
                ? Color.FromArgb(77, 194, 143)
                : MutedText;
        }
        DiscoveryStatusChanged?.Invoke(
            rooms.Count > 0 ? $"{rooms.Count} found" : _hasReceivedAnnouncement || DateTime.UtcNow - _discoveryStartedUtc >= TimeSpan.FromSeconds(4) ? "No rooms found" : "Searching",
            rooms.Count > 0 ? "Available on your local network" : _hasReceivedAnnouncement || DateTime.UtcNow - _discoveryStartedUtc >= TimeSpan.FromSeconds(4) ? "Check that friends are on the same Wi-Fi" : "Looking for LAN rooms");
        UpdateJoinButton();
        ResizeRoomColumns();
    }

    private void UpdateJoinButton()
    {
        var connectedAsClient = _session.IsActive && !_session.IsHost;
        var selectedRoom = _roomList.SelectedItems.Count > 0 ? _roomList.SelectedItems[0].Tag as LanRoomAnnouncement : null;
        var roomHasSpace = selectedRoom is not null && selectedRoom.CurrentPlayers < selectedRoom.MaxPlayers;
        _joinButton.Text = connectedAsClient ? "Leave Room" : selectedRoom is not null && !roomHasSpace ? "Room Full" : "Join Selected Room";
        _joinButton.Enabled = connectedAsClient || roomHasSpace;
        if (_roomList.SelectedItems.Count > 0 && _roomList.SelectedItems[0].Tag is LanRoomAnnouncement room)
        {
            if (!_session.IsActive)
            {
                _hostAddressText.Text = room.HostIp;
                _roomIdText.Text = room.RoomId;
                _gameChoice.SelectedItem = room.Game switch
                {
                    "Ludo" => "Ludo",
                    "Chess" => "Chess",
                    "Carrom" => "Carrom",
                    "Chat" => "Chat Only",
                    _ => "Tic Tac Toe"
                };
                _roomPanelTitle.Text = $"ROOM LOBBY  ·  {_gameChoice.SelectedItem?.ToString()?.ToUpperInvariant()}";
                _playerList.Items.Clear();
                _playerList.Items.Add($"HOST  ·  {room.HostName}  ·  CONNECTED");
                _playerList.Items.Add($"ROOM  ·  {room.RoomName}");
                _playerList.Items.Add($"PLAYERS  ·  {room.CurrentPlayers}/{room.MaxPlayers}");
            }
        }
    }

    private void ResizeRoomColumns()
    {
        if (_roomList.Columns.Count != 4 || _roomList.ClientSize.Width <= 0)
        {
            return;
        }

        var availableWidth = Math.Max(0, _roomList.ClientSize.Width - SystemInformation.VerticalScrollBarWidth);
        _roomList.Columns[0].Width = (int)(availableWidth * 0.34);
        _roomList.Columns[1].Width = (int)(availableWidth * 0.27);
        _roomList.Columns[2].Width = (int)(availableWidth * 0.19);
        _roomList.Columns[3].Width = availableWidth - _roomList.Columns[0].Width - _roomList.Columns[1].Width - _roomList.Columns[2].Width;
    }

    private void BroadcastHostedRoom()
    {
        if (_hostedRoom is null || _discovery is null || !_session.IsHost || _session.CurrentState is null)
        {
            return;
        }

        try
        {
            _discovery.BroadcastHost(new LanRoomAnnouncement
            {
                RoomId = _hostedRoom.Id,
                RoomName = _hostedRoom.Name,
                Game = _hostedRoom.GameType switch
                {
                    GameType.Ludo => "Ludo",
                    GameType.Chess => "Chess",
                    GameType.Carrom => "Carrom",
                    GameType.Chat => "Chat",
                    _ => "TicTacToe"
                },
                HostName = _hostedRoom.Players.FirstOrDefault(player => player.IsHost)?.Name ?? "Host",
                HostIp = _hostedRoom.HostIp,
                Port = _hostedRoom.Port,
                CurrentPlayers = _session.CurrentState.Players.Count,
                MaxPlayers = _hostedRoom.MaxPlayers,
                Status = _session.CurrentState.Started ? "In game" : _hostedRoom.Status
            });
        }
        catch (SocketException exception)
        {
            _connectionStatus.Text = $"Room is hosted, but discovery broadcast failed: {exception.Message}";
        }
    }

    private void UpdateHostedPlayerList()
    {
        if (_hostedRoom is null || _session.CurrentState is null)
        {
            return;
        }

        _playerList.Items.Clear();
        foreach (var player in _session.CurrentState.Players)
        {
            var role = player.PlayerId == _session.LocalPlayerId ? "HOST" : "PLAYER";
            var status = player.Connected ? "CONNECTED" : "DISCONNECTED";
            _playerList.Items.Add($"{role}  ·  {player.Name}  ·  {status}");
        }
        _hostedRoom.Status = _session.CurrentState.Players.Count >= _hostedRoom.MaxPlayers ? "Full" : "Waiting";
    }

    private void Session_StateChanged(GameSessionState state)
    {
        PostToUi(() =>
        {
            if (state.RoomId != _session.RoomId)
            {
                return;
            }
            RefreshRoomSessionState(state);
            if (_session.IsHost)
            {
                BroadcastHostedRoom();
            }
            UpdateRoomId();
            RefreshLobbyControls();
        });
    }

    private void RefreshRoomSessionState(GameSessionState state)
    {
        _playerList.Items.Clear();
        var hostId = state.Players.FirstOrDefault()?.PlayerId;
        foreach (var player in state.Players)
        {
            var role = player.PlayerId == hostId ? "HOST" : "PLAYER";
            var gameRole = string.Join(" ", new[] { player.Mark, player.Color }.Where(value => !string.IsNullOrWhiteSpace(value)));
            var gameRoleText = string.IsNullOrWhiteSpace(gameRole) ? string.Empty : $"  ·  {gameRole}";
            var connection = player.Connected ? "CONNECTED" : "DISCONNECTED";
            _playerList.Items.Add($"{role}  ·  {player.Name}{gameRoleText}  ·  {connection}");
        }

        if (_hostedRoom is not null)
        {
            _hostedRoom.Status = state.Players.Count(player => player.Connected) >= _hostedRoom.MaxPlayers ? "Full" : "Waiting";
        }
    }

    private void Session_StatusChanged(string message)
    {
        PostToUi(() =>
        {
            _connectionStatus.Text = message;
            RefreshLobbyControls();
        });
    }

    private void Session_ConnectionChanged(bool connected)
    {
        PostToUi(() =>
        {
            _joinButton.Text = connected && !_session.IsHost ? "Leave Room" : "Join Selected Room";
            _joinByIdButton.Text = connected && !_session.IsHost ? "Leave Room" : "Join by ID";
            if (!connected && !_session.IsHost)
            {
                _playerList.Items.Clear();
            }
            UpdateRoomId();
            RefreshLobbyControls();
        });
    }

    private void CleanupHost()
    {
        _announcementTimer.Stop();
        if (_session.IsHost)
        {
            _session.Disconnect();
        }
        _hostedRoom = null;
        _playerList.Items.Clear();
        UpdateRoomId();
    }

    private void Cleanup()
    {
        if (_closing)
        {
            return;
        }
        _closing = true;
        _announcementTimer.Stop();
        _refreshTimer.Stop();
        _discovery?.Dispose();
        _discovery = null;
        if (_session.IsHost || _session.IsActive)
        {
            _session.Disconnect();
        }
        _session.StateChanged -= Session_StateChanged;
        _session.StatusChanged -= Session_StatusChanged;
        _session.ConnectionChanged -= Session_ConnectionChanged;
        _hostedRoom = null;
        _announcementTimer.Dispose();
        _refreshTimer.Dispose();
    }

    private void PostToUi(Action action)
    {
        if (_closing || IsDisposed || !IsHandleCreated)
        {
            return;
        }
        if (InvokeRequired)
        {
            BeginInvoke(action);
        }
        else
        {
            action();
        }
    }

    private static string GetLocalIPv4Address()
    {
        return NetworkInterface.GetAllNetworkInterfaces()
            .Where(network => network.OperationalStatus == OperationalStatus.Up)
            .SelectMany(network => network.GetIPProperties().UnicastAddresses)
            .Select(address => address.Address)
            .FirstOrDefault(address => address.AddressFamily == AddressFamily.InterNetwork && !IPAddress.IsLoopback(address))?.ToString()
            ?? IPAddress.Loopback.ToString();
    }

    private static Panel CreateListPanel(string title, Control list)
    {
        var panel = new Panel { Dock = DockStyle.Fill, BackColor = Surface, Padding = new Padding(12), Margin = new Padding(0, 0, 12, 0) };
        var label = new Label { Text = title, ForeColor = Color.FromArgb(220, 218, 241), Font = new Font("Segoe UI", 8.5F, FontStyle.Bold), AutoSize = true, Dock = DockStyle.Top, Height = 27 };
        list.Dock = DockStyle.Fill;
        panel.Controls.Add(list);
        panel.Controls.Add(label);
        return panel;
    }

    private static Label CreateFieldLabel(string text) => new() { Text = text, ForeColor = MutedText, Font = new Font("Segoe UI", 7.5F, FontStyle.Bold), AutoSize = true, Dock = DockStyle.Fill, TextAlign = ContentAlignment.MiddleLeft };

    private static void StyleTextBox(TextBox textBox)
    {
        textBox.BackColor = Card;
        textBox.ForeColor = Color.FromArgb(235, 236, 247);
        textBox.Font = new Font("Segoe UI", 9F);
        textBox.BorderStyle = BorderStyle.FixedSingle;
        textBox.Dock = DockStyle.Fill;
        textBox.Margin = new Padding(2);
    }

    private static void StyleCombo(ComboBox comboBox)
    {
        comboBox.BackColor = Card;
        comboBox.ForeColor = Color.White;
        comboBox.Font = new Font("Segoe UI", 9F);
        comboBox.Dock = DockStyle.Fill;
        comboBox.Margin = new Padding(2);
    }

    private static void StyleButton(Button button, Color color)
    {
        button.BackColor = color;
        button.ForeColor = Color.White;
        button.FlatStyle = FlatStyle.Flat;
        button.FlatAppearance.BorderSize = 0;
        button.FlatAppearance.MouseOverBackColor = ControlPaint.Light(color, 0.1f);
        button.FlatAppearance.MouseDownBackColor = ControlPaint.Dark(color, 0.08f);
        button.Font = new Font("Segoe UI", 8.5F, FontStyle.Bold);
        button.Dock = DockStyle.Fill;
        button.Margin = new Padding(3, 1, 3, 1);
    }

    private static void StyleList(ListBox list)
    {
        list.BackColor = Card;
        list.ForeColor = Color.FromArgb(230, 231, 244);
        list.Font = new Font("Segoe UI", 9F);
        list.BorderStyle = BorderStyle.None;
        list.IntegralHeight = false;
    }
}