using WiFiGameHub.Services;

namespace WiFiGameHub.Forms;

public class WifiForm : Form
{
    private readonly ListView _networkList = new();
    private readonly Label _statusLabel = new();
    private readonly Label _connectedLabel = new();
    private readonly Label _emptyState = new();
    private readonly Button _refreshButton = new();

    public WifiForm(bool scanOnLoad = true)
    {
        Text = "Network Center";
        BackColor = Color.FromArgb(17, 22, 34);
        ForeColor = Color.White;
        FormBorderStyle = FormBorderStyle.None;
        Dock = DockStyle.Fill;
        Padding = new Padding(0);

        var root = new TableLayoutPanel { Dock = DockStyle.Fill, ColumnCount = 1, RowCount = 3, BackColor = BackColor, Padding = Padding.Empty };
        root.RowStyles.Add(new RowStyle(SizeType.Absolute, 72));
        root.RowStyles.Add(new RowStyle(SizeType.Absolute, 108));
        root.RowStyles.Add(new RowStyle(SizeType.Percent, 100));

        var header = new Panel { Dock = DockStyle.Fill };
        header.Controls.Add(new Label { Text = "Wi-Fi networks", ForeColor = Color.White, Font = new Font("Segoe UI", 22F, FontStyle.Bold), AutoSize = true, Location = new Point(0, 0) });
        header.Controls.Add(new Label { Text = "View nearby networks and check your current connection.", ForeColor = Color.FromArgb(157, 175, 199), Font = new Font("Segoe UI", 9.5F), AutoSize = true, Location = new Point(2, 43) });

        var statusPanel = new TableLayoutPanel { Dock = DockStyle.Fill, ColumnCount = 2, RowCount = 1, BackColor = Color.FromArgb(28, 36, 52), Padding = new Padding(16, 14, 14, 14), Margin = new Padding(0, 0, 0, 12) };
        statusPanel.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 72));
        statusPanel.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 28));
        var connectionInfo = new Panel { Dock = DockStyle.Fill };
        connectionInfo.Controls.Add(new Label { Text = "CONNECTED NETWORK", ForeColor = Color.FromArgb(137, 158, 188), Font = new Font("Segoe UI", 8F, FontStyle.Bold), AutoSize = true, Location = new Point(0, 0) });
        _connectedLabel.Text = "Checking...";
        _connectedLabel.ForeColor = Color.White;
        _connectedLabel.Font = new Font("Segoe UI", 13F, FontStyle.Bold);
        _connectedLabel.AutoEllipsis = true;
        _connectedLabel.AutoSize = false;
        _connectedLabel.Location = new Point(0, 25);
        _connectedLabel.Size = new Size(480, 28);
        _connectedLabel.Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right;
        connectionInfo.Controls.Add(_connectedLabel);

        var scanInfo = new Panel { Dock = DockStyle.Fill };
        _statusLabel.Text = "Ready";
        _statusLabel.ForeColor = Color.FromArgb(157, 175, 199);
        _statusLabel.Font = new Font("Segoe UI", 9F);
        _statusLabel.AutoEllipsis = true;
        _statusLabel.AutoSize = false;
        _statusLabel.Dock = DockStyle.Top;
        _statusLabel.Height = 24;
        _refreshButton.Text = "Scan Again";
        _refreshButton.BackColor = Color.FromArgb(94, 111, 240);
        _refreshButton.ForeColor = Color.White;
        _refreshButton.FlatStyle = FlatStyle.Flat;
        _refreshButton.FlatAppearance.BorderSize = 0;
        _refreshButton.Font = new Font("Segoe UI", 9F, FontStyle.Bold);
        _refreshButton.Dock = DockStyle.Bottom;
        _refreshButton.Height = 36;
        _refreshButton.Click += async (_, _) => await LoadNetworksAsync();
        scanInfo.Controls.Add(_refreshButton);
        scanInfo.Controls.Add(_statusLabel);

        statusPanel.Controls.Add(connectionInfo, 0, 0);
        statusPanel.Controls.Add(scanInfo, 1, 0);

        _networkList.Dock = DockStyle.Fill;
        _networkList.View = View.Details;
        _networkList.FullRowSelect = true;
        _networkList.BorderStyle = BorderStyle.None;
        _networkList.BackColor = Color.FromArgb(24, 31, 45);
        _networkList.ForeColor = Color.FromArgb(226, 234, 245);
        _networkList.Font = new Font("Segoe UI", 10F);
        _networkList.HeaderStyle = ColumnHeaderStyle.Nonclickable;
        _networkList.MultiSelect = false;
        _networkList.Columns.Add("NETWORK", 320);
        _networkList.Columns.Add("SIGNAL", 120);
        _networkList.Columns.Add("SECURITY", 210);
        _networkList.Columns.Add("STATUS", 140);
        _networkList.Resize += (_, _) => ResizeColumns();
        var networkSurface = new Panel { Dock = DockStyle.Fill, BackColor = Color.FromArgb(24, 31, 45) };
        networkSurface.Controls.Add(_networkList);
        _emptyState.Dock = DockStyle.Fill;
        _emptyState.BackColor = networkSurface.BackColor;
        _emptyState.ForeColor = Color.FromArgb(157, 175, 199);
        _emptyState.Font = new Font("Segoe UI", 10F);
        _emptyState.Text = "Scan to find nearby Wi-Fi networks.";
        _emptyState.TextAlign = ContentAlignment.MiddleCenter;
        networkSurface.Controls.Add(_emptyState);
        _emptyState.BringToFront();

        root.Controls.Add(header, 0, 0);
        root.Controls.Add(statusPanel, 0, 1);
        root.Controls.Add(networkSurface, 0, 2);
        Controls.Add(root);
        if (scanOnLoad)
        {
            Load += async (_, _) => await LoadNetworksAsync();
        }
    }

    private async Task LoadNetworksAsync()
    {
        _refreshButton.Enabled = false;
        _statusLabel.Text = "Scanning nearby networks...";
        _emptyState.Text = "Scanning nearby Wi-Fi networks...";
        _emptyState.Visible = _networkList.Items.Count == 0;
        try
        {
            ApplyScanResult(await WifiScanner.ScanNetworksDetailedAsync());
        }
        catch (Exception exception)
        {
            ApplyScanResult(new WifiScanResult(null, string.Empty, Array.Empty<WifiNetwork>(), exception.Message));
        }
        finally
        {
            _refreshButton.Enabled = true;
        }
    }

    private void ApplyScanResult(WifiScanResult result)
    {
        _networkList.BeginUpdate();
        _networkList.Items.Clear();
        foreach (var network in result.Networks.OrderByDescending(item => item.SignalStrength))
        {
            var item = new ListViewItem(network.Ssid);
            item.SubItems.Add(network.SignalStrength > 0 ? $"{network.SignalStrength}%" : "—");
            item.SubItems.Add(network.Authentication);
            item.SubItems.Add(network.IsConnected ? "Connected" : "Available");
            _networkList.Items.Add(item);
        }
        _networkList.EndUpdate();

        _emptyState.Visible = result.Networks.Count == 0;
        _connectedLabel.Text = string.IsNullOrWhiteSpace(result.ConnectedNetwork)
            ? "Not connected"
            : result.ConnectedNetwork;
        _emptyState.Text = !string.IsNullOrWhiteSpace(result.ErrorMessage)
            ? "Could not scan for networks.\r\nCheck the Wi-Fi adapter and try again."
            : result.WifiEnabled == false
                ? "Turn on Wi-Fi to find nearby networks."
                : "No nearby networks found. Try scanning again.";
        _statusLabel.Text = !string.IsNullOrWhiteSpace(result.ErrorMessage)
            ? $"Scan failed: {result.ErrorMessage}"
            : result.WifiEnabled == false
                ? "Wi-Fi is off or unavailable"
                : result.Networks.Count == 0 ? "No networks found" : $"{result.Networks.Count} networks found";
        ResizeColumns();
    }

    private void ResizeColumns()
    {
        if (_networkList.Columns.Count != 4 || _networkList.ClientSize.Width <= 0)
        {
            return;
        }

        var width = Math.Max(0, _networkList.ClientSize.Width - SystemInformation.VerticalScrollBarWidth);
        _networkList.Columns[0].Width = (int)(width * 0.40);
        _networkList.Columns[1].Width = (int)(width * 0.16);
        _networkList.Columns[2].Width = (int)(width * 0.26);
        _networkList.Columns[3].Width = width - _networkList.Columns[0].Width - _networkList.Columns[1].Width - _networkList.Columns[2].Width;
    }
}