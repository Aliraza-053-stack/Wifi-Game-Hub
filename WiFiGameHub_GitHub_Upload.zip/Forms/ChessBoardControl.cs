using System.Drawing.Drawing2D;
using System.Drawing.Text;
using WiFiGameHub.Games.Chess;

namespace WiFiGameHub.Forms;

public sealed class ChessBoardControl : Control
{
    private static readonly Color LightSquare = Color.FromArgb(220, 220, 235);
    private static readonly Color DarkSquare = Color.FromArgb(65, 66, 94);

    public ChessGame Game { get; set; }
    public (int Row, int Column)? SelectedSquare { get; set; }
    public IReadOnlyCollection<(int Row, int Column)> LegalTargets { get; set; } = Array.Empty<(int Row, int Column)>();
    public bool FlipBoard { get; set; }

    public event Action<int, int>? SquareClicked;

    public ChessBoardControl(ChessGame game)
    {
        Game = game;
        DoubleBuffered = true;
        BackColor = Color.FromArgb(22, 27, 38);
        MinimumSize = new Size(360, 360);
        Dock = DockStyle.Fill;
        SetStyle(ControlStyles.ResizeRedraw | ControlStyles.UserPaint | ControlStyles.AllPaintingInWmPaint, true);
    }

    protected override void OnPaint(PaintEventArgs e)
    {
        base.OnPaint(e);
        var graphics = e.Graphics;
        graphics.SmoothingMode = SmoothingMode.AntiAlias;
        graphics.TextRenderingHint = TextRenderingHint.AntiAliasGridFit;
        if (!TryGetBoardBounds(out var boardBounds))
        {
            return;
        }

        var boardSize = boardBounds.Width;
        var cell = boardSize / 8f;
        var originX = boardBounds.X;
        var originY = boardBounds.Y;
        var frame = new RectangleF(originX - 18, originY - 18, boardSize + 36, boardSize + 36);
        using (var frameShadow = new SolidBrush(Color.FromArgb(115, 0, 0, 0)))
        {
            graphics.FillEllipse(frameShadow, frame.X + 8, frame.Bottom - 2, frame.Width - 4, 24);
        }
        using (var outerFrame = RoundedRectangle(frame, 14))
        using (var outerWood = new LinearGradientBrush(frame, Color.FromArgb(51, 45, 78), Color.FromArgb(24, 26, 42), 40f))
        using (var outerEdge = new Pen(Color.FromArgb(117, 91, 176), 2.2f))
        {
            graphics.FillPath(outerWood, outerFrame);
            graphics.DrawPath(outerEdge, outerFrame);
        }
        var bevel = new RectangleF(originX - 12, originY - 12, boardSize + 24, boardSize + 24);
        using (var innerFrame = RoundedRectangle(bevel, 8))
        using (var innerWood = new LinearGradientBrush(bevel, Color.FromArgb(83, 69, 125), Color.FromArgb(37, 39, 61), 35f))
        using (var innerEdge = new Pen(Color.FromArgb(31, 29, 48), 2f))
        {
            graphics.FillPath(innerWood, innerFrame);
            graphics.DrawPath(innerEdge, innerFrame);
        }

        var board = Game.Board;
        for (var screenRow = 0; screenRow < 8; screenRow++)
        {
            for (var screenColumn = 0; screenColumn < 8; screenColumn++)
            {
                var (row, column) = ToBoardSquare(screenRow, screenColumn);
                var bounds = new RectangleF(originX + screenColumn * cell, originY + screenRow * cell, cell, cell);
                var light = (row + column) % 2 == 0;
                using (var square = new LinearGradientBrush(
                    bounds,
                    light ? LightSquare : DarkSquare,
                    light ? Color.FromArgb(207, 207, 224) : Color.FromArgb(51, 53, 81),
                    42f))
                using (var edge = new Pen(Color.FromArgb(48, 44, 27, 16), 0.7f))
                {
                    graphics.FillRectangle(square, bounds);
                    graphics.DrawRectangle(edge, bounds.X, bounds.Y, bounds.Width, bounds.Height);
                }

                if (Game.LastMove is { } lastMove
                    && (lastMove.FromRow == row && lastMove.FromColumn == column
                        || lastMove.ToRow == row && lastMove.ToColumn == column))
                {
                    using var lastMoveBrush = new SolidBrush(Color.FromArgb(85, 153, 113, 236));
                    graphics.FillRectangle(lastMoveBrush, bounds);
                }
                if (SelectedSquare == (row, column))
                {
                    using var selectedBrush = new SolidBrush(Color.FromArgb(125, 145, 92, 246));
                    graphics.FillRectangle(selectedBrush, bounds);
                }
                if (LegalTargets.Contains((row, column)))
                {
                    if (board[row, column] == '\0')
                    {
                        using var targetBrush = new SolidBrush(Color.FromArgb(145, 51, 63, 91));
                        var diameter = cell * 0.24f;
                        graphics.FillEllipse(targetBrush, bounds.X + (cell - diameter) / 2, bounds.Y + (cell - diameter) / 2, diameter, diameter);
                    }
                    else
                    {
                        using var targetPen = new Pen(Color.FromArgb(220, 88, 173, 255), Math.Max(3, cell * 0.045f));
                        graphics.DrawEllipse(targetPen, bounds.X + 3, bounds.Y + 3, cell - 6, cell - 6);
                    }
                }

                if (board[row, column] != '\0')
                {
                    DrawPiece(graphics, board[row, column], bounds);
                }
                if (screenColumn == 0)
                {
                    using var rankFont = new Font("Segoe UI", Math.Max(8, cell * 0.12f), FontStyle.Bold);
                    using var rankBrush = new SolidBrush(light ? DarkSquare : LightSquare);
                    graphics.DrawString((8 - row).ToString(), rankFont, rankBrush, bounds.X + 3, bounds.Y + 2);
                }
                if (screenRow == 7)
                {
                    using var fileFont = new Font("Segoe UI", Math.Max(8, cell * 0.12f), FontStyle.Bold);
                    using var fileBrush = new SolidBrush(light ? DarkSquare : LightSquare);
                    graphics.DrawString(((char)('a' + column)).ToString(), fileFont, fileBrush, bounds.Right - cell * 0.16f, bounds.Bottom - cell * 0.18f);
                }
            }
        }

        if (Game.IsCheck)
        {
            for (var row = 0; row < 8; row++)
            {
                for (var column = 0; column < 8; column++)
                {
                    if (board[row, column] != (Game.CurrentTurn == ChessSide.White ? 'K' : 'k'))
                    {
                        continue;
                    }
                    var screen = ToScreenSquare(row, column);
                    var bounds = new RectangleF(originX + screen.Column * cell, originY + screen.Row * cell, cell, cell);
                    using var checkBrush = new SolidBrush(Color.FromArgb(95, 228, 51, 48));
                    graphics.FillRectangle(checkBrush, bounds);
                    DrawPiece(graphics, board[row, column], bounds);
                    break;
                }
            }
        }
    }

    protected override void OnMouseDown(MouseEventArgs e)
    {
        base.OnMouseDown(e);
        if (e.Button != MouseButtons.Left)
        {
            return;
        }
        if (!TryGetBoardBounds(out var boardBounds))
        {
            return;
        }
        var boardSize = boardBounds.Width;
        var originX = boardBounds.X;
        var originY = boardBounds.Y;
        var cell = boardSize / 8f;
        var screenColumn = (int)((e.X - originX) / cell);
        var screenRow = (int)((e.Y - originY) / cell);
        if (screenRow is < 0 or >= 8 || screenColumn is < 0 or >= 8)
        {
            return;
        }

        var square = ToBoardSquare(screenRow, screenColumn);
        SquareClicked?.Invoke(square.Row, square.Column);
    }

    private bool TryGetBoardBounds(out RectangleF bounds)
    {
        var available = Math.Min(ClientSize.Width - 64, ClientSize.Height - 64);
        if (available < 8)
        {
            bounds = RectangleF.Empty;
            return false;
        }

        var boardSize = Math.Min(available, 760);
        bounds = new RectangleF(
            (ClientSize.Width - boardSize) / 2f,
            (ClientSize.Height - boardSize) / 2f,
            boardSize,
            boardSize);
        return true;
    }

    private void DrawPiece(Graphics graphics, char piece, RectangleF square)
    {
        var whitePiece = char.IsUpper(piece);
        var kind = char.ToUpperInvariant(piece);
        var width = square.Width * 0.76f;
        var height = square.Height * 0.84f;
        var left = square.X + (square.Width - width) / 2;
        var top = square.Y + square.Height * 0.07f;
        var baseY = top + height * 0.87f;
        var side = whitePiece ? Color.FromArgb(166, 160, 193) : Color.FromArgb(21, 22, 38);
        var dark = whitePiece ? Color.FromArgb(119, 112, 149) : Color.FromArgb(9, 10, 20);
        var highlight = whitePiece ? Color.FromArgb(255, 255, 255) : Color.FromArgb(137, 119, 190);
        var mid = whitePiece ? Color.FromArgb(239, 237, 248) : Color.FromArgb(55, 53, 81);

        using (var groundShadow = new SolidBrush(Color.FromArgb(100, 25, 17, 12)))
        {
            graphics.FillEllipse(groundShadow, left + width * 0.08f, baseY + height * 0.055f, width * 0.92f, height * 0.12f);
        }
        DrawEllipticalLayer(graphics, left + width * 0.05f, baseY - height * 0.10f, width * 0.90f, height * 0.18f,
            side, dark, highlight);

        var foot = new RectangleF(left + width * 0.18f, baseY - height * 0.20f, width * 0.64f, height * 0.17f);
        DrawEllipticalLayer(graphics, foot.X, foot.Y, foot.Width, foot.Height, mid, dark, highlight);

        switch (kind)
        {
            case 'P':
                DrawTaperedBody(graphics, left, top, width, height, mid, dark, highlight,
                    0.38f, 0.68f, 0.25f, 0.48f);
                DrawEllipticalLayer(graphics, left + width * 0.34f, top + height * 0.11f, width * 0.32f, height * 0.27f,
                    highlight, side, Color.White);
                break;
            case 'R':
                DrawTaperedBody(graphics, left, top, width, height, mid, dark, highlight,
                    0.31f, 0.58f, 0.26f, 0.28f);
                DrawCrown(graphics, left, top, width, height, mid, dark, highlight, rook: true);
                break;
            case 'B':
                DrawTaperedBody(graphics, left, top, width, height, mid, dark, highlight,
                    0.32f, 0.65f, 0.20f, 0.38f);
                DrawEllipticalLayer(graphics, left + width * 0.36f, top + height * 0.12f, width * 0.28f, height * 0.24f,
                    mid, dark, highlight);
                using (var slitPen = new Pen(dark, Math.Max(1.5f, square.Width * 0.035f)))
                {
                    graphics.DrawLine(slitPen, left + width * 0.48f, top + height * 0.15f,
                        left + width * 0.57f, top + height * 0.30f);
                }
                break;
            case 'N':
                DrawKnight(graphics, left, top, width, height, mid, dark, highlight);
                break;
            case 'Q':
                DrawTaperedBody(graphics, left, top, width, height, mid, dark, highlight,
                    0.33f, 0.68f, 0.19f, 0.39f);
                DrawCrown(graphics, left, top, width, height, mid, dark, highlight, rook: false);
                break;
            case 'K':
                DrawTaperedBody(graphics, left, top, width, height, mid, dark, highlight,
                    0.32f, 0.67f, 0.18f, 0.42f);
                DrawKingCrown(graphics, left, top, width, height, mid, dark, highlight);
                break;
        }
    }

    private static void DrawEllipticalLayer(Graphics graphics, float x, float y, float width, float height, Color top, Color bottom, Color shine)
    {
        using var sideBrush = new LinearGradientBrush(new RectangleF(x, y, width, height), top, bottom, 90f);
        graphics.FillEllipse(sideBrush, x, y, width, height);
        using var edge = new Pen(Color.FromArgb(185, bottom), Math.Max(1f, width * 0.025f));
        graphics.DrawEllipse(edge, x, y, width, height);
        using var highlightPen = new Pen(Color.FromArgb(165, shine), Math.Max(0.8f, width * 0.018f));
        graphics.DrawArc(highlightPen, x + width * 0.08f, y + height * 0.08f, width * 0.76f, height * 0.72f, 195, 115);
    }

    private static void DrawTaperedBody(Graphics graphics, float x, float y, float width, float height,
        Color mid, Color dark, Color highlight, float baseTop, float baseBottom, float upperHalf, float lowerHalf)
    {
        using var body = new GraphicsPath();
        body.AddBezier(x + width * (0.5f - lowerHalf), y + height * baseBottom,
            x + width * (0.5f - lowerHalf * 0.62f), y + height * 0.70f,
            x + width * (0.5f - upperHalf * 1.4f), y + height * 0.53f,
            x + width * (0.5f - upperHalf), y + height * baseTop);
        body.AddLine(x + width * (0.5f - upperHalf), y + height * baseTop,
            x + width * (0.5f + upperHalf), y + height * baseTop);
        body.AddBezier(x + width * (0.5f + upperHalf), y + height * baseTop,
            x + width * (0.5f + upperHalf * 1.4f), y + height * 0.53f,
            x + width * (0.5f + lowerHalf * 0.62f), y + height * 0.70f,
            x + width * (0.5f + lowerHalf), y + height * baseBottom);
        body.CloseFigure();
        FillSculptedShape(graphics, body, mid, dark, highlight, width);
        DrawEllipticalLayer(graphics, x + width * (0.5f - upperHalf * 1.15f), y + height * (baseTop - 0.025f),
            width * upperHalf * 2.3f, height * 0.06f, highlight, mid, Color.White);
    }

    private static void DrawCrown(Graphics graphics, float x, float y, float width, float height,
        Color mid, Color dark, Color highlight, bool rook)
    {
        var crownY = y + height * 0.13f;
        if (rook)
        {
            var battlement = new[]
            {
                new PointF(x + width * 0.25f, crownY + height * 0.12f),
                new PointF(x + width * 0.25f, crownY),
                new PointF(x + width * 0.39f, crownY),
                new PointF(x + width * 0.39f, crownY + height * 0.07f),
                new PointF(x + width * 0.48f, crownY + height * 0.07f),
                new PointF(x + width * 0.48f, crownY),
                new PointF(x + width * 0.62f, crownY),
                new PointF(x + width * 0.62f, crownY + height * 0.12f),
                new PointF(x + width * 0.5f, crownY + height * 0.18f)
            };
            using var crenellation = new GraphicsPath();
            crenellation.AddPolygon(battlement);
            FillSculptedShape(graphics, crenellation, mid, dark, highlight, width);
        }
        else
        {
            DrawEllipticalLayer(graphics, x + width * 0.23f, crownY + height * 0.06f, width * 0.54f, height * 0.11f,
                mid, dark, highlight);
            for (var index = 0; index < 5; index++)
            {
                var angle = (float)(Math.PI * (1.05 + index * 0.225));
                var centerX = x + width * (0.5f + MathF.Cos(angle) * 0.25f);
                var centerY = crownY + height * (0.035f + MathF.Sin(angle) * 0.075f);
                var ball = width * (index == 2 ? 0.13f : 0.095f);
                DrawEllipticalLayer(graphics, centerX - ball / 2, centerY - ball / 2, ball, ball, highlight, dark, Color.White);
            }
        }
    }

    private static void DrawKingCrown(Graphics graphics, float x, float y, float width, float height,
        Color mid, Color dark, Color highlight)
    {
        var centerX = x + width * 0.5f;
        var crossY = y + height * 0.12f;
        DrawEllipticalLayer(graphics, centerX - width * 0.13f, crossY + height * 0.11f, width * 0.26f, height * 0.08f,
            mid, dark, highlight);
        using var cross = new GraphicsPath();
        cross.AddRectangle(new RectangleF(centerX - width * 0.035f, crossY - height * 0.02f, width * 0.07f, height * 0.20f));
        cross.AddRectangle(new RectangleF(centerX - width * 0.13f, crossY + height * 0.035f, width * 0.26f, height * 0.065f));
        FillSculptedShape(graphics, cross, highlight, dark, Color.White, width);
    }

    private static void DrawKnight(Graphics graphics, float x, float y, float width, float height,
        Color mid, Color dark, Color highlight)
    {
        using var horse = new GraphicsPath();
        horse.StartFigure();
        horse.AddBezier(x + width * 0.25f, y + height * 0.78f,
            x + width * 0.39f, y + height * 0.58f,
            x + width * 0.26f, y + height * 0.43f,
            x + width * 0.31f, y + height * 0.27f);
        horse.AddBezier(x + width * 0.31f, y + height * 0.27f,
            x + width * 0.35f, y + height * 0.19f,
            x + width * 0.28f, y + height * 0.12f,
            x + width * 0.41f, y + height * 0.08f);
        horse.AddBezier(x + width * 0.41f, y + height * 0.08f,
            x + width * 0.44f, y + height * 0.17f,
            x + width * 0.52f, y + height * 0.19f,
            x + width * 0.61f, y + height * 0.16f);
        horse.AddBezier(x + width * 0.61f, y + height * 0.16f,
            x + width * 0.83f, y + height * 0.23f,
            x + width * 0.75f, y + height * 0.42f,
            x + width * 0.66f, y + height * 0.53f);
        horse.AddBezier(x + width * 0.66f, y + height * 0.53f,
            x + width * 0.78f, y + height * 0.63f,
            x + width * 0.75f, y + height * 0.72f,
            x + width * 0.72f, y + height * 0.78f);
        horse.CloseFigure();
        FillSculptedShape(graphics, horse, mid, dark, highlight, width);

        using var mane = new SolidBrush(dark);
        graphics.FillEllipse(mane, x + width * 0.28f, y + height * 0.24f, width * 0.18f, height * 0.28f);
        using var eye = new SolidBrush(dark);
        graphics.FillEllipse(eye, x + width * 0.63f, y + height * 0.31f, width * 0.055f, width * 0.055f);
        using var nose = new Pen(highlight, Math.Max(1f, width * 0.025f));
        graphics.DrawLine(nose, x + width * 0.63f, y + height * 0.39f, x + width * 0.77f, y + height * 0.43f);
    }

    private static void FillSculptedShape(Graphics graphics, GraphicsPath path, Color mid, Color dark, Color highlight, float scale)
    {
        using var outline = new Pen(Color.FromArgb(215, dark), Math.Max(1.2f, scale * 0.035f))
        {
            LineJoin = LineJoin.Round
        };
        using var body = new LinearGradientBrush(path.GetBounds(), highlight, dark, 0f);
        graphics.FillPath(body, path);
        graphics.DrawPath(outline, path);
        using var shine = new Pen(Color.FromArgb(178, highlight), Math.Max(0.9f, scale * 0.018f))
        {
            LineJoin = LineJoin.Round
        };
        graphics.DrawPath(shine, path);
    }

    private (int Row, int Column) ToBoardSquare(int screenRow, int screenColumn) =>
        FlipBoard ? (7 - screenRow, 7 - screenColumn) : (screenRow, screenColumn);

    private (int Row, int Column) ToScreenSquare(int row, int column) =>
        FlipBoard ? (7 - row, 7 - column) : (row, column);

    private static GraphicsPath RoundedRectangle(RectangleF rectangle, float radius)
    {
        var path = new GraphicsPath();
        var diameter = radius * 2;
        path.AddArc(rectangle.X, rectangle.Y, diameter, diameter, 180, 90);
        path.AddArc(rectangle.Right - diameter, rectangle.Y, diameter, diameter, 270, 90);
        path.AddArc(rectangle.Right - diameter, rectangle.Bottom - diameter, diameter, diameter, 0, 90);
        path.AddArc(rectangle.X, rectangle.Bottom - diameter, diameter, diameter, 90, 90);
        path.CloseFigure();
        return path;
    }
}
