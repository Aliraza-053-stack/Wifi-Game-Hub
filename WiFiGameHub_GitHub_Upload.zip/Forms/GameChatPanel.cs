using System.Net.Sockets;
using WiFiGameHub.Networking;

namespace WiFiGameHub.Forms;

public sealed class GameChatPanel : UserControl
{
    private static readonly Color PanelColor = Color.FromArgb(27, 28, 45);
    private static readonly Color MessageAreaColor = Color.FromArgb(19, 20, 34);
    private static readonly Color InputColor = Color.FromArgb(21, 22, 38);
    private static readonly Color Blue = Color.FromArgb(69, 150, 255);
    private readonly MultiplayerSession? _session;
    private readonly FlowLayoutPanel _messages = new();
    private readonly TextBox _messageInput = new();
    private readonly Button _sendButton = new();
    private readonly Label _status = new();
    private readonly Label _emptyState = new();
    private readonly object _pendingMessagesLock = new();
    private readonly List<GameChatEntry> _pendingMessages = new();
    private bool _sending;
    private string _displayedRoomId = string.Empty;

    public GameChatPanel(MultiplayerSession? session)
    {
        _session = session;
        Dock = DockStyle.Fill;
        BackColor = PanelColor;
        MinimumSize = new Size(180, 130);

        var layout = new TableLayoutPanel
        {
            Dock = DockStyle.Fill,
            ColumnCount = 1,
            RowCount = 3,
            BackColor = PanelColor,
            Padding = new Padding(10)
        };
        layout.RowStyles.Add(new RowStyle(SizeType.Absolute, 26));
        layout.RowStyles.Add(new RowStyle(SizeType.Percent, 100));
        layout.RowStyles.Add(new RowStyle(SizeType.Absolute, 58));

        var title = new Label
        {
            Text = "Match chat",
            Dock = DockStyle.Fill,
            ForeColor = Color.White,
            Font = new Font("Segoe UI", 9.5F, FontStyle.Bold),
            TextAlign = ContentAlignment.MiddleLeft
        };

        _messages.Dock = DockStyle.Fill;
        _messages.AutoScroll = true;
        _messages.FlowDirection = FlowDirection.TopDown;
        _messages.WrapContents = false;
        _messages.BackColor = MessageAreaColor;
        _messages.Padding = new Padding(8);
        _messages.Resize += (_, _) => ResizeMessageCards();
        _emptyState.Text = "No messages yet\r\nSay hello to start the conversation.";
        _emptyState.ForeColor = Color.FromArgb(158, 165, 190);
        _emptyState.Font = new Font("Segoe UI", 9F);
        _emptyState.TextAlign = ContentAlignment.MiddleCenter;
        _emptyState.Width = Math.Max(150, _messages.ClientSize.Width - 20);
        _emptyState.Height = 64;
        _messages.Controls.Add(_emptyState);

        var composer = new TableLayoutPanel
        {
            Dock = DockStyle.Fill,
            ColumnCount = 2,
            RowCount = 2,
            BackColor = PanelColor,
            Margin = Padding.Empty,
            Padding = new Padding(0, 5, 0, 0)
        };
        composer.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100));
        composer.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 66));
        composer.RowStyles.Add(new RowStyle(SizeType.Percent, 100));
        composer.RowStyles.Add(new RowStyle(SizeType.Absolute, 20));
        _messageInput.Dock = DockStyle.Fill;
        _messageInput.BackColor = InputColor;
        _messageInput.ForeColor = Color.White;
        _messageInput.BorderStyle = BorderStyle.FixedSingle;
        _messageInput.Font = new Font("Segoe UI", 9F);
        _messageInput.PlaceholderText = "Write a message...";
        _messageInput.Multiline = true;
        _messageInput.AcceptsReturn = true;
        _messageInput.MaxLength = 1000;
        _messageInput.Margin = new Padding(0, 0, 6, 0);
        _messageInput.KeyDown += MessageInput_KeyDown;
        _messageInput.TextChanged += (_, _) => UpdateComposer();

        _sendButton.Text = "Send";
        _sendButton.Dock = DockStyle.Fill;
        _sendButton.BackColor = Blue;
        _sendButton.ForeColor = Color.White;
        _sendButton.FlatStyle = FlatStyle.Flat;
        _sendButton.FlatAppearance.BorderSize = 0;
        _sendButton.FlatAppearance.MouseOverBackColor = ControlPaint.Light(Blue, 0.1f);
        _sendButton.Font = new Font("Segoe UI", 8.5F, FontStyle.Bold);
        _sendButton.Click += async (_, _) => await SendMessageAsync();

        _status.Dock = DockStyle.Fill;
        _status.ForeColor = Color.FromArgb(158, 165, 190);
        _status.Font = new Font("Segoe UI", 7.5F);
        _status.AutoEllipsis = true;
        _status.TextAlign = ContentAlignment.MiddleLeft;
        composer.Controls.Add(_messageInput, 0, 0);
        composer.Controls.Add(_sendButton, 1, 0);
        composer.Controls.Add(_status, 0, 1);
        composer.SetColumnSpan(_status, 2);

        layout.Controls.Add(title, 0, 0);
        layout.Controls.Add(_messages, 0, 1);
        layout.Controls.Add(composer, 0, 2);
        Controls.Add(layout);

        if (_session is not null)
        {
            _session.ChatReceived += Session_ChatReceived;
            _session.ConnectionChanged += Session_ConnectionChanged;
            _session.StateChanged += Session_StateChanged;
            _session.StatusChanged += Session_StatusChanged;
            Disposed += (_, _) =>
            {
                _session.ChatReceived -= Session_ChatReceived;
                _session.ConnectionChanged -= Session_ConnectionChanged;
                _session.StateChanged -= Session_StateChanged;
                _session.StatusChanged -= Session_StatusChanged;
            };
        }
        UpdateSessionState();
    }

    protected override void OnHandleCreated(EventArgs e)
    {
        base.OnHandleCreated(e);
        GameChatEntry[] pending;
        lock (_pendingMessagesLock)
        {
            pending = _pendingMessages.ToArray();
            _pendingMessages.Clear();
        }
        foreach (var entry in pending)
        {
            AddMessage(entry);
        }
    }

    private async Task SendMessageAsync()
    {
        var localOnly = !IsRoomConnectionActive();
        if (!localOnly && !IsChatReady())
        {
            _status.Text = "Wait for the room connection before chatting.";
            UpdateComposer();
            return;
        }
        var text = _messageInput.Text.Trim();
        if (text.Length == 0)
        {
            return;
        }

        _sending = true;
        _status.Text = "Sending...";
        UpdateComposer();
        try
        {
            if (localOnly)
            {
                PostMessage(new GameChatEntry
                {
                    RoomId = "local",
                    SenderName = "You",
                    Text = text,
                    SentAtUtc = DateTime.UtcNow
                });
                _messageInput.Clear();
                _status.Text = "Local chat · this computer only";
            }
            else if (await _session!.SendChatAsync(text))
            {
                _messageInput.Clear();
                _status.Text = "Message sent";
            }
            else
            {
                _status.Text = "Message could not be sent. Check the room connection.";
            }
        }
        catch (Exception exception) when (exception is IOException or SocketException or InvalidOperationException or OperationCanceledException)
        {
            _status.Text = $"Message failed: {exception.Message}";
        }
        finally
        {
            _sending = false;
            UpdateComposer();
        }
    }

    private void Session_ChatReceived(GameChatEntry entry)
    {
        if (_session?.CurrentState is { } state && state.RoomId != entry.RoomId)
        {
            return;
        }
        PostMessage(entry);
    }

    private void PostMessage(GameChatEntry entry)
    {
        if (IsDisposed)
        {
            return;
        }
        if (!IsHandleCreated)
        {
            lock (_pendingMessagesLock)
            {
                if (!IsHandleCreated)
                {
                    _pendingMessages.Add(entry);
                    return;
                }
            }
        }
        if (InvokeRequired)
        {
            BeginInvoke(() => AddMessage(entry));
        }
        else
        {
            AddMessage(entry);
        }
    }

    private void AddMessage(GameChatEntry entry)
    {
        if (_messages.Controls.Contains(_emptyState))
        {
            _messages.Controls.Remove(_emptyState);
        }
        var card = new TableLayoutPanel
        {
            AutoSize = true,
            AutoSizeMode = AutoSizeMode.GrowAndShrink,
            ColumnCount = 1,
            RowCount = 2,
            Width = Math.Max(130, _messages.ClientSize.Width - 25),
            BackColor = IsOwnMessage(entry) ? Color.FromArgb(45, 37, 67) : Color.FromArgb(31, 34, 52),
            Margin = new Padding(1, 2, 1, 5),
            Padding = new Padding(7, 5, 7, 5)
        };
        card.RowStyles.Add(new RowStyle(SizeType.AutoSize));
        card.RowStyles.Add(new RowStyle(SizeType.AutoSize));
        card.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100));
        var sender = new Label
        {
            Text = $"{(IsOwnMessage(entry) ? "You" : entry.SenderName)}  ·  {entry.SentAtUtc.ToLocalTime():HH:mm}",
            AutoSize = true,
            Dock = DockStyle.Fill,
            ForeColor = IsOwnMessage(entry) ? Color.FromArgb(204, 179, 255) : Color.FromArgb(153, 183, 226),
            Font = new Font("Segoe UI", 8F, FontStyle.Bold),
            Margin = new Padding(0, 0, 0, 2)
        };
        var message = new Label
        {
            Text = entry.Text,
            AutoSize = true,
            Dock = DockStyle.Fill,
            ForeColor = Color.FromArgb(235, 236, 247),
            Font = new Font("Segoe UI", 9F),
            MaximumSize = new Size(Math.Max(110, card.Width - 18), 0),
            Margin = Padding.Empty
        };
        card.Controls.Add(sender, 0, 0);
        card.Controls.Add(message, 0, 1);
        _messages.Controls.Add(card);
        ScrollToLatest();
    }

    private void ResizeMessageCards()
    {
        var width = Math.Max(130, _messages.ClientSize.Width - 25);
        _emptyState.Width = Math.Max(150, _messages.ClientSize.Width - 20);
        foreach (var card in _messages.Controls.OfType<TableLayoutPanel>())
        {
            card.Width = width;
            if (card.Controls.Count > 1 && card.Controls[1] is Label message)
            {
                message.MaximumSize = new Size(Math.Max(110, width - 18), 0);
            }
        }
    }

    private void PostToUi(Action action)
    {
        if (IsDisposed || !IsHandleCreated)
        {
            return;
        }
        if (InvokeRequired)
        {
            BeginInvoke(action);
        }
        else
        {
            action();
        }
    }

    private void ScrollToLatest()
    {
        if (_messages.Controls.Count > 0)
        {
            _messages.ScrollControlIntoView(_messages.Controls[^1]);
        }
    }

    private void MessageInput_KeyDown(object? sender, KeyEventArgs e)
    {
        if (e.KeyCode == Keys.Enter && !e.Shift)
        {
            e.SuppressKeyPress = true;
            _ = SendMessageAsync();
        }
    }

    private void Session_ConnectionChanged(bool connected) => PostToUi(UpdateSessionState);
    private void Session_StateChanged(GameSessionState state) => PostToUi(UpdateSessionState);

    private void Session_StatusChanged(string message)
    {
        if (message.Contains("failed", StringComparison.OrdinalIgnoreCase)
            || message.Contains("rejected", StringComparison.OrdinalIgnoreCase)
            || message.Contains("disconnected", StringComparison.OrdinalIgnoreCase))
        {
            PostToUi(() =>
            {
                _status.Text = message;
                UpdateComposer();
            });
        }
    }

    private void UpdateSessionState()
    {
        var roomId = _session?.IsActive == true ? _session.RoomId : string.Empty;
        if (!string.Equals(roomId, _displayedRoomId, StringComparison.Ordinal))
        {
            _messages.Controls.Clear();
            lock (_pendingMessagesLock)
            {
                _pendingMessages.Clear();
            }
            _displayedRoomId = roomId;
            _messages.Controls.Add(_emptyState);
        }
        _status.Text = IsChatReady()
            ? $"Connected · {(_session!.Game == "Chat" ? "Chat Only room" : $"{_session.Game} room")}"
            : IsRoomConnectionActive()
                ? "Joining room..."
                : "Offline chat · local to this device.";
        UpdateComposer();
    }

    private void UpdateComposer()
    {
        var ready = IsChatReady();
        var canChat = ready || !IsRoomConnectionActive();
        _messageInput.Enabled = canChat && !_sending;
        _sendButton.Enabled = canChat && !_sending && _messageInput.Text.Trim().Length > 0;
    }

    private bool IsRoomConnectionActive() => _session?.IsActive == true;

    private bool IsOwnMessage(GameChatEntry entry) =>
        entry.RoomId == "local"
        || (!string.IsNullOrEmpty(entry.SenderId) && entry.SenderId == _session?.LocalPlayerId);

    private bool IsChatReady() =>
        _session?.IsActive == true
        && !string.IsNullOrWhiteSpace(_session.LocalPlayerId)
        && _session.CurrentState is { } state
        && state.Players.Any(player => player.PlayerId == _session.LocalPlayerId && player.Connected);
}
