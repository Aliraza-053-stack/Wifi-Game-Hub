using System.Diagnostics;
using System.Drawing.Drawing2D;
using System.Drawing.Text;
using System.Numerics;
using WiFiGameHub.Games.Carrom;
using WiFiGameHub.Networking;

namespace WiFiGameHub.Forms;

public sealed class CarromForm : Form
{
    private static readonly Color Canvas = Color.FromArgb(15, 16, 28);
    private static readonly Color Surface = Color.FromArgb(27, 28, 45);
    private static readonly Color MutedText = Color.FromArgb(158, 165, 190);
    private static readonly Color Purple = Color.FromArgb(145, 92, 246);
    private readonly Action? _onExit;
    private readonly CarromPhysicsEngine _engine = new();
    private readonly CarromRulesEngine _rules = new();
    private readonly MultiplayerSession? _session;
    private readonly CarromBoardControl _board;
    private readonly TrackBar _power = new();
    private readonly Label _powerValue = new();
    private readonly Label _status = new();
    private readonly Label _turnDetail = new();
    private readonly Label _instructions = new();
    private readonly Label _playerOneDetail = new();
    private readonly Label _playerTwoDetail = new();
    private readonly Label _playerOneName = new();
    private readonly Label _playerTwoName = new();
    private readonly Label _connectionStatus = new();
    private readonly Panel _playerOneCard;
    private readonly Panel _playerTwoCard;
    private readonly Button _resetButton = new();
    private readonly Button _exitButton = new();
    private readonly Panel _resultOverlay = new();
    private readonly Label _resultTitle = new();
    private readonly Label _resultDetails = new();
    private readonly Button _resultRematchButton = new();
    private readonly Stopwatch _localMatchClock = Stopwatch.StartNew();
    private bool _waitingForAuthoritativeState;
    private GameSessionState? _networkState;
    private long _lastNetworkRevision = -1;

    public CarromForm(Action? onExit = null, MultiplayerSession? session = null)
    {
        _onExit = onExit;
        _session = session is { Game: "Carrom" } ? session : null;
        _board = new CarromBoardControl(_engine);
        _playerOneCard = CreatePlayerCard("PLAYER 1 · WHITE", Color.FromArgb(222, 226, 242), _playerOneName, _playerOneDetail);
        _playerTwoCard = CreatePlayerCard("PLAYER 2 · BLACK", Color.FromArgb(110, 178, 255), _playerTwoName, _playerTwoDetail);
        Text = "Carrom Practice";
        BackColor = Canvas;
        ForeColor = Color.White;
        FormBorderStyle = FormBorderStyle.None;
        Dock = DockStyle.Fill;
        Padding = new Padding(12);
        MinimumSize = new Size(720, 520);

        var root = new TableLayoutPanel
        {
            Dock = DockStyle.Fill,
            ColumnCount = 1,
            RowCount = 2,
            BackColor = Canvas,
            Margin = Padding.Empty,
            Padding = Padding.Empty
        };
        root.RowStyles.Add(new RowStyle(SizeType.Absolute, 66));
        root.RowStyles.Add(new RowStyle(SizeType.Percent, 100));
        root.Controls.Add(CreateHeader(), 0, 0);

        var body = new TableLayoutPanel
        {
            Dock = DockStyle.Fill,
            ColumnCount = 2,
            RowCount = 1,
            BackColor = Canvas,
            Margin = Padding.Empty,
            Padding = Padding.Empty
        };
        body.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 68));
        body.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 32));
        _board.Dock = DockStyle.Fill;
        _board.Margin = new Padding(0, 0, 14, 0);
        body.Controls.Add(_board, 0, 0);
        body.Controls.Add(CreatePracticePanel(), 1, 0);
        root.Controls.Add(body, 0, 1);
        Controls.Add(root);
        Controls.Add(CreateResultOverlay());
        _board.ShotStarted += HandleShotStarted;
        _board.ShotCompleted += HandleShotCompleted;
        _board.ShotRequested += HandleShotRequested;
        _board.InvalidPlacement += () =>
        {
            _status.Text = "INVALID STRIKER POSITION · SELECT AN OPEN BASELINE SPOT";
            _status.ForeColor = Color.FromArgb(255, 143, 156);
        };
        if (_session is not null)
        {
            _session.StateChanged += Session_StateChanged;
            _session.StatusChanged += Session_StatusChanged;
            _session.ConnectionChanged += Session_ConnectionChanged;
            Disposed += (_, _) =>
            {
                _session.StateChanged -= Session_StateChanged;
                _session.StatusChanged -= Session_StatusChanged;
                _session.ConnectionChanged -= Session_ConnectionChanged;
            };
            if (_session.CurrentState is { } state)
            {
                ApplyNetworkState(state);
            }
        }
        _power.ValueChanged += (_, _) =>
        {
            _powerValue.Text = $"{_power.Value}%";
            _board.SetSelectedPower(_power.Value);
        };
        UpdateGamePresentation();
    }

    private Control CreateHeader()
    {
        var header = new Panel { Dock = DockStyle.Fill, BackColor = Canvas };
        var backButton = CreateButton("‹  Back", Color.FromArgb(39, 38, 58));
        backButton.Location = new Point(0, 10);
        backButton.Size = new Size(78, 32);
        backButton.Click += async (_, _) => await ExitAsync();
        header.Controls.Add(backButton);

        header.Controls.Add(new Label
        {
            Text = "CARROM",
            ForeColor = Color.White,
            Font = new Font("Segoe UI", 19F, FontStyle.Bold),
            AutoSize = true,
            Location = new Point(94, 1)
        });
        header.Controls.Add(new Label
        {
            Text = _session is null ? "NEON PRACTICE TABLE  ·  LOCAL MATCH" : "NEON PRACTICE TABLE  ·  WI-FI MATCH",
            ForeColor = Color.FromArgb(187, 165, 241),
            Font = new Font("Segoe UI", 8F, FontStyle.Bold),
            AutoSize = true,
            Location = new Point(97, 37)
        });
        _exitButton.Text = "Exit";
        StyleButton(_exitButton, Color.FromArgb(39, 38, 58));
        _exitButton.Size = new Size(66, 32);
        _exitButton.Anchor = AnchorStyles.Top | AnchorStyles.Right;
        _exitButton.Location = new Point(header.ClientSize.Width - _exitButton.Width, 10);
        _exitButton.Click += async (_, _) => await ExitAsync();
        header.Resize += (_, _) => _exitButton.Left = header.ClientSize.Width - _exitButton.Width;
        header.Controls.Add(_exitButton);
        return header;
    }

    private Control CreateResultOverlay()
    {
        _resultOverlay.Dock = DockStyle.Fill;
        _resultOverlay.BackColor = Color.FromArgb(238, 12, 13, 25);
        _resultOverlay.Visible = false;

        var card = new Panel
        {
            Size = new Size(620, 390),
            BackColor = Color.FromArgb(29, 29, 48),
            Padding = new Padding(34)
        };
        card.Paint += (_, e) =>
        {
            using var border = new Pen(Color.FromArgb(115, 145, 92, 246), 2F);
            e.Graphics.DrawRectangle(border, 1, 1, card.Width - 3, card.Height - 3);
        };
        _resultTitle.Text = "MATCH COMPLETE";
        _resultTitle.Dock = DockStyle.Top;
        _resultTitle.Height = 54;
        _resultTitle.ForeColor = Color.FromArgb(255, 213, 122);
        _resultTitle.Font = new Font("Segoe UI", 22F, FontStyle.Bold);
        _resultTitle.TextAlign = ContentAlignment.MiddleCenter;
        _resultDetails.Dock = DockStyle.Fill;
        _resultDetails.ForeColor = Color.FromArgb(223, 226, 242);
        _resultDetails.Font = new Font("Segoe UI", 11F);
        _resultDetails.TextAlign = ContentAlignment.MiddleCenter;

        var actions = new FlowLayoutPanel
        {
            Dock = DockStyle.Bottom,
            Height = 54,
            FlowDirection = FlowDirection.RightToLeft,
            WrapContents = false,
            BackColor = Color.Transparent
        };
        var dashboard = CreateButton("Return to Dashboard", Color.FromArgb(43, 42, 61));
        dashboard.Size = new Size(176, 40);
        dashboard.Click += async (_, _) => await ExitAsync();
        _resultRematchButton.Text = "Play Again";
        StyleButton(_resultRematchButton, Color.FromArgb(91, 61, 157));
        _resultRematchButton.Size = new Size(138, 40);
        _resultRematchButton.Click += async (_, _) =>
        {
            if (_session is { IsActive: true })
            {
                await SendNetworkResetAsync();
            }
            else
            {
                ResetLocalMatch();
            }
        };
        actions.Controls.Add(dashboard);
        actions.Controls.Add(_resultRematchButton);
        card.Controls.Add(_resultDetails);
        card.Controls.Add(actions);
        card.Controls.Add(_resultTitle);
        _resultOverlay.Controls.Add(card);
        _resultOverlay.Resize += (_, _) => card.Location = new Point(
            Math.Max(0, (_resultOverlay.ClientSize.Width - card.Width) / 2),
            Math.Max(0, (_resultOverlay.ClientSize.Height - card.Height) / 2));
        return _resultOverlay;
    }

    private Control CreatePracticePanel()
    {
        var panel = new TableLayoutPanel
        {
            Dock = DockStyle.Fill,
            ColumnCount = 1,
            RowCount = 7,
            BackColor = Surface,
            Padding = new Padding(14),
            Margin = Padding.Empty
        };
        panel.RowStyles.Add(new RowStyle(SizeType.Absolute, 42));
        panel.RowStyles.Add(new RowStyle(SizeType.Absolute, 96));
        panel.RowStyles.Add(new RowStyle(SizeType.Absolute, 52));
        panel.RowStyles.Add(new RowStyle(SizeType.Percent, 100));
        panel.RowStyles.Add(new RowStyle(SizeType.Absolute, 68));
        panel.RowStyles.Add(new RowStyle(SizeType.Absolute, 42));
        panel.RowStyles.Add(new RowStyle(SizeType.Absolute, 30));

        _status.Dock = DockStyle.Fill;
        _status.ForeColor = Color.FromArgb(96, 224, 207);
        _status.Font = new Font("Segoe UI", 9F, FontStyle.Bold);
        _status.TextAlign = ContentAlignment.MiddleLeft;
        panel.Controls.Add(_status, 0, 0);
        panel.Controls.Add(CreatePlayersPanel(), 0, 1);

        var turnCard = CreateInfoCard("MATCH STATUS", _turnDetail, Purple);
        panel.Controls.Add(turnCard, 0, 2);

        _instructions.Text = "POSITION: drag along your near baseline.\nAIM: pull back from the striker and release.\nPocket your colour, cover the Queen on your next valid shot, and avoid pocketing the striker.";
        _instructions.Dock = DockStyle.Fill;
        _instructions.ForeColor = MutedText;
        _instructions.Font = new Font("Segoe UI", 9F);
        _instructions.TextAlign = ContentAlignment.TopLeft;
        _instructions.Padding = new Padding(2, 10, 2, 4);
        var instructionsPanel = new Panel
        {
            Dock = DockStyle.Fill,
            BackColor = Color.Transparent,
            Margin = Padding.Empty
        };
        instructionsPanel.Controls.Add(_instructions);
        panel.Controls.Add(instructionsPanel, 0, 3);

        var powerPanel = new TableLayoutPanel
        {
            Dock = DockStyle.Fill,
            ColumnCount = 2,
            RowCount = 2,
            BackColor = Color.Transparent,
            Margin = Padding.Empty
        };
        powerPanel.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 68));
        powerPanel.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 32));
        powerPanel.RowStyles.Add(new RowStyle(SizeType.Absolute, 23));
        powerPanel.RowStyles.Add(new RowStyle(SizeType.Percent, 100));
        var powerTitle = new Label
        {
            Text = "SHOT POWER",
            Dock = DockStyle.Fill,
            ForeColor = Color.FromArgb(190, 195, 216),
            Font = new Font("Segoe UI", 8F, FontStyle.Bold),
            TextAlign = ContentAlignment.MiddleLeft
        };
        _powerValue.Text = "50%";
        _powerValue.Dock = DockStyle.Fill;
        _powerValue.ForeColor = Color.FromArgb(120, 196, 255);
        _powerValue.Font = new Font("Segoe UI", 9F, FontStyle.Bold);
        _powerValue.TextAlign = ContentAlignment.MiddleRight;
        _power.Minimum = 0;
        _power.Maximum = 100;
        _power.Value = 50;
        _power.TickFrequency = 25;
        _power.SmallChange = 5;
        _power.LargeChange = 10;
        _power.Dock = DockStyle.Fill;
        _power.Margin = new Padding(0, 0, 6, 0);
        _power.BackColor = Surface;
        powerPanel.Controls.Add(powerTitle, 0, 0);
        powerPanel.Controls.Add(_powerValue, 1, 0);
        powerPanel.Controls.Add(_power, 0, 1);
        powerPanel.SetColumnSpan(_power, 2);
        panel.Controls.Add(powerPanel, 0, 4);

        var actions = new TableLayoutPanel
        {
            Dock = DockStyle.Fill,
            ColumnCount = 2,
            RowCount = 1,
            BackColor = Color.Transparent,
            Margin = Padding.Empty
        };
        actions.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 50));
        actions.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 50));
        _resetButton.Text = "Reset Board";
        StyleButton(_resetButton, Color.FromArgb(76, 57, 121));
        _resetButton.Margin = new Padding(0, 3, 5, 3);
        _resetButton.Click += (_, _) =>
        {
            _board.ResetInteraction();
            if (_session is not null && _session.IsActive)
            {
                if (_session.IsHost || _networkState?.IsGameOver == true)
                {
                    _ = SendNetworkResetAsync();
                }
                return;
            }

            ResetLocalMatch();
        };
        actions.Controls.Add(_resetButton, 0, 0);
        var exit = CreateButton("Exit Game", Color.FromArgb(43, 42, 61));
        exit.Margin = new Padding(5, 3, 0, 3);
        exit.Click += async (_, _) => await ExitAsync();
        actions.Controls.Add(exit, 1, 0);
        panel.Controls.Add(actions, 0, 5);

        _connectionStatus.Text = _session is null
            ? "Local two-player match"
            : "Waiting for opponent connection...";
        _connectionStatus.Dock = DockStyle.Fill;
        _connectionStatus.ForeColor = Color.FromArgb(116, 128, 154);
        _connectionStatus.Font = new Font("Segoe UI", 8F);
        _connectionStatus.TextAlign = ContentAlignment.MiddleLeft;
        panel.Controls.Add(_connectionStatus, 0, 6);
        return panel;
    }

    private Control CreatePlayersPanel()
    {
        var players = new TableLayoutPanel
        {
            Dock = DockStyle.Fill,
            ColumnCount = 2,
            RowCount = 1,
            BackColor = Color.Transparent,
            Margin = Padding.Empty
        };
        players.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 50));
        players.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 50));
        players.Controls.Add(_playerOneCard, 0, 0);
        players.Controls.Add(_playerTwoCard, 1, 0);
        return players;
    }

    private static Panel CreatePlayerCard(string name, Color accent, Label playerName, Label details)
    {
        var card = new Panel
        {
            Dock = DockStyle.Fill,
            BackColor = Color.FromArgb(21, 22, 38),
            Margin = new Padding(0, 0, 6, 0),
            Padding = new Padding(9, 8, 6, 5)
        };
        card.Controls.Add(new Panel
        {
            BackColor = accent,
            Size = new Size(3, 34),
            Location = new Point(0, 8)
        });
        playerName.Text = name;
        playerName.ForeColor = Color.White;
        playerName.Font = new Font("Segoe UI", 8.5F, FontStyle.Bold);
        playerName.AutoSize = true;
        playerName.Location = new Point(10, 7);
        card.Controls.Add(playerName);
        details.Text = "9 coins left · Score —";
        details.ForeColor = MutedText;
        details.Font = new Font("Segoe UI", 7.5F);
        details.AutoSize = true;
        details.Location = new Point(10, 31);
        card.Controls.Add(details);
        return card;
    }

    private static Control CreateInfoCard(string title, Label detail, Color accent)
    {
        var card = new Panel
        {
            Dock = DockStyle.Fill,
            BackColor = Color.FromArgb(21, 22, 38),
            Padding = new Padding(10, 4, 5, 3),
            Margin = Padding.Empty
        };
        card.Controls.Add(new Label
        {
            Text = title,
            ForeColor = accent,
            Font = new Font("Segoe UI", 7.5F, FontStyle.Bold),
            AutoSize = true,
            Location = new Point(10, 4)
        });
        detail.ForeColor = Color.White;
        detail.Font = new Font("Segoe UI", 8.5F, FontStyle.Bold);
        detail.AutoSize = true;
        detail.Location = new Point(10, 23);
        card.Controls.Add(detail);
        return card;
    }

    private void HandleShotStarted()
    {
        _status.Text = $"PLAYER {_rules.CurrentPlayerIndex + 1} · SHOT IN PROGRESS";
        _status.ForeColor = Color.FromArgb(120, 196, 255);
        _turnDetail.Text = "Pieces moving · wait for the board to settle";
        _power.Enabled = false;
        _resetButton.Enabled = false;
        _board.CanInteract = false;
        UpdatePlayerCards();
    }

    private void HandleShotCompleted(CarromShotResult result)
    {
        if (_session is { IsActive: true })
        {
            _status.Text = "SHOT COMPLETE · SYNCHRONIZING";
            _turnDetail.Text = "Waiting for the authoritative host result…";
            return;
        }

        if (!_rules.TryProcessShot(_engine, result, out var ruleResult) || ruleResult is null)
        {
            _status.Text = "SHOT RESULT ALREADY PROCESSED";
            return;
        }

        if (ruleResult.BoardCompleted && !ruleResult.MatchCompleted)
        {
            _rules.BeginNextBoard(ruleResult.BoardWinnerIndex ?? _rules.CurrentPlayerIndex);
            _engine.Reset();
        }

        _connectionStatus.Text = ruleResult.FoulReason is not null
            ? $"FOUL: {ruleResult.FoulReason}"
            : ruleResult.QueenClaimed ? "Queen claimed and covered."
            : ruleResult.QueenReturned ? "Queen returned to the center; no Queen points awarded."
            : ruleResult.BoardCompleted ? "Board complete."
            : ruleResult.OwnCoinPocketed ? "Own-colour coin pocketed; player keeps the turn."
            : "No qualifying coin pocketed; turn passes.";
        UpdatePlayerCards();
        UpdateGamePresentation();
    }

    private void UpdateGamePresentation()
    {
        if (_session is not null)
        {
            if (_networkState is { } network)
            {
                UpdateNetworkPresentation(network);
            }
            else
            {
                _status.Text = "WAITING FOR MATCH STATE";
                _board.CanInteract = false;
                _power.Enabled = false;
            }
            return;
        }

        if (_rules.IsMatchComplete)
        {
            _status.Text = _rules.MatchWinnerIndex is int winner
                ? $"PLAYER {winner + 1} WINS THE MATCH"
                : "MATCH DRAW";
            _status.ForeColor = Color.FromArgb(255, 213, 122);
            _turnDetail.Text = $"Final score · White {_rules.Scores[0]} — Black {_rules.Scores[1]}";
            _instructions.Text = "Match complete. Select Play Again to start a new match, or return to the dashboard.";
            ShowLocalResult();
        }
        else
        {
            _resultOverlay.Visible = false;
            _status.Text = $"PLAYER {_rules.CurrentPlayerIndex + 1} · READY TO SHOOT";
            _status.ForeColor = Color.FromArgb(96, 224, 207);
            _turnDetail.Text = $"Player {_rules.CurrentPlayerIndex + 1}'s turn · drag back and release";
            _instructions.Text = $"POSITION: drag along your near baseline.\nAIM: pull back from the striker and release.\nQueen: {GetQueenStatus()}. Board {Math.Min(_rules.CompletedBoards + 1, _rules.Options.MaximumBoards)} of {_rules.Options.MaximumBoards}; first to {_rules.Options.MatchTargetScore} points wins.";
        }

        _board.CanInteract = !_rules.IsMatchComplete;
        _power.Enabled = !_rules.IsMatchComplete;
        _resetButton.Enabled = true;
        _resetButton.Text = _rules.IsMatchComplete ? "Play Again" : "Reset Board";
        UpdatePlayerCards();
    }

    private void UpdatePlayerCards()
    {
        _playerOneDetail.Text = $"Left {_engine.Pieces.Count(piece => piece.Type == CarromPieceType.White && piece.IsActive)} · In {_rules.PocketedCoins[0]} · Pts {_rules.Scores[0]} · F {_rules.Fouls[0]}";
        _playerTwoDetail.Text = $"Left {_engine.Pieces.Count(piece => piece.Type == CarromPieceType.Black && piece.IsActive)} · In {_rules.PocketedCoins[1]} · Pts {_rules.Scores[1]} · F {_rules.Fouls[1]}";
        _playerOneCard.BackColor = _rules.CurrentPlayerIndex == 0
            ? Color.FromArgb(49, 43, 74)
            : Color.FromArgb(21, 22, 38);
        _playerTwoCard.BackColor = _rules.CurrentPlayerIndex == 1
            ? Color.FromArgb(39, 48, 77)
            : Color.FromArgb(21, 22, 38);
    }

    private async void HandleShotRequested(CarromShotInput input)
    {
        if (!_board.CanInteract || _engine.IsShotInProgress)
        {
            return;
        }

        if (_session is not { IsActive: true })
        {
            _board.StartShot(input);
            return;
        }

        _waitingForAuthoritativeState = true;
        if (!_board.StartShot(input))
        {
            _waitingForAuthoritativeState = false;
            return;
        }

        try
        {
            var accepted = await _session.SendActionAsync(new GameActionRequest
            {
                Action = "carrom-shot",
                CarromStrikerX = input.StrikerX,
                CarromAimX = input.PullPoint.X,
                CarromAimY = input.PullPoint.Y,
                CarromPower = input.Power
            });
            if (!accepted)
            {
                _waitingForAuthoritativeState = false;
                if (_session.CurrentState is { } current)
                {
                    ApplySettledNetworkState(current);
                }
            }
        }
        catch (Exception exception) when (exception is IOException or InvalidOperationException or OperationCanceledException or ObjectDisposedException)
        {
            _waitingForAuthoritativeState = false;
            _status.Text = $"SHOT NOT SENT · {exception.Message}";
            if (_session.CurrentState is { } current)
            {
                ApplySettledNetworkState(current);
            }
        }
    }

    private void Session_StateChanged(GameSessionState state) => PostToUi(() => ApplyNetworkState(state));

    private void Session_StatusChanged(string message) => PostToUi(() =>
    {
        _connectionStatus.Text = message;
        var actionRejected = message.Contains("rejected", StringComparison.OrdinalIgnoreCase)
            || message.Contains("illegal", StringComparison.OrdinalIgnoreCase)
            || message.Contains("outdated", StringComparison.OrdinalIgnoreCase)
            || message.Contains("unauthorized", StringComparison.OrdinalIgnoreCase)
            || message.Contains("not authorized", StringComparison.OrdinalIgnoreCase);
        if (_session?.CurrentState is { } current && (_waitingForAuthoritativeState || actionRejected))
        {
            _waitingForAuthoritativeState = false;
            ApplySettledNetworkState(current);
        }
    });

    private void Session_ConnectionChanged(bool connected) => PostToUi(() =>
    {
        if (!connected && _session?.CurrentState is { } current)
        {
            ApplySettledNetworkState(current);
        }
    });

    private void ApplyNetworkState(GameSessionState state)
    {
        if (_session is null || state.RoomId != _session.RoomId || state.Game != "Carrom"
            || state.CarromPieces is null || state.CarromPieces.Length != 20
            || state.Revision < _lastNetworkRevision)
        {
            return;
        }

        if (_networkState is { } previous && state.Revision > previous.Revision
            && state.CarromLastShotActionId.Length > 0
            && state.CarromLastShotActionId != previous.CarromLastShotActionId
            && previous.CarromPieces.Length == 20
            && state.CarromLastShotPlayerId.Length > 0
            && !state.IsForfeit)
        {
            _lastNetworkRevision = state.Revision;
            _networkState = state;
            _waitingForAuthoritativeState = true;
            var shooter = state.Players.FirstOrDefault(player => player.PlayerId == state.CarromLastShotPlayerId)?.Name
                ?? "Opponent";
            _status.Text = $"{shooter.ToUpperInvariant()} · SHOT IN PROGRESS";
            _status.ForeColor = Color.FromArgb(120, 196, 255);
            _turnDetail.Text = "Opponent is aiming and shooting · waiting for the host's settled result";
            _connectionStatus.Text = $"{shooter} played a shot. The host remains authoritative.";
            _power.Enabled = false;
            _resetButton.Enabled = false;
            _board.CanInteract = false;
            var input = new CarromShotInput(
                state.CarromLastShotStrikerX,
                new System.Numerics.Vector2(state.CarromLastShotAimX, state.CarromLastShotAimY),
                state.CarromLastShotPower);
            var visualShotNumber = previous.CarromShotNumber + 1;
            _board.AnimateAuthoritativeShot(previous.CarromPieces, input, state.CarromPieces,
                state.CarromShotNumber, visualShotNumber, () => ApplySettledNetworkState(state));
            return;
        }

        if (state.Revision == _lastNetworkRevision && !_waitingForAuthoritativeState)
        {
            return;
        }
        ApplySettledNetworkState(state);
    }

    private void ApplySettledNetworkState(GameSessionState state)
    {
        try
        {
            _board.ApplyRemoteSnapshot(state.CarromPieces, state.CarromShotNumber);
            _rules.RestoreState(
                state.CarromCurrentPlayerIndex,
                state.CarromCompletedBoards,
                state.CarromWhiteScore,
                state.CarromBlackScore,
                state.CarromWhiteFouls,
                state.CarromBlackFouls,
                state.CarromWhitePocketedCoins,
                state.CarromBlackPocketedCoins,
                state.CarromWhiteTotalPocketedCoins,
                state.CarromBlackTotalPocketedCoins,
                state.CarromWhiteQueenBonus,
                state.CarromBlackQueenBonus,
                state.CarromQueenPendingCoverByPlayer < 0 ? null : state.CarromQueenPendingCoverByPlayer,
                state.CarromQueenClaimed,
                state.CarromQueenClaimedByPlayer < 0 ? null : state.CarromQueenClaimedByPlayer,
                state.CarromBoardComplete,
                state.IsGameOver && !state.IsForfeit,
                state.CarromMatchWinnerIndex < 0 ? null : state.CarromMatchWinnerIndex,
                state.CarromShotNumber);
            _networkState = state;
            _lastNetworkRevision = Math.Max(_lastNetworkRevision, state.Revision);
            _waitingForAuthoritativeState = false;
            _connectionStatus.Text = state.Players.All(player => player.Connected)
                ? "Opponent connected · authoritative host synchronization active"
                : state.LastDepartedPlayerName.Length > 0
                    ? $"Player {state.LastDepartedPlayerName} has left the match."
                    : "Waiting for opponent connection...";
            _playerOneName.Text = state.Players.FirstOrDefault(player => player.Mark == "White")?.Name ?? "White · waiting";
            _playerTwoName.Text = state.Players.FirstOrDefault(player => player.Mark == "Black")?.Name ?? "Black · waiting";
            UpdateGamePresentation();
        }
        catch (ArgumentException exception)
        {
            _connectionStatus.Text = $"Invalid Carrom state received: {exception.Message}";
            _board.CanInteract = false;
            _power.Enabled = false;
        }
    }

    private void UpdateNetworkPresentation(GameSessionState state)
    {
        var session = _session ?? throw new InvalidOperationException("Multiplayer Carrom state requires an active session.");
        if (state.IsForfeit)
        {
            var localWon = state.WinnerId == session.LocalPlayerId;
            _status.Text = localWon ? "VICTORY · OPPONENT LEFT" : "MATCH ENDED · PLAYER LEFT";
            _status.ForeColor = localWon ? Color.FromArgb(255, 213, 122) : Color.FromArgb(255, 143, 156);
            _turnDetail.Text = $"Player {state.LastDepartedPlayerName} left · {(localWon ? "You win by forfeit" : "Opponent wins by forfeit")}";
            _instructions.Text = "This Wi-Fi match has ended. Return to the dashboard or close the room from the lobby.";
            ShowNetworkResult(state);
        }
        else if (state.IsGameOver)
        {
            var localWon = state.WinnerId == session.LocalPlayerId;
            _status.Text = state.IsDraw ? "MATCH DRAW" : localWon ? "VICTORY · MATCH COMPLETE" : "DEFEAT · MATCH COMPLETE";
            _status.ForeColor = state.IsDraw ? Color.FromArgb(255, 213, 122)
                : localWon ? Color.FromArgb(255, 213, 122) : Color.FromArgb(255, 143, 156);
            _turnDetail.Text = $"Final score · White {state.CarromWhiteScore} — Black {state.CarromBlackScore}";
            _instructions.Text = "Match complete. The host can select Play Again to reset the match.";
            ShowNetworkResult(state);
        }
        else if (!state.Started)
        {
            _resultOverlay.Visible = false;
            _status.Text = "WAITING FOR OPPONENT";
            _status.ForeColor = Color.FromArgb(244, 190, 62);
            _turnDetail.Text = "A second player must join before the match begins.";
            _instructions.Text = "Share the room ID with your opponent. The host plays White; the joining player plays Black.";
        }
        else
        {
            _resultOverlay.Visible = false;
            var localTurn = state.CurrentPlayerId == session.LocalPlayerId;
            var currentName = state.Players.FirstOrDefault(player => player.PlayerId == state.CurrentPlayerId)?.Name ?? state.CurrentPlayerMark;
            _status.Text = localTurn ? "YOUR TURN · READY TO SHOOT" : $"{currentName.ToUpperInvariant()} · PLAYING";
            _status.ForeColor = localTurn ? Color.FromArgb(96, 224, 207) : Color.FromArgb(120, 196, 255);
            _turnDetail.Text = state.CarromLastResult.Length > 0
                ? state.CarromLastResult
                : $"{currentName}'s turn · Board {Math.Min(state.CarromCompletedBoards + 1, 8)} · {GetQueenStatus()}";
            _instructions.Text = "Only the active player can place and shoot the striker. The host simulates physics and synchronizes the validated result.";
        }

        var canPlay = state.Started && !state.IsGameOver
            && !state.IsForfeit && state.CurrentPlayerId == session.LocalPlayerId
            && session.IsConnected && !_waitingForAuthoritativeState;
        _board.CanInteract = canPlay;
        _power.Enabled = canPlay;
        var rematchAvailable = state.IsGameOver && !state.IsForfeit
            && state.Players.Count == 2 && state.Players.All(player => player.Connected);
        _resetButton.Enabled = session.IsConnected && state.Players.Count == 2
            && state.Players.All(player => player.Connected)
            && (session.IsHost && !state.IsForfeit || rematchAvailable);
        _resetButton.Text = state.IsGameOver ? "Play Again" : "Reset Match";
        _resultRematchButton.Enabled = session.IsConnected && rematchAvailable;
        UpdatePlayerCards();
    }

    private void ShowLocalResult()
    {
        var winner = _rules.MatchWinnerIndex is int index
            ? $"PLAYER {index + 1} · { (index == 0 ? "WHITE" : "BLACK") } WINS"
            : "MATCH DRAW";
        _resultTitle.Text = winner;
        _resultDetails.Text =
            $"FINAL SCORE\nWhite  {_rules.Scores[0]}       —       Black  {_rules.Scores[1]}\n\n" +
            $"Coins pocketed  {_rules.TotalPocketedCoins[0]} / {_rules.TotalPocketedCoins[1]}     ·     " +
            $"Queen bonus  +{_rules.QueenBonuses[0]} / +{_rules.QueenBonuses[1]}\n" +
            $"Fouls  {_rules.Fouls[0]} / {_rules.Fouls[1]}     ·     Duration  {FormatDuration(_localMatchClock.Elapsed.TotalSeconds)}";
        _resultOverlay.Visible = true;
        _resultOverlay.BringToFront();
    }

    private void ShowNetworkResult(GameSessionState state)
    {
        _resultTitle.Text = state.IsForfeit
            ? $"{state.WinnerName.ToUpperInvariant()} WINS BY FORFEIT"
            : state.IsDraw ? "MATCH DRAW" : $"{state.WinnerName.ToUpperInvariant()} WINS";
        _resultDetails.Text =
            $"FINAL SCORE\nWhite  {state.CarromWhiteScore}       —       Black  {state.CarromBlackScore}\n\n" +
            $"Coins pocketed  {state.CarromWhiteTotalPocketedCoins} / {state.CarromBlackTotalPocketedCoins}     ·     " +
            $"Queen bonus  +{state.CarromWhiteQueenBonus} / +{state.CarromBlackQueenBonus}\n" +
            $"Fouls  {state.CarromWhiteFouls} / {state.CarromBlackFouls}     ·     " +
            $"Duration  {FormatDuration(state.CarromMatchDurationSeconds)}";
        _resultOverlay.Visible = true;
        _resultOverlay.BringToFront();
    }

    private static string FormatDuration(double seconds)
    {
        var duration = TimeSpan.FromSeconds(Math.Max(0, seconds));
        return duration.TotalHours >= 1
            ? $"{(int)duration.TotalHours:00}:{duration.Minutes:00}:{duration.Seconds:00}"
            : $"{duration.Minutes:00}:{duration.Seconds:00}";
    }

    private string GetQueenStatus() =>
        _rules.QueenClaimed ? "secured" :
        _rules.QueenPendingCoverByPlayer is int player ? $"awaiting cover by Player {player + 1}" :
        "available";

    private void ResetLocalMatch()
    {
        _engine.Reset();
        _rules.Reset();
        _localMatchClock.Restart();
        _power.Value = 50;
        _connectionStatus.Text = "Local two-player match";
        UpdateGamePresentation();
    }

    private async Task SendNetworkResetAsync()
    {
        try
        {
            await _session!.SendActionAsync(new GameActionRequest { Action = "carrom-reset" });
        }
        catch (Exception exception) when (exception is IOException or InvalidOperationException or OperationCanceledException or ObjectDisposedException)
        {
            _connectionStatus.Text = $"Could not restart match: {exception.Message}";
        }
    }

    private async Task ExitAsync()
    {
        if (_session is { IsActive: true })
        {
            try
            {
                await _session.LeaveGameAsync();
            }
            catch (Exception exception) when (exception is IOException or InvalidOperationException or OperationCanceledException or ObjectDisposedException)
            {
                _connectionStatus.Text = $"Could not send leave notification: {exception.Message}";
            }
        }

        _onExit?.Invoke();
    }

    private void PostToUi(Action action)
    {
        if (IsDisposed || Disposing)
        {
            return;
        }
        if (IsHandleCreated && InvokeRequired)
        {
            BeginInvoke(action);
        }
        else
        {
            action();
        }
    }

    private static Button CreateButton(string text, Color color)
    {
        var button = new Button
        {
            Text = text,
            BackColor = color,
            ForeColor = Color.White,
            FlatStyle = FlatStyle.Flat,
            Font = new Font("Segoe UI", 8.5F, FontStyle.Bold),
            Cursor = Cursors.Hand
        };
        button.FlatAppearance.BorderSize = 0;
        return button;
    }

    private static void StyleButton(Button button, Color color)
    {
        button.BackColor = color;
        button.ForeColor = Color.White;
        button.FlatStyle = FlatStyle.Flat;
        button.Font = new Font("Segoe UI", 8.5F, FontStyle.Bold);
        button.Cursor = Cursors.Hand;
        button.FlatAppearance.BorderSize = 0;
        button.FlatAppearance.MouseOverBackColor = ControlPaint.Light(color, 0.12F);
    }
}

internal sealed record CarromShotInput(float StrikerX, Vector2 PullPoint, float Power);

internal sealed class CarromBoardControl : Control
{
    private static readonly Color Cyan = Color.FromArgb(67, 220, 232);
    private readonly CarromPhysicsEngine _engine;
    private readonly System.Windows.Forms.Timer _physicsTimer = new() { Interval = 16 };
    private readonly Stopwatch _clock = new();
    private readonly List<PocketEffect> _pocketEffects = new();
    private bool _positioningStriker;
    private bool _invalidPlacement;
    private bool _aimingShot;
    private Vector2 _aimPullPoint;
    private float _selectedPower = 50F;
    private CarromPieceSnapshot[]? _authoritativeSettledSnapshot;
    private int _authoritativeShotNumber;
    private Action? _authoritativeShotCompleted;

    internal RectangleF BoardBounds
    {
        get
        {
            var size = Math.Max(0, Math.Min(ClientSize.Width - 12, ClientSize.Height - 12));
            return new RectangleF((ClientSize.Width - size) / 2F, (ClientSize.Height - size) / 2F, size, size);
        }
    }

    internal int CoinCount => _engine.Pieces.Count(piece => piece.Type is CarromPieceType.Black or CarromPieceType.White or CarromPieceType.Queen);
    internal float StrikerPosition => _engine.Striker.Position.X;
    internal bool HasAimPreview => _aimingShot;
    internal bool IsShotInProgress => _engine.IsShotInProgress;
    internal bool CanInteract { get; set; } = true;

    public event Action? ShotStarted;
    public event Action<CarromShotResult>? ShotCompleted;
    public event Action<CarromShotInput>? ShotRequested;
    public event Action? InvalidPlacement;

    public CarromBoardControl(CarromPhysicsEngine engine)
    {
        _engine = engine ?? throw new ArgumentNullException(nameof(engine));
        BackColor = Color.FromArgb(20, 21, 35);
        SetStyle(ControlStyles.UserPaint | ControlStyles.AllPaintingInWmPaint | ControlStyles.OptimizedDoubleBuffer | ControlStyles.ResizeRedraw | ControlStyles.Selectable, true);
        TabStop = true;
        _engine.PiecePocketed += HandlePiecePocketed;
        _physicsTimer.Tick += PhysicsTimer_Tick;
    }

    internal void SetSelectedPower(float power) => _selectedPower = Math.Clamp(power, 0F, 100F);

    protected override void OnPaint(PaintEventArgs e)
    {
        base.OnPaint(e);
        var bounds = BoardBounds;
        if (bounds.Width < 30)
        {
            return;
        }

        var graphics = e.Graphics;
        graphics.SmoothingMode = SmoothingMode.AntiAlias;
        graphics.TextRenderingHint = TextRenderingHint.AntiAliasGridFit;
        var graphicsState = graphics.Save();
        graphics.SetClip(bounds);
        graphics.TranslateTransform(bounds.X, bounds.Y);
        graphics.ScaleTransform(bounds.Width / 1000F, bounds.Height / 1000F);
        DrawBoard(graphics);
        graphics.Restore(graphicsState);
    }

    internal void ResetInteraction()
    {
        _physicsTimer.Stop();
        _clock.Reset();
        _authoritativeSettledSnapshot = null;
        _authoritativeShotCompleted = null;
        _positioningStriker = false;
        _invalidPlacement = false;
        _aimingShot = false;
        _pocketEffects.Clear();
        Invalidate();
    }

    internal bool StartShot(CarromShotInput input)
    {
        var strikerPosition = new Vector2(input.StrikerX, CarromPhysicsEngine.StrikerBaselineY);
        var direction = strikerPosition - input.PullPoint;
        var power = CarromPhysicsEngine.GetShotPower(Vector2.Distance(strikerPosition, input.PullPoint), input.Power) * 100F;
        if (!_engine.TryPlaceStriker(input.StrikerX) || !_engine.Shoot(direction, power))
        {
            return false;
        }

        CanInteract = false;
        ShotStarted?.Invoke();
        _clock.Restart();
        _physicsTimer.Start();
        Invalidate();
        return true;
    }

    internal void ApplyRemoteSnapshot(CarromPieceSnapshot[] pieces, int shotNumber)
    {
        ResetInteraction();
        _engine.RestoreSnapshot(pieces, shotNumber);
        Invalidate();
    }

    internal void AnimateAuthoritativeShot(
        CarromPieceSnapshot[] startingPieces,
        CarromShotInput input,
        CarromPieceSnapshot[] settledPieces,
        int settledShotNumber,
        int visualShotNumber,
        Action completed)
    {
        ResetInteraction();
        try
        {
            _engine.RestoreSnapshot(startingPieces, Math.Max(0, visualShotNumber - 1));
            if (!_engine.TryPlaceStriker(input.StrikerX))
            {
                throw new InvalidOperationException("The authoritative striker placement cannot be previewed.");
            }
            var strikerPosition = new Vector2(input.StrikerX, CarromPhysicsEngine.StrikerBaselineY);
            var direction = strikerPosition - input.PullPoint;
            var power = CarromPhysicsEngine.GetShotPower(direction.Length(), input.Power) * 100F;
            if (!_engine.Shoot(direction, power))
            {
                throw new InvalidOperationException("The authoritative shot cannot be previewed.");
            }
        }
        catch (ArgumentException)
        {
            ApplyRemoteSnapshot(settledPieces, settledShotNumber);
            completed();
            return;
        }
        catch (InvalidOperationException)
        {
            ApplyRemoteSnapshot(settledPieces, settledShotNumber);
            completed();
            return;
        }

        _authoritativeSettledSnapshot = settledPieces;
        _authoritativeShotNumber = settledShotNumber;
        _authoritativeShotCompleted = completed;
        CanInteract = false;
        ShotStarted?.Invoke();
        _clock.Restart();
        _physicsTimer.Start();
        Invalidate();
    }

    protected override void OnMouseDown(MouseEventArgs e)
    {
        base.OnMouseDown(e);
        if (e.Button != MouseButtons.Left || BoardBounds.Width <= 0 || _engine.IsShotInProgress || !CanInteract)
        {
            return;
        }
        Focus();
        var point = ToBoardPoint(e.Location);
        var striker = _engine.Striker.Position;
        if (Vector2.Distance(point, striker) <= _engine.Striker.Radius + 16F)
        {
            _aimingShot = true;
            _aimPullPoint = point;
            Invalidate();
            return;
        }

        if (point.Y >= 775F && point.Y <= 870F && point.X is >= 210F and <= 790F)
        {
            if (_engine.TryPlaceStriker(point.X))
            {
                _positioningStriker = true;
                _invalidPlacement = false;
                Invalidate();
            }
            else
            {
                InvalidPlacement?.Invoke();
            }
        }
    }

    protected override void OnMouseMove(MouseEventArgs e)
    {
        base.OnMouseMove(e);
        if (_positioningStriker)
        {
            _invalidPlacement = !_engine.TryPlaceStriker(ToBoardPoint(e.Location).X);
            Invalidate();
        }
        else if (_aimingShot)
        {
            _aimPullPoint = ToBoardPoint(e.Location);
            Invalidate();
        }
    }

    protected override void OnMouseUp(MouseEventArgs e)
    {
        base.OnMouseUp(e);
        _positioningStriker = false;
        if (_invalidPlacement)
        {
            InvalidPlacement?.Invoke();
            _invalidPlacement = false;
        }
        if (!_aimingShot)
        {
            return;
        }

        var strikerPosition = _engine.Striker.Position;
        var shot = new CarromShotInput(strikerPosition.X, _aimPullPoint, _selectedPower);
        _aimingShot = false;
        ShotRequested?.Invoke(shot);
        Invalidate();
    }

    private Vector2 ToBoardPoint(Point point)
    {
        var bounds = BoardBounds;
        return new Vector2((point.X - bounds.X) * 1000F / bounds.Width, (point.Y - bounds.Y) * 1000F / bounds.Height);
    }

    private void PhysicsTimer_Tick(object? sender, EventArgs e)
    {
        var elapsed = _clock.Elapsed;
        _clock.Restart();
        var result = _engine.Advance(elapsed);
        UpdatePocketEffects(elapsed);
        Invalidate();
        if (result is not null)
        {
            _physicsTimer.Stop();
            _clock.Stop();
            if (_authoritativeSettledSnapshot is { } authoritative)
            {
                var settledShotNumber = _authoritativeShotNumber;
                var completed = _authoritativeShotCompleted;
                _authoritativeSettledSnapshot = null;
                _authoritativeShotCompleted = null;
                _engine.RestoreSnapshot(authoritative, settledShotNumber);
                Invalidate();
                completed?.Invoke();
                return;
            }
            ShotCompleted?.Invoke(result);
        }
        if (!_engine.IsShotInProgress && _pocketEffects.Count == 0)
        {
            _physicsTimer.Stop();
            _clock.Stop();
        }
    }

    private void HandlePiecePocketed(CarromPiece piece)
    {
        _pocketEffects.Add(new PocketEffect(piece.Position, TimeSpan.FromMilliseconds(420)));
    }

    private void UpdatePocketEffects(TimeSpan elapsed)
    {
        for (var index = _pocketEffects.Count - 1; index >= 0; index--)
        {
            _pocketEffects[index].Remaining -= elapsed;
            if (_pocketEffects[index].Remaining <= TimeSpan.Zero)
            {
                _pocketEffects.RemoveAt(index);
            }
        }
    }

    protected override void Dispose(bool disposing)
    {
        if (disposing)
        {
            _physicsTimer.Stop();
            _clock.Stop();
            _physicsTimer.Dispose();
            _engine.PiecePocketed -= HandlePiecePocketed;
        }
        base.Dispose(disposing);
    }

    private void DrawBoard(Graphics graphics)
    {
        var outer = new RectangleF(20, 20, 960, 960);
        using (var shadow = new SolidBrush(Color.FromArgb(180, 0, 0, 0)))
        using (var shadowPath = RoundedRectangle(new RectangleF(31, 35, 938, 938), 46))
        {
            graphics.FillPath(shadow, shadowPath);
        }
        using (var frameBrush = new LinearGradientBrush(outer, Color.FromArgb(88, 55, 142), Color.FromArgb(33, 155, 190), 40F))
        using (var framePath = RoundedRectangle(outer, 50))
        using (var frameGlow = new Pen(Color.FromArgb(190, 87, 206, 244), 7F))
        {
            graphics.FillPath(frameBrush, framePath);
            graphics.DrawPath(frameGlow, framePath);
        }

        var wood = new RectangleF(76, 76, 848, 848);
        using (var woodPath = RoundedRectangle(wood, 20))
        using (var woodBrush = new LinearGradientBrush(wood, Color.FromArgb(217, 171, 119), Color.FromArgb(154, 101, 69), 35F))
        using (var border = new Pen(Color.FromArgb(238, 241, 197, 138), 5F))
        {
            graphics.FillPath(woodBrush, woodPath);
            graphics.DrawPath(border, woodPath);
        }

        var play = new RectangleF(126, 126, 748, 748);
        var state = graphics.Save();
        using (var clip = RoundedRectangle(play, 8))
        {
            graphics.SetClip(clip);
            using var grain = new LinearGradientBrush(play, Color.FromArgb(226, 190, 145), Color.FromArgb(206, 160, 116), 90F);
            graphics.FillRectangle(grain, play);
            using var grainPen = new Pen(Color.FromArgb(17, 103, 65, 45), 2F);
            for (var y = 158; y < 880; y += 34)
            {
                graphics.DrawLine(grainPen, 130, y, 870, y + 7);
            }
        }
        graphics.Restore(state);

        using var marking = new Pen(Color.FromArgb(164, 79, 45, 50), 4F);
        using var fineMarking = new Pen(Color.FromArgb(150, 112, 65, 67), 2.5F);
        using var neon = new Pen(Color.FromArgb(170, 67, 220, 232), 3F);
        using var softNeon = new Pen(Color.FromArgb(88, 67, 220, 232), 2F);
        graphics.DrawRectangle(marking, play.X, play.Y, play.Width, play.Height);
        graphics.DrawEllipse(marking, 354, 354, 292, 292);
        graphics.DrawEllipse(fineMarking, 407, 407, 186, 186);
        graphics.DrawEllipse(softNeon, 474, 474, 52, 52);
        graphics.DrawEllipse(fineMarking, 437, 437, 126, 126);
        graphics.DrawEllipse(fineMarking, 467, 467, 66, 66);

        DrawBaseline(graphics, 210, 812, marking, fineMarking);
        DrawBaseline(graphics, 790, 188, marking, fineMarking);
        DrawBaseline(graphics, 188, 210, marking, fineMarking, vertical: true);
        DrawBaseline(graphics, 812, 790, marking, fineMarking, vertical: true);

        var pocketCenters = new[]
        {
            new PointF(107, 107), new PointF(893, 107),
            new PointF(107, 893), new PointF(893, 893)
        };
        foreach (var pocket in pocketCenters)
        {
            using var pocketGlow = new SolidBrush(Color.FromArgb(65, 44, 225, 238));
            using var pocketShadow = new SolidBrush(Color.FromArgb(235, 21, 19, 34));
            using var pocketRim = new Pen(Color.FromArgb(207, 63, 206, 229), 7F);
            graphics.FillEllipse(pocketGlow, pocket.X - 54, pocket.Y - 54, 108, 108);
            graphics.FillEllipse(pocketShadow, pocket.X - 39, pocket.Y - 39, 78, 78);
            graphics.DrawEllipse(pocketRim, pocket.X - 39, pocket.Y - 39, 78, 78);
        }

        foreach (var piece in _engine.Pieces)
        {
            if (!piece.IsActive)
            {
                continue;
            }

            var position = piece.Position;
            switch (piece.Type)
            {
                case CarromPieceType.Black:
                    DrawCoin(graphics, position.X, position.Y, piece.Radius, Color.FromArgb(35, 34, 49), Color.FromArgb(146, 151, 176));
                    break;
                case CarromPieceType.White:
                    DrawCoin(graphics, position.X, position.Y, piece.Radius, Color.FromArgb(244, 241, 232), Color.FromArgb(255, 255, 255));
                    break;
                case CarromPieceType.Queen:
                    DrawCoin(graphics, position.X, position.Y, piece.Radius, Color.FromArgb(181, 50, 84), Color.FromArgb(255, 190, 213));
                    break;
                case CarromPieceType.Striker:
                    DrawStriker(graphics, position.X, position.Y);
                    break;
            }
        }

        DrawPocketEffects(graphics);

        using var baselineGlow = new Pen(Color.FromArgb(80, 52, 226, 235), 10F);
        graphics.DrawLine(baselineGlow, 210, 812, 790, 812);
        graphics.DrawLine(neon, 210, 812, 790, 812);
        graphics.DrawLine(softNeon, 210, 188, 790, 188);
    }

    private static void DrawBaseline(Graphics graphics, float x, float y, Pen outer, Pen inner, bool vertical = false)
    {
        var radius = 30F;
        if (vertical)
        {
            graphics.DrawLine(outer, x, 210, x, 790);
            graphics.DrawEllipse(inner, x - radius, y - radius, radius * 2, radius * 2);
            graphics.DrawEllipse(inner, x - radius, 1000 - y - radius, radius * 2, radius * 2);
        }
        else
        {
            graphics.DrawLine(outer, 210, y, 790, y);
            graphics.DrawEllipse(inner, x - radius, y - radius, radius * 2, radius * 2);
            graphics.DrawEllipse(inner, 1000 - x - radius, y - radius, radius * 2, radius * 2);
        }
    }

    private void DrawPocketEffects(Graphics graphics)
    {
        foreach (var effect in _pocketEffects)
        {
            var progress = 1F - (float)(effect.Remaining.TotalMilliseconds / 420F);
            var radius = 18F + 44F * progress;
            var alpha = (int)(190F * (1F - progress));
            using var pen = new Pen(Color.FromArgb(Math.Clamp(alpha, 0, 255), Cyan), 5F * (1F - progress * 0.6F));
            graphics.DrawEllipse(pen, effect.Position.X - radius, effect.Position.Y - radius, radius * 2, radius * 2);
        }
    }

    private static void DrawCoin(Graphics graphics, float centerX, float centerY, float radius, Color color, Color edge)
    {
        var bounds = new RectangleF(centerX - radius, centerY - radius, radius * 2, radius * 2);
        using var shadow = new SolidBrush(Color.FromArgb(95, 31, 22, 23));
        using var coin = new LinearGradientBrush(bounds, ControlPaint.Light(color, 0.25F), color, 45F);
        using var rim = new Pen(Color.FromArgb(220, edge), 3F);
        using var innerRim = new Pen(Color.FromArgb(95, edge), 1.4F);
        graphics.FillEllipse(shadow, bounds.X + 3, bounds.Y + 5, bounds.Width, bounds.Height);
        graphics.FillEllipse(coin, bounds);
        graphics.DrawEllipse(rim, bounds);
        graphics.DrawEllipse(innerRim, bounds.X + 5, bounds.Y + 5, bounds.Width - 10, bounds.Height - 10);
    }

    private void DrawStriker(Graphics graphics, float centerX, float centerY)
    {
        if (_aimingShot)
        {
            var direction = new Vector2(centerX, centerY) - _aimPullPoint;
            if (direction.LengthSquared() > 0.001F)
            {
                direction = Vector2.Normalize(direction);
                var pullDistance = Vector2.Distance(new Vector2(centerX, centerY), _aimPullPoint);
                var shotPower = CarromPhysicsEngine.GetShotPower(pullDistance, _selectedPower);
                var guideLength = 140F + 260F * shotPower;
                var aim = new PointF(centerX + direction.X * guideLength, centerY + direction.Y * guideLength);
                using var aimPen = new Pen(Color.FromArgb(212, Cyan), 5F)
                {
                    DashStyle = DashStyle.Dash,
                    StartCap = LineCap.Round,
                    EndCap = LineCap.Round
                };
                graphics.DrawLine(aimPen, centerX, centerY, aim.X, aim.Y);
                using var target = new Pen(Color.FromArgb(220, Cyan), 4F);
                graphics.DrawEllipse(target, aim.X - 12, aim.Y - 12, 24, 24);
            }

            using var pullPen = new Pen(Color.FromArgb(150, 145, 92, 246), 3F) { DashStyle = DashStyle.Dot };
            graphics.DrawLine(pullPen, centerX, centerY, _aimPullPoint.X, _aimPullPoint.Y);
        }

        var bounds = new RectangleF(centerX - 36, centerY - 36, 72, 72);
        using var glow = new SolidBrush(Color.FromArgb(55, Cyan));
        using var striker = new LinearGradientBrush(bounds, Color.FromArgb(177, 235, 255), Color.FromArgb(74, 135, 214), 45F);
        using var outline = new Pen(Color.FromArgb(245, 205, 250, 255), 5F);
        using var detail = new Pen(Color.FromArgb(220, 74, 51, 117), 3F);
        graphics.FillEllipse(glow, bounds.X - 14, bounds.Y - 14, bounds.Width + 28, bounds.Height + 28);
        graphics.FillEllipse(striker, bounds);
        graphics.DrawEllipse(outline, bounds);
        graphics.DrawEllipse(detail, bounds.X + 12, bounds.Y + 12, bounds.Width - 24, bounds.Height - 24);
    }

    private sealed class PocketEffect(Vector2 position, TimeSpan remaining)
    {
        internal Vector2 Position { get; } = position;
        internal TimeSpan Remaining { get; set; } = remaining;
    }

    private static GraphicsPath RoundedRectangle(RectangleF bounds, float radius)
    {
        var path = new GraphicsPath();
        var diameter = radius * 2;
        path.AddArc(bounds.X, bounds.Y, diameter, diameter, 180, 90);
        path.AddArc(bounds.Right - diameter, bounds.Y, diameter, diameter, 270, 90);
        path.AddArc(bounds.Right - diameter, bounds.Bottom - diameter, diameter, diameter, 0, 90);
        path.AddArc(bounds.X, bounds.Bottom - diameter, diameter, diameter, 90, 90);
        path.CloseFigure();
        return path;
    }
}
