using WiFiGameHub.Games.Chess;
using WiFiGameHub.Networking;
using WiFiGameHub.Services;

namespace WiFiGameHub.Forms;

public sealed class ChessForm : Form
{
    private static readonly Color Canvas = Color.FromArgb(15, 16, 28);
    private static readonly Color Surface = Color.FromArgb(27, 28, 45);
    private static readonly Color MutedText = Color.FromArgb(158, 165, 190);
    private static readonly Color Purple = Color.FromArgb(145, 92, 246);
    private static readonly Color Blue = Color.FromArgb(69, 150, 255);
    private readonly MultiplayerSession? _session;
    private readonly Action? _onExit;
    private readonly ChessBoardControl _board;
    private readonly ChessGame _game = new();
    private readonly Label _status = new();
    private readonly Label _mode = new();
    private readonly Label _whitePlayer = new();
    private readonly Label _blackPlayer = new();
    private readonly Label _whiteTurn = new();
    private readonly Label _blackTurn = new();
    private readonly Panel _whitePlayerCard = new();
    private readonly Panel _blackPlayerCard = new();
    private readonly Label _moveCount = new();
    private readonly ListBox _history = new();
    private readonly ComboBox _promotion = new();
    private readonly Button _newGame = new();
    private readonly Button _exit = new();
    private (int Row, int Column)? _selectedSquare;
    private int _lastSoundedMoveCount;
    private long _lastDepartureSequence;
    private string _departureMessage = string.Empty;

    public ChessForm(MultiplayerSession? session = null, Action? onExit = null)
    {
        _session = session;
        _onExit = onExit;
        Text = "Chess";
        BackColor = Canvas;
        ForeColor = Color.White;
        FormBorderStyle = FormBorderStyle.None;
        Dock = DockStyle.Fill;
        Padding = new Padding(12);

        _board = new ChessBoardControl(_game);
        _board.SquareClicked += Board_SquareClicked;
        _board.Margin = new Padding(0, 0, 12, 0);

        var root = new TableLayoutPanel
        {
            Dock = DockStyle.Fill,
            ColumnCount = 2,
            RowCount = 1,
            BackColor = Canvas,
            Padding = Padding.Empty
        };
        root.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 64));
        root.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 36));

        var side = new TableLayoutPanel
        {
            Dock = DockStyle.Fill,
            ColumnCount = 1,
            RowCount = 6,
            BackColor = Surface,
            Padding = new Padding(14),
            Margin = Padding.Empty
        };
        side.RowStyles.Add(new RowStyle(SizeType.Absolute, 66));
        side.RowStyles.Add(new RowStyle(SizeType.Absolute, 70));
        side.RowStyles.Add(new RowStyle(SizeType.Absolute, 100));
        side.RowStyles.Add(new RowStyle(SizeType.Absolute, 48));
        side.RowStyles.Add(new RowStyle(SizeType.Absolute, 34));
        side.RowStyles.Add(new RowStyle(SizeType.Percent, 100));

        var heading = new Panel { Dock = DockStyle.Fill };
        heading.Controls.Add(new Label
        {
            Text = "CHESS",
            ForeColor = Color.White,
            Font = new Font("Segoe UI", 19F, FontStyle.Bold),
            AutoSize = true,
            Location = new Point(0, 0)
        });
        _mode.Text = "Local game";
        _mode.ForeColor = MutedText;
        _mode.Font = new Font("Segoe UI", 8.5F, FontStyle.Bold);
        _mode.AutoSize = true;
        _mode.Location = new Point(2, 37);
        heading.Controls.Add(_mode);
        _exit.Text = "Exit";
        StyleButton(_exit, Color.FromArgb(39, 38, 58));
        _exit.Size = new Size(62, 30);
        _exit.Dock = DockStyle.None;
        _exit.Enabled = _onExit is not null;
        _exit.Anchor = AnchorStyles.Top | AnchorStyles.Right;
        _exit.Location = new Point(heading.Width - _exit.Width, 8);
        _exit.Click += async (_, _) => await LeaveAndExitAsync();
        heading.Resize += (_, _) => _exit.Left = heading.ClientSize.Width - _exit.Width;
        heading.Controls.Add(_exit);

        var turnPanel = new Panel
        {
            Dock = DockStyle.Fill,
            BackColor = Color.FromArgb(35, 31, 54),
            Padding = new Padding(12, 8, 12, 8)
        };
        _status.Dock = DockStyle.Fill;
        _status.Font = new Font("Segoe UI", 11.5F, FontStyle.Bold);
        _status.ForeColor = Color.White;
        _status.TextAlign = ContentAlignment.MiddleLeft;
        _status.AutoEllipsis = true;
        turnPanel.Controls.Add(_status);

        var players = new TableLayoutPanel { Dock = DockStyle.Fill, ColumnCount = 1, RowCount = 2, BackColor = Surface, Padding = new Padding(0, 6, 0, 2) };
        players.RowStyles.Add(new RowStyle(SizeType.Percent, 50));
        players.RowStyles.Add(new RowStyle(SizeType.Percent, 50));
        _whitePlayerCard.Controls.Add(CreatePlayerCardContent(_whitePlayer, _whiteTurn, "WHITE", Color.FromArgb(245, 239, 223)));
        _blackPlayerCard.Controls.Add(CreatePlayerCardContent(_blackPlayer, _blackTurn, "BLACK", Color.FromArgb(166, 157, 202)));
        StylePlayerCard(_whitePlayerCard, new Padding(0, 0, 0, 4));
        StylePlayerCard(_blackPlayerCard, new Padding(0, 4, 0, 0));
        players.Controls.Add(_whitePlayerCard, 0, 0);
        players.Controls.Add(_blackPlayerCard, 0, 1);

        var actions = new TableLayoutPanel { Dock = DockStyle.Fill, ColumnCount = 2, RowCount = 1, BackColor = Surface };
        actions.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 58));
        actions.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 42));
        _newGame.Text = "Restart Match";
        StyleButton(_newGame, Purple);
        _newGame.Click += async (_, _) => await StartNewGameAsync();
        _promotion.DropDownStyle = ComboBoxStyle.DropDownList;
        _promotion.Items.AddRange(new object[] { "Queen", "Rook", "Bishop", "Knight" });
        _promotion.SelectedIndex = 0;
        _promotion.BackColor = Color.FromArgb(20, 21, 36);
        _promotion.ForeColor = Color.White;
        _promotion.Font = new Font("Segoe UI", 9F);
        _promotion.Dock = DockStyle.Fill;
        actions.Controls.Add(_newGame, 0, 0);
        actions.Controls.Add(_promotion, 1, 0);
        _whitePlayer.Text = "Player 1";
        _blackPlayer.Text = "Player 2";

        _moveCount.Dock = DockStyle.Fill;
        _moveCount.Font = new Font("Segoe UI", 8.5F, FontStyle.Bold);
        _moveCount.ForeColor = MutedText;
        _moveCount.TextAlign = ContentAlignment.MiddleLeft;

        var tabs = new TabControl
        {
            Dock = DockStyle.Fill,
            Font = new Font("Segoe UI", 9F, FontStyle.Bold),
            DrawMode = TabDrawMode.OwnerDrawFixed,
            SizeMode = TabSizeMode.Fixed,
            ItemSize = new Size(100, 30)
        };
        tabs.DrawItem += (_, eventArgs) => DrawTabHeader(tabs, eventArgs);
        var historyTab = new TabPage("Move History") { BackColor = Surface, Padding = new Padding(5) };
        var chatTab = new TabPage("Chat") { BackColor = Surface, Padding = new Padding(2) };
        _history.Dock = DockStyle.Fill;
        _history.BackColor = Color.FromArgb(19, 20, 34);
        _history.ForeColor = Color.FromArgb(227, 228, 241);
        _history.BorderStyle = BorderStyle.None;
        _history.Font = new Font("Segoe UI", 9.5F);
        historyTab.Controls.Add(_history);
        chatTab.Controls.Add(new GameChatPanel(_session));
        tabs.TabPages.Add(historyTab);
        tabs.TabPages.Add(chatTab);

        side.Controls.Add(heading, 0, 0);
        side.Controls.Add(turnPanel, 0, 1);
        side.Controls.Add(players, 0, 2);
        side.Controls.Add(actions, 0, 3);
        side.Controls.Add(_moveCount, 0, 4);
        side.Controls.Add(tabs, 0, 5);
        var boardPanel = new Panel
        {
            Dock = DockStyle.Fill,
            BackColor = Color.FromArgb(19, 20, 33),
            Padding = new Padding(4),
            Margin = new Padding(0, 0, 10, 0)
        };
        boardPanel.Controls.Add(_board);
        root.Controls.Add(boardPanel, 0, 0);
        root.Controls.Add(side, 1, 0);
        Controls.Add(root);

        RefreshGame();
        if (_session is not null)
        {
            _session.StateChanged += Session_StateChanged;
            _session.StatusChanged += Session_StatusChanged;
            _session.ConnectionChanged += Session_ConnectionChanged;
            Disposed += (_, _) =>
            {
                _session.StateChanged -= Session_StateChanged;
                _session.StatusChanged -= Session_StatusChanged;
                _session.ConnectionChanged -= Session_ConnectionChanged;
            };
            if (_session.CurrentState is { Game: "Chess" } state)
            {
                ApplyNetworkState(state);
            }
        }
    }

    private async void Board_SquareClicked(int row, int column)
    {
        if (_session?.CurrentState is { Game: "Chess", IsGameOver: true } endedState)
        {
            _status.Text = endedState.IsForfeit ? _departureMessage : "The match is over.";
            return;
        }
        if (_game.IsGameOver)
        {
            return;
        }
        var multiplayer = _session?.IsActive == true && _session.Game == "Chess";
        if (multiplayer)
        {
            var state = _session!.CurrentState;
            if (state?.Started != true)
            {
                _status.Text = "Waiting for another player to join";
                return;
            }
            if (state.CurrentPlayerId != _session.LocalPlayerId)
            {
                _status.Text = $"Waiting for {state.CurrentPlayerMark}";
                return;
            }
        }

        var board = _game.Board;
        if (_selectedSquare is { } selected && _game.GetLegalMoves(selected.Row, selected.Column).Contains((row, column)))
        {
            if (multiplayer)
            {
                try
                {
                    await _session!.SendActionAsync(new GameActionRequest
                    {
                        Action = "chess-move",
                        FromRow = selected.Row,
                        FromColumn = selected.Column,
                        Row = row,
                        Column = column,
                        Promotion = SelectedPromotion()
                    });
                }
                catch (Exception exception) when (exception is IOException or InvalidOperationException or OperationCanceledException)
                {
                    _status.Text = $"Move failed: {exception.Message}";
                }
                ClearSelection();
                return;
            }

            if (_game.TryMove(selected.Row, selected.Column, row, column, SelectedPromotion()))
            {
                GameAudio.PlayMove();
                if (_game.IsGameOver && !_game.IsDraw) GameAudio.PlayWin();
                ClearSelection();
                RefreshGame();
                return;
            }
        }

        if (board[row, column] != '\0' && char.IsUpper(board[row, column]) == (_game.CurrentTurn == ChessSide.White))
        {
            _selectedSquare = (row, column);
            _board.SelectedSquare = _selectedSquare;
            _board.LegalTargets = _game.GetLegalMoves(row, column);
        }
        else
        {
            ClearSelection();
        }
        _board.Invalidate();
    }

    private async Task StartNewGameAsync()
    {
        if (_session?.IsActive == true && _session.Game == "Chess")
        {
            if (!_session.IsHost)
            {
                _status.Text = "Only the room host can start a new game";
                return;
            }
            try
            {
                await _session.SendActionAsync(new GameActionRequest { Action = "restart" });
            }
            catch (Exception exception) when (exception is IOException or InvalidOperationException or OperationCanceledException)
            {
                _status.Text = $"Could not restart: {exception.Message}";
            }
            return;
        }

        _game.LoadFen("rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR w KQkq - 0 1");
        _lastSoundedMoveCount = 0;
        ClearSelection();
        RefreshGame();
    }

    private void Session_StateChanged(GameSessionState state)
    {
        if (InvokeRequired)
        {
            BeginInvoke(() => Session_StateChanged(state));
            return;
        }
        if (state.Game == "Chess")
        {
            ApplyNetworkState(state);
        }
    }

    private void ApplyNetworkState(GameSessionState state)
    {
        if (state.Game != "Chess" || string.IsNullOrEmpty(state.ChessFen))
        {
            return;
        }
        try
        {
            _game.LoadFen(state.ChessFen, state.MoveHistory);
        }
        catch (ArgumentException exception)
        {
            _status.Text = $"Invalid room position: {exception.Message}";
            return;
        }

        if (state.MoveHistory.Length < _lastSoundedMoveCount)
        {
            _lastSoundedMoveCount = 0;
        }
        if (state.MoveHistory.Length > _lastSoundedMoveCount)
        {
            GameAudio.PlayMove();
            if (state.IsGameOver && !state.IsDraw) GameAudio.PlayWin();
            _lastSoundedMoveCount = state.MoveHistory.Length;
        }

        var white = state.Players.FirstOrDefault(player => player.Connected && player.Mark == "White")
            ?? state.Players.FirstOrDefault(player => player.Mark == "White");
        var black = state.Players.FirstOrDefault(player => player.Connected && player.Mark == "Black")
            ?? state.Players.FirstOrDefault(player => player.Mark == "Black");
        _whitePlayer.Text = white is null ? "Waiting for player" : white.Connected ? white.Name : $"{white.Name} · LEFT";
        _blackPlayer.Text = black is null ? "Waiting for player" : black.Connected ? black.Name : $"{black.Name} · LEFT";
        _newGame.Enabled = _session?.IsHost == true && !state.IsForfeit;
        if (state.DepartureSequence > _lastDepartureSequence)
        {
            _lastDepartureSequence = state.DepartureSequence;
            _departureMessage = BuildDepartureMessage(state);
        }
        _mode.Text = _session?.IsHost == true ? "Room host" : "Online match";
        ClearSelection();
        RefreshGame(state.Started);
    }

    private void Session_StatusChanged(string message)
    {
        if (InvokeRequired)
        {
            BeginInvoke(() => Session_StatusChanged(message));
            return;
        }
        if (_session?.IsActive == true && _session.Game == "Chess" && message.StartsWith("Connection failed:", StringComparison.OrdinalIgnoreCase))
        {
            _status.Text = message;
        }
    }

    private void Session_ConnectionChanged(bool connected)
    {
        if (InvokeRequired)
        {
            BeginInvoke(() => Session_ConnectionChanged(connected));
            return;
        }
        if (!connected && _session?.Game == "Chess")
        {
            _mode.Text = "Local game";
            _newGame.Enabled = _session.CurrentState?.IsForfeit != true;
            ClearSelection();
            RefreshGame();
            if (_session.CurrentState?.IsForfeit != true)
            {
                _status.Text = "Connection lost. Local Play is available.";
            }
        }
    }

    private void RefreshGame(bool started = true)
    {
        _board.Game = _game;
        _board.Invalidate();
        if (_session?.CurrentState is { Game: "Chess", IsForfeit: true })
        {
            _status.Text = _departureMessage;
        }
        else if (_session?.IsActive == true && _session.Game == "Chess" && !started)
        {
            _status.Text = "Waiting for another player to join";
        }
        else if (_game.IsGameOver)
        {
            _status.Text = _game.IsStalemate
                ? "STALEMATE  ·  Draw"
                : _game.IsDraw
                    ? "DRAW  ·  Match complete"
                    : $"CHECKMATE  ·  {_game.Winner} wins";
        }
        else if (_game.IsCheck)
        {
            _status.Text = $"CHECK  ·  {_game.CurrentTurn} to move";
        }
        else
        {
            var yourTurn = _session?.IsActive == true && _session.Game == "Chess"
                ? _session.CurrentState?.CurrentPlayerId == _session.LocalPlayerId
                : true;
            _status.Text = yourTurn ? $"YOUR TURN  ·  {_game.CurrentTurn}" : $"WAITING FOR  ·  {_game.CurrentTurn}";
        }

        UpdatePlayerIndicators(started);
        _moveCount.Text = $"MOVES PLAYED  ·  {_game.MoveHistory.Count}";
        _history.BeginUpdate();
        _history.Items.Clear();
        for (var index = 0; index < _game.MoveHistory.Count; index += 2)
        {
            var whiteMove = _game.MoveHistory[index];
            var blackMove = index + 1 < _game.MoveHistory.Count ? _game.MoveHistory[index + 1] : "…";
            _history.Items.Add($"{index / 2 + 1,2}.  {whiteMove,-12} {blackMove}");
        }
        if (_history.Items.Count > 0) _history.TopIndex = _history.Items.Count - 1;
        _history.EndUpdate();
    }

    private string BuildDepartureMessage(GameSessionState state)
    {
        var departed = string.IsNullOrWhiteSpace(state.LastDepartedPlayerName)
            ? "A player"
            : $"Player {state.LastDepartedPlayerName}";
        if (!state.IsForfeit)
        {
            return $"{departed} has left the game.";
        }

        var winner = state.Players.FirstOrDefault(player => player.PlayerId == state.WinnerId)?.Name ?? state.WinnerName;
        return state.WinnerId == _session?.LocalPlayerId
            ? $"{departed} has left the game. You Won!"
            : $"{departed} has left the game. {winner} wins!";
    }

    private async Task LeaveAndExitAsync()
    {
        if (_session?.IsActive == true && _session.Game == "Chess")
        {
            try
            {
                await _session.LeaveGameAsync();
            }
            catch (Exception exception) when (exception is IOException or InvalidOperationException or OperationCanceledException or ObjectDisposedException)
            {
                MessageBox.Show(this, $"Could not notify the room before leaving: {exception.Message}", Text,
                    MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }
        _onExit?.Invoke();
    }

    private void ClearSelection()
    {
        _selectedSquare = null;
        _board.SelectedSquare = null;
        _board.LegalTargets = Array.Empty<(int Row, int Column)>();
        _board.Invalidate();
    }

    private char SelectedPromotion() => _promotion.SelectedIndex switch
    {
        1 => 'R',
        2 => 'B',
        3 => 'N',
        _ => 'Q'
    };

    private static Control CreatePlayerCardContent(Label player, Label turn, string side, Color pieceColor)
    {
        var layout = new TableLayoutPanel
        {
            Dock = DockStyle.Fill,
            ColumnCount = 2,
            RowCount = 2,
            BackColor = Color.Transparent,
            Margin = Padding.Empty,
            Padding = new Padding(12, 4, 10, 4)
        };
        layout.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 68));
        layout.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 32));
        layout.RowStyles.Add(new RowStyle(SizeType.Percent, 42));
        layout.RowStyles.Add(new RowStyle(SizeType.Percent, 58));
        layout.Controls.Add(new Label
        {
            Text = side,
            Dock = DockStyle.Fill,
            ForeColor = pieceColor,
            Font = new Font("Segoe UI", 7.5F, FontStyle.Bold),
            TextAlign = ContentAlignment.MiddleLeft,
            BackColor = Color.Transparent
        }, 0, 0);
        player.Dock = DockStyle.Fill;
        player.Font = new Font("Segoe UI", 9.5F, FontStyle.Bold);
        player.ForeColor = Color.White;
        player.TextAlign = ContentAlignment.MiddleLeft;
        player.AutoEllipsis = true;
        player.BackColor = Color.Transparent;
        layout.Controls.Add(player, 0, 1);
        turn.Text = "TO MOVE";
        turn.Dock = DockStyle.Fill;
        turn.ForeColor = Color.FromArgb(205, 184, 255);
        turn.Font = new Font("Segoe UI", 7F, FontStyle.Bold);
        turn.TextAlign = ContentAlignment.MiddleRight;
        turn.Visible = false;
        turn.BackColor = Color.Transparent;
        layout.Controls.Add(turn, 1, 0);
        layout.SetRowSpan(turn, 2);
        return layout;
    }

    private static void StylePlayerCard(Panel card, Padding margin)
    {
        card.Dock = DockStyle.Fill;
        card.BackColor = Color.FromArgb(21, 22, 37);
        card.Margin = margin;
        card.Padding = Padding.Empty;
        card.BorderStyle = BorderStyle.FixedSingle;
    }

    private void UpdatePlayerIndicators(bool started = true)
    {
        var active = started && !_game.IsGameOver;
        var whiteToMove = active && _game.CurrentTurn == ChessSide.White;
        var blackToMove = active && _game.CurrentTurn == ChessSide.Black;
        _whiteTurn.Visible = whiteToMove;
        _blackTurn.Visible = blackToMove;
        _whitePlayerCard.BackColor = whiteToMove ? Color.FromArgb(45, 37, 61) : Color.FromArgb(21, 22, 37);
        _blackPlayerCard.BackColor = blackToMove ? Color.FromArgb(37, 36, 61) : Color.FromArgb(21, 22, 37);
        _whitePlayerCard.Padding = whiteToMove ? new Padding(2) : Padding.Empty;
        _blackPlayerCard.Padding = blackToMove ? new Padding(2) : Padding.Empty;
    }

    private static void DrawTabHeader(TabControl tabs, DrawItemEventArgs e)
    {
        var selected = e.Index == tabs.SelectedIndex;
        using var background = new SolidBrush(selected ? Color.FromArgb(51, 39, 75) : Surface);
        using var text = new SolidBrush(selected ? Color.White : MutedText);
        e.Graphics.FillRectangle(background, e.Bounds);
        TextRenderer.DrawText(
            e.Graphics,
            tabs.TabPages[e.Index].Text,
            tabs.Font,
            e.Bounds,
            text.Color,
            TextFormatFlags.HorizontalCenter | TextFormatFlags.VerticalCenter | TextFormatFlags.EndEllipsis);
        if (selected)
        {
            using var accent = new Pen(Purple, 2F);
            e.Graphics.DrawLine(accent, e.Bounds.Left + 12, e.Bounds.Bottom - 2, e.Bounds.Right - 12, e.Bounds.Bottom - 2);
        }
    }

    private static void StyleButton(Button button, Color color)
    {
        button.BackColor = color;
        button.ForeColor = Color.White;
        button.FlatStyle = FlatStyle.Flat;
        button.FlatAppearance.BorderSize = 0;
        button.Font = new Font("Segoe UI", 9F, FontStyle.Bold);
        button.Cursor = Cursors.Hand;
        button.Dock = DockStyle.Fill;
        button.Margin = new Padding(2);
        button.FlatAppearance.MouseOverBackColor = ControlPaint.Light(color, 0.12F);
    }
}
