using WiFiGameHub.Games.TicTacToe;
using WiFiGameHub.Services;
using WiFiGameHub.Networking;

namespace WiFiGameHub.Forms;

public class TicTacToeForm : Form
{
    private static readonly Color Canvas = Color.FromArgb(15, 16, 28);
    private static readonly Color Surface = Color.FromArgb(27, 28, 45);
    private static readonly Color Card = Color.FromArgb(21, 22, 38);
    private static readonly Color MutedText = Color.FromArgb(158, 165, 190);
    private static readonly Color Purple = Color.FromArgb(145, 92, 246);
    private static readonly Color Blue = Color.FromArgb(69, 150, 255);
    private readonly TicTacToeGame _game = new();
    private readonly TicTacToeCellButton[,] _cells = new TicTacToeCellButton[3, 3];
    private readonly Label _statusLabel = new();
    private readonly Label _scoreLabel = new();
    private readonly Label _xPlayerLabel = new();
    private readonly Label _oPlayerLabel = new();
    private readonly Label _modeLabel = new();
    private readonly TextBox _xName = new();
    private readonly TextBox _oName = new();
    private readonly MultiplayerSession? _session;
    private readonly Action? _onExit;
    private readonly Panel _boardHost = new();
    private Button _restartButton = null!;
    private Button _newMatchButton = null!;
    private Button _renameButton = null!;
    private Button _exitButton = null!;
    private long _lastDepartureSequence;
    private string _departureMessage = string.Empty;

    public TicTacToeForm(MultiplayerSession? session = null, Action? onExit = null)
    {
        _session = session;
        _onExit = onExit;
        Text = "Tic Tac Toe";
        BackColor = Canvas;
        ForeColor = Color.White;
        FormBorderStyle = FormBorderStyle.None;
        Dock = DockStyle.Fill;
        Padding = new Padding(14);

        var root = new TableLayoutPanel { Dock = DockStyle.Fill, ColumnCount = 2, RowCount = 1, BackColor = Canvas, Padding = Padding.Empty };
        root.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 66));
        root.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 34));

        var boardPanel = new TableLayoutPanel
        {
            ColumnCount = 3,
            RowCount = 3,
            Padding = new Padding(12),
            BackColor = Color.FromArgb(48, 43, 69),
            Margin = Padding.Empty
        };
        for (var index = 0; index < 3; index++)
        {
            boardPanel.RowStyles.Add(new RowStyle(SizeType.Percent, 33.333F));
            boardPanel.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 33.333F));
        }

        _boardHost.Dock = DockStyle.Fill;
        _boardHost.BackColor = Canvas;
        _boardHost.Margin = new Padding(0, 0, 16, 0);
        _boardHost.Resize += (_, _) => FitBoard(boardPanel);
        _boardHost.Controls.Add(boardPanel);

        for (var row = 0; row < 3; row++)
        {
            for (var column = 0; column < 3; column++)
            {
                var button = new TicTacToeCellButton
                {
                    Dock = DockStyle.Fill,
                    Margin = new Padding(3),
                    Tag = new Point(row, column),
                    Cursor = Cursors.Hand
                };
                button.AccessibleName = $"Row {row + 1}, column {column + 1}";
                button.Click += Cell_Click;
                _cells[row, column] = button;
                boardPanel.Controls.Add(button, column, row);
            }
        }

        var side = new TableLayoutPanel { Dock = DockStyle.Fill, ColumnCount = 1, RowCount = 7, BackColor = Surface, Padding = new Padding(18), Margin = Padding.Empty };
        side.RowStyles.Add(new RowStyle(SizeType.Absolute, 72));
        side.RowStyles.Add(new RowStyle(SizeType.Absolute, 74));
        side.RowStyles.Add(new RowStyle(SizeType.Absolute, 66));
        side.RowStyles.Add(new RowStyle(SizeType.Absolute, 86));
        side.RowStyles.Add(new RowStyle(SizeType.Absolute, 82));
        side.RowStyles.Add(new RowStyle(SizeType.Absolute, 96));
        side.RowStyles.Add(new RowStyle(SizeType.Percent, 100));

        var heading = new Panel { Dock = DockStyle.Fill };
        heading.Controls.Add(new Label { Text = "TIC-TAC-TOE", ForeColor = Color.White, Font = new Font("Segoe UI", 18F, FontStyle.Bold), AutoSize = true, Location = new Point(0, 0) });
        heading.Controls.Add(new Label { Text = "A quick match of X and O", ForeColor = MutedText, Font = new Font("Segoe UI", 8.5F), AutoSize = true, Location = new Point(2, 35) });
        _modeLabel.Text = "LOCAL PLAY";
        _modeLabel.ForeColor = Blue;
        _modeLabel.Font = new Font("Segoe UI", 8.5F, FontStyle.Bold);
        _modeLabel.AutoSize = true;
        _modeLabel.Location = new Point(2, 54);
        heading.Controls.Add(_modeLabel);

        var turnPanel = new Panel { Dock = DockStyle.Fill, BackColor = Color.FromArgb(39, 34, 58), Padding = new Padding(12), Margin = new Padding(0, 2, 0, 2) };
        _statusLabel.Text = "X starts";
        _statusLabel.Dock = DockStyle.Fill;
        _statusLabel.Font = new Font("Segoe UI", 12F, FontStyle.Bold);
        _statusLabel.ForeColor = Color.White;
        _statusLabel.TextAlign = ContentAlignment.MiddleLeft;
        _statusLabel.AutoEllipsis = true;
        turnPanel.Controls.Add(_statusLabel);

        var scorePanel = new Panel { Dock = DockStyle.Fill };
        scorePanel.Controls.Add(new Label { Text = "MATCH SCORE", ForeColor = MutedText, Font = new Font("Segoe UI", 8F, FontStyle.Bold), AutoSize = true, Location = new Point(0, 0) });
        _scoreLabel.Text = "X  0       O  0";
        _scoreLabel.ForeColor = Color.White;
        _scoreLabel.Font = new Font("Segoe UI", 16F, FontStyle.Bold);
        _scoreLabel.AutoSize = true;
        _scoreLabel.Location = new Point(0, 28);
        scorePanel.Controls.Add(_scoreLabel);

        var playerPanel = new TableLayoutPanel { Dock = DockStyle.Fill, ColumnCount = 2, RowCount = 2, BackColor = Surface, Margin = Padding.Empty };
        playerPanel.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 50));
        playerPanel.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 50));
        playerPanel.RowStyles.Add(new RowStyle(SizeType.Absolute, 24));
        playerPanel.RowStyles.Add(new RowStyle(SizeType.Percent, 100));
        playerPanel.Controls.Add(new Label { Text = "PLAYER NAMES", ForeColor = MutedText, Font = new Font("Segoe UI", 8F, FontStyle.Bold), AutoSize = true }, 0, 0);
        playerPanel.SetColumnSpan(playerPanel.Controls[0], 2);
        StyleNameBox(_xName, "Player X");
        StyleNameBox(_oName, "Player O");
        playerPanel.Controls.Add(_xName, 0, 1);
        playerPanel.Controls.Add(_oName, 1, 1);

        var identityPanel = new TableLayoutPanel { Dock = DockStyle.Fill, ColumnCount = 2, RowCount = 1, BackColor = Surface, Margin = Padding.Empty };
        identityPanel.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 50));
        identityPanel.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 50));
        _xPlayerLabel.Text = "X  ·  Player X";
        _oPlayerLabel.Text = "O  ·  Player O";
        _xPlayerLabel.Dock = DockStyle.Fill;
        _oPlayerLabel.Dock = DockStyle.Fill;
        _xPlayerLabel.ForeColor = Blue;
        _oPlayerLabel.ForeColor = Purple;
        _xPlayerLabel.BackColor = Card;
        _oPlayerLabel.BackColor = Card;
        _xPlayerLabel.TextAlign = ContentAlignment.MiddleCenter;
        _oPlayerLabel.TextAlign = ContentAlignment.MiddleCenter;
        _xPlayerLabel.Font = new Font("Segoe UI", 9F, FontStyle.Bold);
        _oPlayerLabel.Font = new Font("Segoe UI", 9F, FontStyle.Bold);
        _xPlayerLabel.AutoEllipsis = true;
        _oPlayerLabel.AutoEllipsis = true;
        _xPlayerLabel.Margin = new Padding(0, 0, 4, 0);
        _oPlayerLabel.Margin = new Padding(4, 0, 0, 0);
        identityPanel.Controls.Add(_xPlayerLabel, 0, 0);
        identityPanel.Controls.Add(_oPlayerLabel, 1, 0);

        var actions = new TableLayoutPanel { Dock = DockStyle.Fill, ColumnCount = 2, RowCount = 2, BackColor = Surface, Padding = new Padding(0, 4, 0, 0) };
        actions.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 50));
        actions.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 50));
        actions.RowStyles.Add(new RowStyle(SizeType.Percent, 50));
        actions.RowStyles.Add(new RowStyle(SizeType.Percent, 50));
        _restartButton = CreateButton("Restart Round", Color.FromArgb(48, 42, 69));
        _restartButton.Click += (_, _) => RestartGame();
        _newMatchButton = CreateButton("New Match", Blue);
        _newMatchButton.Click += (_, _) => NewMatch();
        _renameButton = CreateButton("Save Names", Color.FromArgb(48, 42, 69));
        _renameButton.Click += (_, _) => ApplyNames();
        _exitButton = CreateButton("Exit Game", Color.FromArgb(39, 38, 58));
        _exitButton.Enabled = _onExit is not null;
        _exitButton.Click += async (_, _) => await LeaveAndExitAsync();
        actions.Controls.Add(_restartButton, 0, 0);
        actions.Controls.Add(_newMatchButton, 1, 0);
        actions.Controls.Add(_renameButton, 0, 1);
        actions.Controls.Add(_exitButton, 1, 1);

        side.Controls.Add(heading, 0, 0);
        side.Controls.Add(turnPanel, 0, 1);
        side.Controls.Add(scorePanel, 0, 2);
        side.Controls.Add(playerPanel, 0, 3);
        side.Controls.Add(identityPanel, 0, 4);
        side.Controls.Add(actions, 0, 5);
        side.Controls.Add(new GameChatPanel(_session), 0, 6);
        root.Controls.Add(_boardHost, 0, 0);
        root.Controls.Add(side, 1, 0);
        Controls.Add(root);
        FitBoard(boardPanel);
        RefreshBoard();
        if (_session is not null)
        {
            _session.StateChanged += Session_StateChanged;
            _session.StatusChanged += Session_StatusChanged;
            _session.ConnectionChanged += Session_ConnectionChanged;
            Disposed += (_, _) =>
            {
                _session.StateChanged -= Session_StateChanged;
                _session.StatusChanged -= Session_StatusChanged;
                _session.ConnectionChanged -= Session_ConnectionChanged;
            };
            UpdateMode();
            if (_session.CurrentState is { Game: "TicTacToe" } state)
            {
                ApplyMultiplayerState(state);
            }
        }
    }

    private async void Cell_Click(object? sender, EventArgs e)
    {
        if (sender is not Button { Tag: Point point })
        {
            return;
        }

        if (_session?.IsActive == true && _session.Game == "TicTacToe")
        {
            var state = _session.CurrentState;
            if (state is null || state.CurrentPlayerId != _session.LocalPlayerId || !state.Started)
            {
                _statusLabel.Text = state?.Started == true ? "Wait for your turn." : "Waiting for another player.";
                return;
            }
            await _session.SendActionAsync(new GameActionRequest { Action = "tic-move", Row = point.X, Column = point.Y });
            return;
        }

        if (!_game.MakeMove(point.X, point.Y, _game.CurrentPlayer))
        {
            _statusLabel.Text = "That cell is already occupied.";
            return;
        }

        if (_game.IsGameOver && !_game.IsDraw)
        {
            GameAudio.PlayWin();
        }
        else
        {
            GameAudio.PlayMove();
        }
        RefreshBoard();
        if (_game.IsGameOver)
        {
            _statusLabel.Text = GetRoundResult(PlayerName(_game.Winner), _game.IsDraw);
        }
        else
        {
            _statusLabel.Text = $"{PlayerName(_game.CurrentPlayer)} to move";
        }
    }

    private async void RestartGame()
    {
        if (_session?.IsActive == true && _session.Game == "TicTacToe")
        {
            await _session.SendActionAsync(new GameActionRequest { Action = "restart" });
            return;
        }
        _game.ResetBoard();
        RefreshBoard();
        _statusLabel.Text = $"{PlayerName("X")} starts the next round.";
    }

    private async void NewMatch()
    {
        if (_session?.IsActive == true && _session.Game == "TicTacToe")
        {
            await _session.SendActionAsync(new GameActionRequest { Action = "new-match" });
            return;
        }
        _game.NewMatch();
        RefreshBoard();
        _statusLabel.Text = $"{PlayerName("X")} starts a new match.";
    }

    private void ApplyNames()
    {
        RefreshBoard();
        _statusLabel.Text = _game.IsGameOver
            ? GetRoundResult(PlayerName(_game.Winner), _game.IsDraw)
            : $"{PlayerName(_game.CurrentPlayer)} to move";
    }

    private void RefreshBoard()
    {
        var multiplayer = _session?.IsActive == true && _session.Game == "TicTacToe";
        for (var row = 0; row < TicTacToeGame.BoardSize; row++)
        {
            for (var column = 0; column < TicTacToeGame.BoardSize; column++)
            {
                var mark = _game.Board[row, column];
                var button = _cells[row, column];
                var winningCell = _game.WinningLine.Contains((row, column));
                button.Mark = mark switch { TicTacToeMark.X => "X", TicTacToeMark.O => "O", _ => string.Empty };
                button.Enabled = !_game.IsGameOver && (!multiplayer || mark == TicTacToeMark.Empty);
                button.IsWinningCell = winningCell;
                button.AccessibleDescription = winningCell ? "Winning cell" : mark == TicTacToeMark.Empty ? "Empty cell" : $"Occupied by {mark}";
                button.Invalidate();
            }
        }

        _scoreLabel.Text = $"X  {_game.XScore}       O  {_game.OScore}";
        var activeMark = _game.IsGameOver ? _game.Winner : _game.CurrentPlayer;
        UpdatePlayerCard(_xPlayerLabel, "X", activeMark);
        UpdatePlayerCard(_oPlayerLabel, "O", activeMark);
    }

    private void UpdatePlayerCard(Label label, string mark, string activeMark)
    {
        var isActive = !_game.IsDraw && string.Equals(activeMark, mark, StringComparison.OrdinalIgnoreCase);
        var name = PlayerName(mark);
        label.Text = isActive ? $"{mark}  ·  {name}  ·  TURN" : $"{mark}  ·  {name}";
        label.BackColor = isActive ? Color.FromArgb(43, 36, 61) : Card;
        label.AccessibleName = $"{name}, mark {mark}{(isActive ? ", current turn" : string.Empty)}";
    }

    private static void FitBoard(TableLayoutPanel board)
    {
        var host = board.Parent;
        if (host is null)
        {
            return;
        }

        var size = Math.Clamp(Math.Min(host.ClientSize.Width, host.ClientSize.Height) - 48, 0, 760);
        board.Size = new Size(size, size);
        board.Location = new Point(
            Math.Max(0, (host.ClientSize.Width - size) / 2),
            Math.Max(0, (host.ClientSize.Height - size) / 2));
    }

    private void Session_StateChanged(GameSessionState state)
    {
        if (InvokeRequired)
        {
            BeginInvoke(() => Session_StateChanged(state));
            return;
        }
        if (state.Game != "TicTacToe" || state.TicTacToeBoard.Length != 9)
        {
            return;
        }
        ApplyMultiplayerState(state);
    }

    private void ApplyMultiplayerState(GameSessionState state)
    {
        if (state.Game != "TicTacToe" || state.TicTacToeBoard.Length != TicTacToeGame.BoardSize * TicTacToeGame.BoardSize)
        {
            return;
        }

        _game.RestoreState(state.TicTacToeBoard, state.CurrentPlayerMark, state.IsGameOver, state.WinnerMark,
            state.IsDraw, state.XScore, state.OScore, state.WinningCells.Select(index => (index / 3, index % 3)).ToArray());
        var xPlayer = state.Players.FirstOrDefault(player => player.Mark == "X");
        var oPlayer = state.Players.FirstOrDefault(player => player.Mark == "O");
        _xName.Text = xPlayer?.Name ?? "Player X";
        _oName.Text = oPlayer?.Name ?? "Player O";
        if (state.DepartureSequence > _lastDepartureSequence)
        {
            _lastDepartureSequence = state.DepartureSequence;
            _departureMessage = BuildDepartureMessage(state);
        }
        RefreshBoard();
        var localTurn = state.CurrentPlayerId == _session?.LocalPlayerId;
        _statusLabel.Text = state.IsForfeit
            ? _departureMessage
            : state.IsGameOver
            ? GetRoundResult(state.Players.FirstOrDefault(player => player.Mark == state.WinnerMark)?.Name ?? state.WinnerMark, state.IsDraw)
            : !state.Started ? "Waiting for second player" : localTurn ? $"Your turn ({state.CurrentPlayerMark})" : $"Waiting for {state.CurrentPlayerMark}";
        _restartButton.Enabled = _session?.IsActive != true || (state.Started && !state.IsForfeit);
        _newMatchButton.Enabled = _session?.IsActive != true || (state.Started && !state.IsForfeit);
        _renameButton.Enabled = _session?.IsActive != true;
        _xName.Enabled = _session?.IsActive != true;
        _oName.Enabled = _session?.IsActive != true;
        foreach (var button in _cells)
        {
            var point = (Point)button.Tag!;
            button.Enabled = state.Started && !state.IsGameOver && state.CurrentPlayerId == _session?.LocalPlayerId
                && state.TicTacToeBoard[point.X * 3 + point.Y] == TicTacToeMark.Empty;
        }
        if (xPlayer is { Connected: false })
        {
            _xPlayerLabel.Text = $"X  ·  {_xName.Text}  ·  LEFT";
        }
        if (oPlayer is { Connected: false })
        {
            _oPlayerLabel.Text = $"O  ·  {_oName.Text}  ·  LEFT";
        }
    }

    private string BuildDepartureMessage(GameSessionState state)
    {
        var departed = string.IsNullOrWhiteSpace(state.LastDepartedPlayerName)
            ? "A player"
            : $"Player {state.LastDepartedPlayerName}";
        if (!state.IsForfeit)
        {
            return $"{departed} has left the game.";
        }

        var winner = state.Players.FirstOrDefault(player => player.PlayerId == state.WinnerId)?.Name ?? state.WinnerName;
        return state.WinnerId == _session?.LocalPlayerId
            ? $"{departed} has left the game. You Won!"
            : $"{departed} has left the game. {winner} wins!";
    }

    private async Task LeaveAndExitAsync()
    {
        if (_session?.IsActive == true && _session.Game == "TicTacToe")
        {
            try
            {
                await _session.LeaveGameAsync();
            }
            catch (Exception exception) when (exception is IOException or InvalidOperationException or OperationCanceledException or ObjectDisposedException)
            {
                MessageBox.Show(this, $"Could not notify the room before leaving: {exception.Message}", Text,
                    MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }
        _onExit?.Invoke();
    }

    private void Session_StatusChanged(string message)
    {
        if (InvokeRequired)
        {
            BeginInvoke(() => Session_StatusChanged(message));
            return;
        }
        if (_session?.IsActive == true && _session.Game == "TicTacToe")
        {
            if (message.StartsWith("Connection failed:", StringComparison.OrdinalIgnoreCase))
            {
                _statusLabel.Text = message;
            }
        }
    }

    private void Session_ConnectionChanged(bool connected)
    {
        if (InvokeRequired)
        {
            BeginInvoke(() => Session_ConnectionChanged(connected));
            return;
        }

        UpdateMode();
        if (!connected && _session?.Game == "TicTacToe")
        {
            _statusLabel.Text = "Connection lost. Local Play is available.";
            RefreshBoard();
        }
    }

    private void UpdateMode()
    {
        var multiplayer = _session?.IsActive == true && _session.Game == "TicTacToe";
        _modeLabel.Text = !multiplayer ? "LOCAL PLAY" : _session!.IsHost ? "ROOM HOST" : "CONNECTED GAME";
        _modeLabel.ForeColor = !multiplayer
            ? Blue
            : _session!.IsHost ? Purple : Color.FromArgb(77, 194, 143);
    }

    private string PlayerName(string mark)
    {
        var value = mark == "X" ? _xName.Text.Trim() : _oName.Text.Trim();
        return string.IsNullOrWhiteSpace(value) ? $"Player {mark}" : value;
    }

    private static string GetRoundResult(string winner, bool isDraw) =>
        $"Round complete · {(isDraw ? "Draw" : $"{winner} wins")}. Select Restart Round when ready.";

    private static void StyleNameBox(TextBox textBox, string placeholder)
    {
        textBox.Text = placeholder;
        textBox.BackColor = Card;
        textBox.ForeColor = Color.FromArgb(235, 236, 247);
        textBox.Font = new Font("Segoe UI", 9F);
        textBox.BorderStyle = BorderStyle.FixedSingle;
        textBox.Dock = DockStyle.Fill;
        textBox.Margin = new Padding(2, 4, 4, 4);
    }

    private static Button CreateButton(string text, Color color)
    {
        var button = new Button { Text = text, Dock = DockStyle.Fill, BackColor = color, ForeColor = Color.White, FlatStyle = FlatStyle.Flat, Font = new Font("Segoe UI", 8.5F, FontStyle.Bold), Cursor = Cursors.Hand };
        button.FlatAppearance.BorderSize = 0;
        button.FlatAppearance.MouseOverBackColor = ControlPaint.Light(color, 0.1f);
        button.FlatAppearance.MouseDownBackColor = ControlPaint.Dark(color, 0.08f);
        button.Margin = new Padding(2);
        return button;
    }
}