using WiFiGameHub.Services;

namespace WiFiGameHub.Forms;

public sealed class SettingsForm : Form
{
    private readonly TextBox _playerName = new();
    private readonly NumericUpDown _networkPort = new();
    private readonly CheckBox _sound = new();
    private readonly Label _status = new();

    public SettingsForm()
    {
        Text = "Settings";
        BackColor = Color.FromArgb(17, 22, 34);
        ForeColor = Color.White;
        FormBorderStyle = FormBorderStyle.None;
        Dock = DockStyle.Fill;

        var root = new TableLayoutPanel { Dock = DockStyle.Fill, ColumnCount = 1, RowCount = 2, BackColor = BackColor };
        root.RowStyles.Add(new RowStyle(SizeType.Absolute, 72));
        root.RowStyles.Add(new RowStyle(SizeType.Percent, 100));
        var header = new Panel { Dock = DockStyle.Fill };
        header.Controls.Add(new Label { Text = "Settings", ForeColor = Color.White, Font = new Font("Segoe UI", 22F, FontStyle.Bold), AutoSize = true, Location = new Point(0, 0) });
        header.Controls.Add(new Label { Text = "Personalize your local play setup", ForeColor = Color.FromArgb(157, 175, 199), Font = new Font("Segoe UI", 9.5F), AutoSize = true, Location = new Point(2, 43) });

        var settings = new TableLayoutPanel { Dock = DockStyle.Top, ColumnCount = 2, RowCount = 6, BackColor = Color.FromArgb(28, 36, 52), Padding = new Padding(20), AutoSize = true };
        settings.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 42));
        settings.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 58));
        for (var index = 0; index < 6; index++)
        {
            settings.RowStyles.Add(new RowStyle(SizeType.Absolute, index < 2 ? 56 : 48));
        }

        _playerName.Text = AppPreferences.Current.PlayerName;
        StyleInput(_playerName);
        AddSetting(settings, 0, "Player name", _playerName);

        _networkPort.Minimum = 1;
        _networkPort.Maximum = 65535;
        _networkPort.Value = AppPreferences.Current.NetworkPort;
        StyleInput(_networkPort);
        AddSetting(settings, 1, "Network port", _networkPort);

        _sound.Text = "Enable game sound effects";
        _sound.Checked = AppPreferences.Current.SoundEnabled;
        _sound.ForeColor = Color.FromArgb(207, 220, 237);
        _sound.Font = new Font("Segoe UI", 9.5F);
        _sound.AutoSize = true;
        AddSetting(settings, 2, "Sound", _sound);

        var theme = new Label
        {
            Text = "Dark gaming theme (current theme)",
            ForeColor = Color.FromArgb(207, 220, 237),
            Font = new Font("Segoe UI", 9.5F),
            AutoSize = true,
            Anchor = AnchorStyles.Left
        };
        AddSetting(settings, 3, "Appearance", theme);

        var save = new Button { Text = "Save Settings", BackColor = Color.FromArgb(96, 112, 239), ForeColor = Color.White, FlatStyle = FlatStyle.Flat, Font = new Font("Segoe UI", 9.5F, FontStyle.Bold), Width = 150, Height = 38, Cursor = Cursors.Hand };
        save.FlatAppearance.BorderSize = 0;
        save.Click += (_, _) => SaveSettings();
        settings.Controls.Add(new Label { Text = string.Empty, AutoSize = true }, 0, 4);
        settings.Controls.Add(save, 1, 4);

        _status.Text = AppPreferences.LoadError is null ? "Settings are stored on this device." : $"Saved settings could not be loaded: {AppPreferences.LoadError}";
        _status.ForeColor = Color.FromArgb(157, 175, 199);
        _status.Font = new Font("Segoe UI", 9F);
        _status.AutoEllipsis = true;
        _status.Dock = DockStyle.Fill;
        settings.Controls.Add(new Label { Text = "STATUS", ForeColor = Color.FromArgb(137, 158, 188), Font = new Font("Segoe UI", 8F, FontStyle.Bold), AutoSize = true }, 0, 5);
        settings.Controls.Add(_status, 1, 5);

        root.Controls.Add(header, 0, 0);
        root.Controls.Add(settings, 0, 1);
        Controls.Add(root);
    }

    private void SaveSettings()
    {
        var name = _playerName.Text.Trim();
        if (string.IsNullOrWhiteSpace(name) || name.Length > 32)
        {
            _status.Text = "Player name must contain 1 to 32 characters.";
            return;
        }

        AppPreferences.Current.PlayerName = name;
        AppPreferences.Current.NetworkPort = (int)_networkPort.Value;
        AppPreferences.Current.SoundEnabled = _sound.Checked;
        AppPreferences.Current.DarkThemeEnabled = true;
        try
        {
            AppPreferences.Save();
            _status.Text = "Settings saved. New rooms will use the selected port and player name.";
        }
        catch (Exception exception) when (exception is IOException or UnauthorizedAccessException)
        {
            _status.Text = $"Could not save settings: {exception.Message}";
        }
    }

    private static void AddSetting(TableLayoutPanel panel, int row, string label, Control control)
    {
        panel.Controls.Add(new Label { Text = label, ForeColor = Color.FromArgb(207, 220, 237), Font = new Font("Segoe UI", 10F), AutoSize = true, Anchor = AnchorStyles.Left, TextAlign = ContentAlignment.MiddleLeft }, 0, row);
        control.Dock = DockStyle.Fill;
        panel.Controls.Add(control, 1, row);
    }

    private static void StyleInput(Control control)
    {
        control.BackColor = Color.FromArgb(20, 27, 40);
        control.ForeColor = Color.White;
        control.Font = new Font("Segoe UI", 9.5F);
        if (control is TextBox textBox)
        {
            textBox.BorderStyle = BorderStyle.FixedSingle;
        }
    }
}