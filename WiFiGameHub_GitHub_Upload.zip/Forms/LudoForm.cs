using WiFiGameHub.Games.Ludo;
using WiFiGameHub.Services;
using WiFiGameHub.Networking;

namespace WiFiGameHub.Forms;

public class LudoForm : Form
{
    private static readonly Color Canvas = Color.FromArgb(15, 16, 28);
    private static readonly Color Surface = Color.FromArgb(27, 28, 45);
    private static readonly Color MutedText = Color.FromArgb(158, 165, 190);
    private static readonly Color Purple = Color.FromArgb(145, 92, 246);
    private static readonly Color Blue = Color.FromArgb(69, 150, 255);
    private static readonly Color[] PlayerPalette =
    {
        Color.FromArgb(239, 76, 91),
        Color.FromArgb(63, 139, 255),
        Color.FromArgb(61, 190, 130),
        Color.FromArgb(244, 190, 62)
    };
    private LudoGame _game = new();
    private readonly LudoBoard _board = new();
    private readonly ComboBox _playerCount = new();
    private readonly TextBox[] _playerNames = new TextBox[4];
    private readonly ListBox _history = new();
    private readonly Label _statusLabel = new();
    private readonly LudoDiceControl _diceControl = new();
    private readonly Label _turnLabel = new();
    private readonly Label _remainingLabel = new();
    private readonly Label[] _playerStatusLabels = new Label[4];
    private readonly Button _rollButton = new();
    private readonly Button _startMatchButton = new();
    private readonly Button _exitButton = new();
    private readonly MultiplayerSession? _session;
    private readonly Action? _onExit;
    private int _lastNetworkPendingDiceValue;
    private int[] _lastNetworkTokenPositions = Array.Empty<int>();
    private string[] _lastNetworkMoveHistory = Array.Empty<string>();
    private long _lastDepartureSequence;
    private string _departureMessage = string.Empty;

    public LudoForm(MultiplayerSession? session = null, Action? onExit = null)
    {
        _session = session;
        _onExit = onExit;
        Text = "Ludo Arena";
        BackColor = Canvas;
        ForeColor = Color.White;
        FormBorderStyle = FormBorderStyle.None;
        Dock = DockStyle.Fill;
        Padding = new Padding(14);

        var root = new TableLayoutPanel
        {
            Dock = DockStyle.Fill,
            ColumnCount = 2,
            RowCount = 2,
            BackColor = BackColor,
            Padding = Padding.Empty
        };
        root.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 64));
        root.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 36));
        root.RowStyles.Add(new RowStyle(SizeType.Absolute, 66));
        root.RowStyles.Add(new RowStyle(SizeType.Percent, 100));

        var header = new Panel { Dock = DockStyle.Fill, Padding = new Padding(2, 0, 0, 8) };
        header.Controls.Add(new Label
        {
            Text = "LUDO ARENA",
            ForeColor = Color.White,
            Font = new Font("Segoe UI", 20F, FontStyle.Bold),
            AutoSize = true,
            Location = new Point(0, 0)
        });
        header.Controls.Add(new Label
        {
            Text = "A colorful race to the finish  ·  2–4 players",
            ForeColor = MutedText,
            Font = new Font("Segoe UI", 9.5F),
            AutoSize = true,
            Location = new Point(3, 38)
        });
        _exitButton.Text = "Exit";
        StyleButton(_exitButton, Color.FromArgb(39, 38, 58));
        _exitButton.Size = new Size(66, 30);
        _exitButton.Dock = DockStyle.None;
        _exitButton.Enabled = _onExit is not null;
        _exitButton.Anchor = AnchorStyles.Top | AnchorStyles.Right;
        _exitButton.Location = new Point(header.Width - _exitButton.Width, 8);
        _exitButton.Click += async (_, _) => await LeaveAndExitAsync();
        header.Resize += (_, _) => _exitButton.Left = header.ClientSize.Width - _exitButton.Width;
        header.Controls.Add(_exitButton);

        _board.Dock = DockStyle.Fill;
        _board.Margin = new Padding(0, 0, 12, 0);
        _board.TokenSelected += HandleTokenSelected;

        var side = new TableLayoutPanel
        {
            Dock = DockStyle.Fill,
            ColumnCount = 1,
            RowCount = 8,
            BackColor = Surface,
            Padding = new Padding(12),
            Margin = Padding.Empty
        };
        side.RowStyles.Add(new RowStyle(SizeType.Absolute, 58));
        side.RowStyles.Add(new RowStyle(SizeType.Absolute, 92));
        side.RowStyles.Add(new RowStyle(SizeType.Absolute, 42));
        side.RowStyles.Add(new RowStyle(SizeType.Absolute, 104));
        side.RowStyles.Add(new RowStyle(SizeType.Absolute, 116));
        side.RowStyles.Add(new RowStyle(SizeType.Absolute, 62));
        side.RowStyles.Add(new RowStyle(SizeType.Percent, 100));
        side.RowStyles.Add(new RowStyle(SizeType.Percent, 100));

        var turnPanel = new Panel
        {
            Dock = DockStyle.Fill,
            BackColor = Color.FromArgb(35, 31, 54),
            Padding = new Padding(12, 6, 12, 4)
        };
        _turnLabel.Dock = DockStyle.Top;
        _turnLabel.Font = new Font("Segoe UI", 13F, FontStyle.Bold);
        _turnLabel.AutoEllipsis = true;
        _turnLabel.Height = 27;
        _statusLabel.Dock = DockStyle.Top;
        _statusLabel.Font = new Font("Segoe UI", 8.5F);
        _statusLabel.ForeColor = MutedText;
        _statusLabel.AutoEllipsis = true;
        _statusLabel.Height = 22;
        turnPanel.Controls.Add(_statusLabel);
        turnPanel.Controls.Add(_turnLabel);

        var dicePanel = new Panel { Dock = DockStyle.Fill, BackColor = Color.FromArgb(21, 22, 38), Padding = new Padding(8) };
        _diceControl.Dock = DockStyle.Fill;
        dicePanel.Controls.Add(_diceControl);

        _rollButton.Text = "ROLL DICE";
        StyleButton(_rollButton, Purple);
        _rollButton.Dock = DockStyle.Fill;
        _rollButton.Click += (_, _) => RollDice();

        var playerPanel = new TableLayoutPanel
        {
            Dock = DockStyle.Fill,
            ColumnCount = 1,
            RowCount = 5,
            BackColor = Surface,
            Margin = Padding.Empty,
            Padding = new Padding(0, 0, 0, 2)
        };
        playerPanel.RowStyles.Add(new RowStyle(SizeType.Absolute, 22));
        for (var index = 0; index < _playerStatusLabels.Length; index++)
        {
            playerPanel.RowStyles.Add(new RowStyle(SizeType.Percent, 25));
            _playerStatusLabels[index] = new Label
            {
                Dock = DockStyle.Fill,
                ForeColor = PlayerPalette[index],
                Font = new Font("Segoe UI", 8.5F, FontStyle.Bold),
                TextAlign = ContentAlignment.MiddleLeft,
                AutoEllipsis = true,
                Padding = new Padding(7, 0, 4, 0),
                BackColor = Color.FromArgb(21, 22, 37),
                Margin = new Padding(0, 1, 0, 1),
                Visible = index < 4
            };
            playerPanel.Controls.Add(_playerStatusLabels[index], 0, index + 1);
        }
        playerPanel.Controls.Add(CreateSectionLabel("PLAYERS  ·  TOKENS REMAINING"), 0, 0);

        var setupPanel = new TableLayoutPanel
        {
            Dock = DockStyle.Fill,
            ColumnCount = 2,
            RowCount = 3,
            BackColor = Surface,
            Padding = new Padding(0, 4, 0, 0)
        };
        setupPanel.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 26));
        setupPanel.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 74));
        setupPanel.RowStyles.Add(new RowStyle(SizeType.Absolute, 28));
        setupPanel.RowStyles.Add(new RowStyle(SizeType.Absolute, 38));
        setupPanel.RowStyles.Add(new RowStyle(SizeType.Percent, 100));
        setupPanel.Controls.Add(CreateSectionLabel("Players"), 0, 0);
        setupPanel.SetColumnSpan(setupPanel.Controls[0], 2);
        setupPanel.Controls.Add(CreateMutedLabel("Players"), 0, 1);
        _playerCount.DropDownStyle = ComboBoxStyle.DropDownList;
        _playerCount.Items.AddRange(new object[] { "2 players", "3 players", "4 players" });
        _playerCount.SelectedIndex = 2;
        StyleInput(_playerCount);
        _playerCount.SelectedIndexChanged += (_, _) => UpdateNameVisibility();
        _playerCount.SelectionChangeCommitted += (_, _) => GameAudio.PlayClick();
        setupPanel.Controls.Add(_playerCount, 1, 1);
        setupPanel.Controls.Add(CreateMutedLabel("Player names"), 0, 2);
        var namePanel = new TableLayoutPanel { Dock = DockStyle.Fill, ColumnCount = 2, RowCount = 2, Padding = Padding.Empty, Margin = Padding.Empty };
        namePanel.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 50));
        namePanel.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 50));
        namePanel.RowStyles.Add(new RowStyle(SizeType.Percent, 50));
        namePanel.RowStyles.Add(new RowStyle(SizeType.Percent, 50));
        for (var index = 0; index < _playerNames.Length; index++)
        {
            _playerNames[index] = new TextBox { Text = new[] { "Red", "Blue", "Green", "Yellow" }[index], Visible = index < 2 };
            StyleInput(_playerNames[index]);
            namePanel.Controls.Add(_playerNames[index], index % 2, index / 2);
        }
        setupPanel.Controls.Add(namePanel, 1, 2);

        var actionPanel = new TableLayoutPanel { Dock = DockStyle.Fill, ColumnCount = 2, RowCount = 2, BackColor = Surface, Padding = new Padding(0, 4, 0, 0) };
        actionPanel.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 50));
        actionPanel.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 50));
        actionPanel.RowStyles.Add(new RowStyle(SizeType.Absolute, 26));
        actionPanel.RowStyles.Add(new RowStyle(SizeType.Percent, 100));
        actionPanel.Controls.Add(CreateSectionLabel("Match"), 0, 0);
        actionPanel.SetColumnSpan(actionPanel.Controls[0], 2);
        _startMatchButton.Text = "New Match";
        StyleButton(_startMatchButton, Blue);
        _startMatchButton.Dock = DockStyle.Fill;
        _startMatchButton.Click += (_, _) =>
        {
            GameAudio.PlayClick();
            StartNewGame();
        };
        var restartButton = new Button { Text = "Restart" };
        StyleButton(restartButton, Color.FromArgb(57, 55, 79));
        restartButton.Dock = DockStyle.Fill;
        restartButton.Click += (_, _) =>
        {
            GameAudio.PlayClick();
            RestartGame();
        };
        actionPanel.Controls.Add(_startMatchButton, 0, 1);
        actionPanel.Controls.Add(restartButton, 1, 1);

        _remainingLabel.Dock = DockStyle.Fill;
        _remainingLabel.Font = new Font("Segoe UI", 8F);
        _remainingLabel.ForeColor = MutedText;
        _remainingLabel.Padding = new Padding(4, 3, 0, 0);

        var historyTabs = new TabControl
        {
            Dock = DockStyle.Fill,
            Padding = new Point(8, 4),
            Font = new Font("Segoe UI", 8.5F, FontStyle.Bold),
            DrawMode = TabDrawMode.OwnerDrawFixed,
            SizeMode = TabSizeMode.Fixed,
            ItemSize = new Size(92, 26)
        };
        historyTabs.DrawItem += (_, eventArgs) => DrawTabHeader(historyTabs, eventArgs);
        var historyPage = new TabPage("Move History") { BackColor = Surface, Padding = new Padding(4) };
        var chatPage = new TabPage("Chat") { BackColor = Surface, Padding = new Padding(2) };
        var historyTitle = CreateSectionLabel("Recent moves");
        historyTitle.Dock = DockStyle.Top;
        historyTitle.Height = 24;
        _history.Dock = DockStyle.Fill;
        _history.BackColor = Color.FromArgb(19, 20, 34);
        _history.ForeColor = Color.FromArgb(227, 228, 241);
        _history.BorderStyle = BorderStyle.None;
        _history.Font = new Font("Segoe UI", 9F);
        historyPage.Controls.Add(_history);
        historyPage.Controls.Add(historyTitle);
        chatPage.Controls.Add(new GameChatPanel(_session));
        historyTabs.TabPages.Add(historyPage);
        historyTabs.TabPages.Add(chatPage);

        side.Controls.Add(turnPanel, 0, 0);
        side.Controls.Add(dicePanel, 0, 1);
        side.Controls.Add(_rollButton, 0, 2);
        side.Controls.Add(playerPanel, 0, 3);
        side.Controls.Add(setupPanel, 0, 4);
        side.Controls.Add(actionPanel, 0, 5);
        side.Controls.Add(_remainingLabel, 0, 6);
        side.Controls.Add(historyTabs, 0, 7);

        root.Controls.Add(header, 0, 0);
        root.SetColumnSpan(header, 2);
        root.Controls.Add(_board, 0, 1);
        root.Controls.Add(side, 1, 1);
        Controls.Add(root);

        UpdateNameVisibility();
        RefreshGameView("Roll the dice to begin.");
        if (_session is not null)
        {
            _session.StateChanged += Session_StateChanged;
            _session.StatusChanged += Session_StatusChanged;
            Disposed += (_, _) =>
            {
                _session.StateChanged -= Session_StateChanged;
                _session.StatusChanged -= Session_StatusChanged;
            };
            if (_session.CurrentState is not null)
            {
                ApplyMultiplayerState(_session.CurrentState);
            }
        }
    }

    private async void RollDice()
    {
        if (_session?.IsActive == true && _session.Game == "Ludo")
        {
            var state = _session.CurrentState;
            if (state is null || !state.Started || state.CurrentPlayerId != _session.LocalPlayerId || state.PendingDiceValue > 0)
            {
                _statusLabel.Text = "Waiting for your turn or a pending move";
                return;
            }
            await _session.SendActionAsync(new GameActionRequest { Action = "ludo-roll" });
            return;
        }

        if (_game.LastDiceValue > 0 || _game.IsGameOver)
        {
            return;
        }

        var currentPlayerIndex = _game.CurrentPlayerIndex;
        var playerName = _game.Players[currentPlayerIndex].Name;
        var value = _game.RollDice();
        GameAudio.PlayDice();
        _diceControl.ShowRoll(value);
        if (_game.CurrentPlayerIndex != currentPlayerIndex)
        {
            RefreshGameView($"{playerName} rolled {value}; no legal move. Turn passed.");
        }
        else
        {
            RefreshGameView(_game.HasLegalMove(_game.CurrentPlayerIndex)
                ? $"{playerName} rolled {value}. Select a token on the board."
                : $"{playerName} rolled {value}.");
        }
    }

    private async void HandleTokenSelected(int playerIndex, int tokenIndex)
    {
        if (_session?.IsActive == true && _session.Game == "Ludo")
        {
            var state = _session.CurrentState;
            if (state is null || !state.Started || state.CurrentPlayerId != _session.LocalPlayerId)
            {
                _statusLabel.Text = "It is not your turn";
                return;
            }
            await _session.SendActionAsync(new GameActionRequest { Action = "ludo-move", TokenIndex = tokenIndex });
            return;
        }

        if (playerIndex != _game.CurrentPlayerIndex || !_game.CanMoveToken(playerIndex, tokenIndex))
        {
            RefreshGameView("That token cannot move with this roll.");
            return;
        }

        if (!_game.MoveToken(playerIndex, tokenIndex))
        {
            RefreshGameView("That move is not legal.");
            return;
        }

        if (_game.IsGameOver)
        {
            GameAudio.PlayWin();
        }
        else
        {
            GameAudio.PlayMove();
        }
        if (_game.LastDiceResult is >= 1 and <= 6)
        {
            _diceControl.ShowRoll(_game.LastDiceResult);
        }
        RefreshGameView(_game.IsGameOver
            ? $"{_game.Winner} wins the arena!"
            : $"Move accepted. {_game.Players[_game.CurrentPlayerIndex].Name}'s turn.");
    }

    private async void StartNewGame()
    {
        if (_session?.IsActive == true && _session.Game == "Ludo")
        {
            if (!_session.IsHost)
            {
                _statusLabel.Text = "Only the room host can start the match.";
                return;
            }
            if (_session.CurrentState?.Players.Count is not >= 2)
            {
                _statusLabel.Text = "Waiting for a second player to join.";
                return;
            }
            await _session.SendActionAsync(new GameActionRequest { Action = "start" });
            return;
        }

        var count = _playerCount.SelectedIndex + 2;
        var names = _playerNames.Take(count).Select((textBox, index) =>
            string.IsNullOrWhiteSpace(textBox.Text) ? new[] { "Red", "Blue", "Green", "Yellow" }[index] : textBox.Text.Trim()).ToArray();
        _game = new LudoGame(count, playerNames: names);
        _board.Game = _game;
        _diceControl.Clear();
        RefreshGameView($"New {count}-player match ready.");
    }

    private async void RestartGame()
    {
        if (_session?.IsActive == true && _session.Game == "Ludo")
        {
            if (_session.IsHost)
            {
                await _session.SendActionAsync(new GameActionRequest { Action = "restart" });
            }
            else
            {
                _statusLabel.Text = "Only the room host can restart the match.";
            }
            return;
        }

        _game.ResetGame();
        _diceControl.Clear();
        RefreshGameView("Match restarted.");
    }

    private void RefreshGameView(string message)
    {
        if (_game.IsGameOver)
        {
            _turnLabel.Text = $"WINNER  ·  {_game.Winner}";
            var winner = _game.Players.FirstOrDefault(player => player.Name == _game.Winner);
            _turnLabel.ForeColor = winner is null ? Color.FromArgb(244, 190, 62) : ColorFor(winner.Color);
            _turnLabel.AccessibleName = $"Winner: {_game.Winner}";
        }
        else
        {
            var player = _game.Players[_game.CurrentPlayerIndex];
            _turnLabel.Text = $"{player.Color.ToUpperInvariant()} TURN  ·  {player.Name}";
            _turnLabel.AccessibleName = $"Current turn: {player.Name}";
            _turnLabel.ForeColor = ColorFor(player.Color);
        }

        _statusLabel.Text = message;
        _rollButton.Enabled = _session?.IsActive == true && _session.Game == "Ludo"
            ? _session.CurrentState is { Started: true, IsGameOver: false, PendingDiceValue: 0 } state
                && state.CurrentPlayerId == _session.LocalPlayerId
            : !_game.IsGameOver && _game.LastDiceValue == 0;
        for (var index = 0; index < _playerStatusLabels.Length; index++)
        {
            var label = _playerStatusLabels[index];
            var player = _game.Players.ElementAtOrDefault(index);
            label.Visible = player is not null;
            if (player is null)
            {
                continue;
            }

            var tokensRemaining = player.Tokens.Count(token => token.Position != LudoGame.FinishPosition);
            var tokensFinished = player.Tokens.Count(token => token.Position == LudoGame.FinishPosition);
            var left = _session?.CurrentState?.Players.FirstOrDefault(candidate => candidate.Color == player.Color) is { Connected: false };
            label.Text = $"●   {player.Color.ToUpperInvariant()}  ·  {player.Name}{(left ? "  ·  LEFT" : string.Empty)}     {tokensRemaining} left  /  {tokensFinished} finished";
            label.ForeColor = ColorFor(player.Color);
            label.BackColor = index == _game.CurrentPlayerIndex && !_game.IsGameOver
                ? Color.FromArgb(43, 36, 61)
                : Color.FromArgb(21, 22, 37);
            label.AccessibleName = $"{player.Color} player {player.Name}, {tokensRemaining} tokens remaining, {tokensFinished} finished";
        }
        var activePlayerCount = _game.Players.Count(player => player.IsActive);
        _remainingLabel.Text = $"{activePlayerCount} active player(s)  ·  4 tokens each";
        _history.BeginUpdate();
        _history.Items.Clear();
        foreach (var item in _game.MoveHistory.TakeLast(14).Reverse())
        {
            _history.Items.Add(item);
        }
        _history.EndUpdate();
        _board.Game = _game;
        var currentPlayerIndex = _game.CurrentPlayerIndex;
        _board.HighlightedTokens = _game.IsGameOver || !_game.HasLegalMove(currentPlayerIndex)
            ? Array.Empty<int>()
            : _game.Players[currentPlayerIndex].Tokens
                .Where(token => _game.CanMoveToken(currentPlayerIndex, token.TokenIndex))
                .Select(token => token.TokenIndex)
                .ToArray();
        _board.Invalidate();
    }

    private void Session_StateChanged(GameSessionState state)
    {
        if (InvokeRequired)
        {
            BeginInvoke(() => Session_StateChanged(state));
            return;
        }
        if (state.Game == "Ludo")
        {
            ApplyMultiplayerState(state);
        }
    }

    private void ApplyMultiplayerState(GameSessionState state)
    {
        if (state.Players.Count is >= 2 and <= 4 && state.LudoTokenPositions.Length == state.Players.Count * 4)
        {
            var newNoMoveRoll = state.MoveHistory.Length > _lastNetworkMoveHistory.Length
                && state.MoveHistory[^1].Contains("rolled", StringComparison.Ordinal);
            if ((_lastNetworkPendingDiceValue == 0 && state.PendingDiceValue is >= 1 and <= 6) || newNoMoveRoll)
            {
                GameAudio.PlayDice();
            }
            if (_lastNetworkTokenPositions.Length == state.LudoTokenPositions.Length
                && !_lastNetworkTokenPositions.SequenceEqual(state.LudoTokenPositions))
            {
                if (state.IsGameOver)
                {
                    GameAudio.PlayWin();
                }
                else
                {
                    GameAudio.PlayMove();
                }
            }

            var players = state.Players.OrderBy(player => ColorOrder(player.Color)).ToArray();
            _game = new LudoGame(
                players.Length,
                playerNames: players.Select(player => player.Name).ToArray(),
                playerColors: players.Select(player => player.Color).ToArray());
            _game.RestoreState(state.LudoTokenPositions, state.CurrentLudoPlayerIndex, state.PendingDiceValue,
                state.DiceValue, state.IsGameOver, state.WinnerName, state.MoveHistory,
                players.Select(player => player.Connected).ToArray());
            _lastNetworkPendingDiceValue = state.PendingDiceValue;
            _lastNetworkTokenPositions = (int[])state.LudoTokenPositions.Clone();
            _lastNetworkMoveHistory = (string[])state.MoveHistory.Clone();
            var activePlayerCount = players.Count(player => player.Connected);
            _playerCount.SelectedIndex = activePlayerCount is >= 2 and <= 4 ? activePlayerCount - 2 : -1;
            for (var index = 0; index < _playerNames.Length; index++)
            {
                _playerNames[index].Text = index < players.Length ? players[index].Name : new[] { "Red", "Blue", "Green", "Yellow" }[index];
            }
        }

        if (state.DepartureSequence > _lastDepartureSequence)
        {
            _lastDepartureSequence = state.DepartureSequence;
            _departureMessage = BuildDepartureMessage(state);
        }

        _board.Game = _game;
        if (state.DiceValue is >= 1 and <= 6 && _diceControl.Value != state.DiceValue)
        {
            _diceControl.ShowRoll(state.DiceValue);
        }
        else if (state.DiceValue == 0)
        {
            _diceControl.Clear();
        }
        _rollButton.Enabled = state.Started && !state.IsGameOver && state.CurrentPlayerId == _session?.LocalPlayerId && state.PendingDiceValue == 0;
        _startMatchButton.Text = _session?.IsActive == true && _session.Game == "Ludo" ? "Start Match" : "New Match";
        _startMatchButton.Enabled = _session?.IsActive != true
            || (_session.IsHost && !state.IsForfeit && !state.Started && state.Players.Count(player => player.Connected) >= 2);
        var current = state.Players.ElementAtOrDefault(state.CurrentLudoPlayerIndex);
        var yourTurn = state.CurrentPlayerId == _session?.LocalPlayerId;
        var status = state.IsForfeit
            ? _departureMessage
            : state.IsGameOver
            ? $"{state.WinnerName} wins the arena!"
            : !state.Started && state.Players.Count < 2
                ? "Waiting for a second player to join."
                : !state.Started
                    ? $"Ready to start with {state.Players.Count} players. The host can start the match."
                    : yourTurn ? "Your turn" : $"Waiting for {current?.Name ?? "player"}";
        RefreshGameView(status);
    }

    private string BuildDepartureMessage(GameSessionState state)
    {
        var departed = string.IsNullOrWhiteSpace(state.LastDepartedPlayerName)
            ? "A player"
            : $"Player {state.LastDepartedPlayerName}";
        if (!state.IsForfeit)
        {
            return $"{departed} has left the game.";
        }

        var winner = state.Players.FirstOrDefault(player => player.PlayerId == state.WinnerId)?.Name ?? state.WinnerName;
        return state.WinnerId == _session?.LocalPlayerId
            ? $"{departed} has left the game. You Won!"
            : $"{departed} has left the game. {winner} wins!";
    }

    private async Task LeaveAndExitAsync()
    {
        if (_session?.IsActive == true && _session.Game == "Ludo")
        {
            try
            {
                await _session.LeaveGameAsync();
            }
            catch (Exception exception) when (exception is IOException or InvalidOperationException or OperationCanceledException or ObjectDisposedException)
            {
                MessageBox.Show(this, $"Could not notify the room before leaving: {exception.Message}", Text,
                    MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }
        _onExit?.Invoke();
    }

    private void Session_StatusChanged(string message)
    {
        if (InvokeRequired)
        {
            BeginInvoke(() => Session_StatusChanged(message));
            return;
        }
        if (_session?.IsActive == true && _session.Game == "Ludo")
        {
            if (_game.IsGameOver)
            {
                var nextStep = _session?.IsActive == true && _session.Game == "Ludo"
                    ? _session.IsHost ? "The host can restart when ready." : "Wait for the host to restart."
                    : "Select Restart Round when ready.";
                _statusLabel.Text = $"{_game.Winner} wins · Match complete. {nextStep}";
            }
            else
            {
                _statusLabel.Text = message;
            }
        }
    }

    private static int ColorOrder(string color) => color switch
    {
        "Red" => 0,
        "Blue" => 1,
        "Green" => 2,
        "Yellow" => 3,
        _ => int.MaxValue
    };

    private void UpdateNameVisibility()
    {
        var count = _playerCount.SelectedIndex + 2;
        for (var index = 0; index < _playerNames.Length; index++)
        {
            _playerNames[index].Visible = index < count;
        }
    }

    private static Label CreateSectionLabel(string text) => new()
    {
        Text = text,
        ForeColor = Color.FromArgb(126, 150, 183),
        Font = new Font("Segoe UI", 8.5F, FontStyle.Bold),
        AutoSize = true
    };

    private static Label CreateMutedLabel(string text) => new()
    {
        Text = text,
        ForeColor = MutedText,
        Font = new Font("Segoe UI", 9.5F),
        TextAlign = ContentAlignment.MiddleLeft,
        Dock = DockStyle.Fill
    };

    private static void StyleInput(Control control)
    {
        control.BackColor = Color.FromArgb(22, 29, 42);
        control.ForeColor = Color.White;
        control.Font = new Font("Segoe UI", 9F);
        control.Dock = DockStyle.Fill;
        if (control is TextBox textBox)
        {
            textBox.BorderStyle = BorderStyle.FixedSingle;
            textBox.Margin = new Padding(0, 4, 4, 4);
        }
        else if (control is ComboBox comboBox)
        {
            comboBox.Margin = new Padding(0, 2, 0, 2);
        }
    }

    private static void StyleButton(Button button, Color color)
    {
        button.BackColor = color;
        button.ForeColor = Color.White;
        button.FlatStyle = FlatStyle.Flat;
        button.FlatAppearance.BorderSize = 0;
        button.Font = new Font("Segoe UI", 10F, FontStyle.Bold);
        button.Cursor = Cursors.Hand;
        button.Margin = new Padding(3);
        button.FlatAppearance.MouseOverBackColor = ControlPaint.Light(color, 0.12F);
        button.FlatAppearance.MouseDownBackColor = ControlPaint.Dark(color, 0.08F);
    }

    private static void DrawTabHeader(TabControl tabs, DrawItemEventArgs e)
    {
        var selected = e.Index == tabs.SelectedIndex;
        using var background = new SolidBrush(selected ? Color.FromArgb(51, 39, 75) : Surface);
        using var text = new SolidBrush(selected ? Color.White : MutedText);
        e.Graphics.FillRectangle(background, e.Bounds);
        TextRenderer.DrawText(
            e.Graphics,
            tabs.TabPages[e.Index].Text,
            tabs.Font,
            e.Bounds,
            text.Color,
            TextFormatFlags.HorizontalCenter | TextFormatFlags.VerticalCenter | TextFormatFlags.EndEllipsis);
        if (selected)
        {
            using var accent = new Pen(Purple, 2F);
            e.Graphics.DrawLine(accent, e.Bounds.Left + 10, e.Bounds.Bottom - 2, e.Bounds.Right - 10, e.Bounds.Bottom - 2);
        }
    }

    private static Color ColorFor(string color) => color switch
    {
        "Red" => Color.FromArgb(239, 76, 91),
        "Blue" => Color.FromArgb(63, 139, 255),
        "Green" => Color.FromArgb(61, 190, 130),
        "Yellow" => Color.FromArgb(244, 190, 62),
        _ => Color.White
    };
}