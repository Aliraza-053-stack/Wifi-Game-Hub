using System.Drawing.Drawing2D;

namespace WiFiGameHub.Forms;

internal sealed class TicTacToeCellButton : Button
{
    private readonly System.Windows.Forms.Timer _markAnimation = new() { Interval = 16 };
    private string _mark = string.Empty;
    private int _animationElapsed;
    private float _markScale = 1f;
    private bool _isHovered;

    public string Mark
    {
        get => _mark;
        set
        {
            if (_mark == value)
            {
                return;
            }

            _mark = value;
            if (string.IsNullOrEmpty(value) || !IsHandleCreated)
            {
                _markAnimation.Stop();
                _markScale = 1f;
                Invalidate();
                return;
            }

            _animationElapsed = 0;
            _markScale = 0.4f;
            _markAnimation.Start();
            Invalidate();
        }
    }
    public bool IsWinningCell { get; set; }

    public TicTacToeCellButton()
    {
        FlatStyle = FlatStyle.Flat;
        FlatAppearance.BorderSize = 0;
        FlatAppearance.MouseDownBackColor = Color.FromArgb(43, 36, 61);
        Text = string.Empty;
        TabStop = true;
        SetStyle(ControlStyles.UserPaint | ControlStyles.AllPaintingInWmPaint
            | ControlStyles.OptimizedDoubleBuffer | ControlStyles.ResizeRedraw, true);
        _markAnimation.Tick += (_, _) =>
        {
            _animationElapsed += _markAnimation.Interval;
            var progress = Math.Min(1f, _animationElapsed / 150f);
            _markScale = 1f - (1f - progress) * (1f - progress) * (1f - progress);
            if (progress >= 1f)
            {
                _markAnimation.Stop();
            }
            Invalidate();
        };
    }

    protected override void OnMouseEnter(EventArgs e)
    {
        _isHovered = true;
        Invalidate();
        base.OnMouseEnter(e);
    }

    protected override void OnMouseLeave(EventArgs e)
    {
        _isHovered = false;
        Invalidate();
        base.OnMouseLeave(e);
    }

    protected override void OnPaint(PaintEventArgs e)
    {
        var graphics = e.Graphics;
        graphics.SmoothingMode = SmoothingMode.AntiAlias;
        var bounds = ClientRectangle;
        if (bounds.Width < 2 || bounds.Height < 2)
        {
            return;
        }

        var fill = IsWinningCell
            ? Color.FromArgb(58, 43, 84)
            : _isHovered && Enabled ? Color.FromArgb(38, 39, 61) : Color.FromArgb(27, 29, 46);
        var inset = RectangleF.Inflate(bounds, -2f, -2f);
        using (var path = RoundedRectangle(inset, Math.Min(14f, Math.Min(inset.Width, inset.Height) * 0.08f)))
        using (var background = new LinearGradientBrush(inset,
            ControlPaint.Light(fill, 0.09f), ControlPaint.Dark(fill, 0.12f), 42f))
        using (var edge = new Pen(
            IsWinningCell ? Color.FromArgb(190, 145, 92, 246) : _isHovered ? Color.FromArgb(110, 117, 103, 180) : Color.FromArgb(52, 57, 78),
            IsWinningCell ? 2.4f : 1.2f))
        {
            graphics.FillPath(background, path);
            graphics.DrawPath(edge, path);
        }

        if (Mark == "X")
        {
            DrawCross(graphics, bounds, _markScale);
        }
        else if (Mark == "O")
        {
            DrawRing(graphics, bounds, _markScale);
        }

        if (Focused)
        {
            using var focusPen = new Pen(Color.FromArgb(210, 145, 92, 246), 2f) { DashStyle = DashStyle.Dot };
            graphics.DrawRectangle(focusPen, 7, 7, bounds.Width - 15, bounds.Height - 15);
        }
    }

    private static GraphicsPath RoundedRectangle(RectangleF bounds, float radius)
    {
        var path = new GraphicsPath();
        var diameter = radius * 2;
        path.AddArc(bounds.X, bounds.Y, diameter, diameter, 180, 90);
        path.AddArc(bounds.Right - diameter, bounds.Y, diameter, diameter, 270, 90);
        path.AddArc(bounds.Right - diameter, bounds.Bottom - diameter, diameter, diameter, 0, 90);
        path.AddArc(bounds.X, bounds.Bottom - diameter, diameter, diameter, 90, 90);
        path.CloseFigure();
        return path;
    }

    protected override void Dispose(bool disposing)
    {
        if (disposing)
        {
            _markAnimation.Stop();
            _markAnimation.Dispose();
        }
        base.Dispose(disposing);
    }

    private static void DrawCross(Graphics graphics, Rectangle bounds, float scale)
    {
        var size = Math.Min(bounds.Width, bounds.Height);
        var centerX = bounds.Width / 2f;
        var centerY = bounds.Height / 2f;
        var halfLength = size * 0.33f * scale;
        var thickness = Math.Max(4f, size * 0.085f * scale);
        using var shadow = new Pen(Color.FromArgb(100, 8, 12, 27), thickness + Math.Max(2f, size * 0.025f))
        {
            StartCap = LineCap.Round,
            EndCap = LineCap.Round
        };
        using var mark = new Pen(Color.FromArgb(74, 173, 255), thickness) { StartCap = LineCap.Round, EndCap = LineCap.Round };
        var inset = halfLength * 0.68f;
        graphics.DrawLine(shadow, centerX - inset + 2, centerY - inset + 3, centerX + inset + 2, centerY + inset + 3);
        graphics.DrawLine(shadow, centerX + inset + 2, centerY - inset + 3, centerX - inset + 2, centerY + inset + 3);
        graphics.DrawLine(mark, centerX - inset, centerY - inset, centerX + inset, centerY + inset);
        graphics.DrawLine(mark, centerX + inset, centerY - inset, centerX - inset, centerY + inset);
    }

    private static void DrawRing(Graphics graphics, Rectangle bounds, float scale)
    {
        var size = Math.Min(bounds.Width, bounds.Height);
        var diameter = size * 0.69f * scale;
        var thickness = size * 0.12f * scale;
        var ring = new RectangleF((bounds.Width - diameter) / 2f, (bounds.Height - diameter) / 2f,
            diameter, diameter);
        var shadow = ring;
        shadow.Offset(size * 0.025f, size * 0.03f);
        using (var shadowBrush = new SolidBrush(Color.FromArgb(100, 8, 12, 27)))
        {
            graphics.FillEllipse(shadowBrush, shadow);
        }

        using (var outer = new LinearGradientBrush(ring,
            Color.FromArgb(190, 143, 255), Color.FromArgb(115, 68, 208), 38f))
        {
            graphics.FillEllipse(outer, ring);
        }

        var inner = RectangleF.Inflate(ring, -thickness, -thickness);
        using (var recess = new LinearGradientBrush(inner,
            Color.FromArgb(38, 33, 59), Color.FromArgb(22, 23, 38), 40f))
        {
            graphics.FillEllipse(recess, inner);
        }

        using var rim = new Pen(Color.FromArgb(221, 193, 255), Math.Max(1f, size * 0.025f));
        graphics.DrawArc(rim, ring, 198, 142);
        using var innerRim = new Pen(Color.FromArgb(90, 231, 211, 255), Math.Max(1f, size * 0.012f));
        graphics.DrawArc(innerRim, inner, 198, 142);
    }
}
