using System.Drawing.Drawing2D;

namespace WiFiGameHub.Forms;

public sealed class GameModeForm : Form
{
    private static readonly Color Canvas = Color.FromArgb(15, 16, 28);
    private static readonly Color MutedText = Color.FromArgb(158, 165, 190);
    private static readonly Color Purple = Color.FromArgb(145, 92, 246);
    private static readonly Color Blue = Color.FromArgb(69, 150, 255);
    private readonly TableLayoutPanel _choices;
    private readonly Panel _localCard;
    private readonly Panel _roomCard;

    public GameModeForm(string gameName, string soloDescription, Action onSoloPlay, Action onPlayInRoom, Action? onBack = null)
    {
        Text = $"{gameName} · Choose mode";
        BackColor = Canvas;
        ForeColor = Color.White;
        FormBorderStyle = FormBorderStyle.None;
        Dock = DockStyle.Fill;
        Padding = new Padding(30, 20, 30, 22);
        MinimumSize = new Size(640, 480);

        var root = new TableLayoutPanel
        {
            Dock = DockStyle.Fill,
            ColumnCount = 1,
            RowCount = 3,
            BackColor = Canvas,
            Margin = Padding.Empty,
            Padding = Padding.Empty
        };
        root.RowStyles.Add(new RowStyle(SizeType.Absolute, 142));
        root.RowStyles.Add(new RowStyle(SizeType.Percent, 100));
        root.RowStyles.Add(new RowStyle(SizeType.Absolute, 38));

        var heading = CreateHeading(gameName, onBack);
        _choices = new TableLayoutPanel
        {
            Dock = DockStyle.Fill,
            ColumnCount = 2,
            RowCount = 1,
            BackColor = Canvas,
            Margin = Padding.Empty,
            Padding = new Padding(0, 5, 0, 8)
        };
        _choices.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 50));
        _choices.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 50));
        _localCard = CreateOption(
            ModeIconKind.Local,
            "LOCAL PLAY",
            "Play Locally",
            "Play with friends on the same computer.",
            soloDescription,
            "Play Locally",
            Purple,
            onSoloPlay);
        _roomCard = CreateOption(
            ModeIconKind.Network,
            "LAN MULTIPLAYER",
            "Play in Room",
            "Create or join a room over the same Wi-Fi network.",
            "Room matches begin when players are connected.",
            "Find a Room",
            Blue,
            onPlayInRoom);
        _choices.Controls.Add(_localCard, 0, 0);
        _choices.Controls.Add(_roomCard, 1, 0);
        _choices.Resize += (_, _) => UpdateResponsiveLayout();

        var footnote = new Label
        {
            Text = "Local play stays on this device  ·  Room play connects players on your local network",
            Dock = DockStyle.Fill,
            ForeColor = MutedText,
            Font = new Font("Segoe UI", 8.5F),
            TextAlign = ContentAlignment.MiddleCenter
        };
        root.Controls.Add(heading, 0, 0);
        root.Controls.Add(_choices, 0, 1);
        root.Controls.Add(footnote, 0, 2);
        Controls.Add(root);
    }

    private static Control CreateHeading(string gameName, Action? onBack)
    {
        var heading = new Panel { Dock = DockStyle.Fill, BackColor = Canvas };
        var backButton = new Button
        {
            Text = "‹   Back to games",
            Location = new Point(0, 0),
            Size = new Size(150, 30),
            FlatStyle = FlatStyle.Flat,
            BackColor = Canvas,
            ForeColor = MutedText,
            Font = new Font("Segoe UI", 9F, FontStyle.Bold),
            Cursor = Cursors.Hand
        };
        backButton.FlatAppearance.BorderSize = 0;
        backButton.FlatAppearance.MouseOverBackColor = Color.FromArgb(29, 27, 44);
        backButton.Click += (_, _) => onBack?.Invoke();
        heading.Controls.Add(backButton);

        var gameIcon = new GameBadgeControl(gameName)
        {
            Location = new Point(0, 44),
            Size = new Size(52, 52),
            Anchor = AnchorStyles.Top | AnchorStyles.Left
        };
        heading.Controls.Add(gameIcon);
        var title = new Label
        {
            Text = "Choose Your Game Mode",
            ForeColor = Color.White,
            Font = new Font("Segoe UI", 21F, FontStyle.Bold),
            AutoSize = true,
            Location = new Point(66, 43)
        };
        heading.Controls.Add(title);
        heading.Controls.Add(new Label
        {
            Text = $"{gameName}  ·  Pick how you want to play",
            ForeColor = MutedText,
            Font = new Font("Segoe UI", 9.5F),
            AutoSize = true,
            Location = new Point(68, 80)
        });
        heading.Resize += (_, _) =>
        {
            title.MaximumSize = new Size(Math.Max(180, heading.ClientSize.Width - 70), 0);
        };
        return heading;
    }

    private static Panel CreateOption(
        ModeIconKind icon,
        string eyebrow,
        string title,
        string summary,
        string detail,
        string actionText,
        Color accent,
        Action action)
    {
        var card = new ModeCardPanel(accent)
        {
            Dock = DockStyle.Fill,
            Margin = new Padding(0, 5, 12, 4),
            Padding = new Padding(22, 20, 22, 20)
        };
        var content = new TableLayoutPanel
        {
            Dock = DockStyle.Fill,
            ColumnCount = 1,
            RowCount = 5,
            BackColor = Color.Transparent,
            Margin = Padding.Empty,
            Padding = Padding.Empty
        };
        content.RowStyles.Add(new RowStyle(SizeType.Absolute, 102));
        content.RowStyles.Add(new RowStyle(SizeType.Absolute, 25));
        content.RowStyles.Add(new RowStyle(SizeType.Absolute, 43));
        content.RowStyles.Add(new RowStyle(SizeType.Percent, 100));
        content.RowStyles.Add(new RowStyle(SizeType.Absolute, 48));
        content.Controls.Add(new ModeIconControl(icon, accent) { Dock = DockStyle.Fill }, 0, 0);
        content.Controls.Add(new Label
        {
            Text = eyebrow,
            Dock = DockStyle.Fill,
            ForeColor = accent,
            Font = new Font("Segoe UI", 8F, FontStyle.Bold),
            TextAlign = ContentAlignment.MiddleLeft,
            BackColor = Color.Transparent
        }, 0, 1);
        content.Controls.Add(new Label
        {
            Text = title,
            Dock = DockStyle.Fill,
            ForeColor = Color.White,
            Font = new Font("Segoe UI", 18F, FontStyle.Bold),
            TextAlign = ContentAlignment.MiddleLeft,
            BackColor = Color.Transparent
        }, 0, 2);

        var description = new TableLayoutPanel
        {
            Dock = DockStyle.Fill,
            ColumnCount = 1,
            RowCount = 2,
            BackColor = Color.Transparent,
            Margin = new Padding(0, 7, 0, 0)
        };
        description.RowStyles.Add(new RowStyle(SizeType.AutoSize));
        description.RowStyles.Add(new RowStyle(SizeType.AutoSize));
        description.Controls.Add(new Label
        {
            Text = summary,
            Dock = DockStyle.Top,
            AutoSize = true,
            ForeColor = Color.FromArgb(221, 223, 238),
            Font = new Font("Segoe UI", 10F, FontStyle.Bold),
            MaximumSize = new Size(410, 0),
            BackColor = Color.Transparent
        }, 0, 0);
        description.Controls.Add(new Label
        {
            Text = detail,
            Dock = DockStyle.Top,
            AutoSize = true,
            ForeColor = MutedText,
            Font = new Font("Segoe UI", 9F),
            MaximumSize = new Size(410, 0),
            Margin = new Padding(0, 10, 0, 0),
            BackColor = Color.Transparent
        }, 0, 1);
        content.Controls.Add(description, 0, 3);

        var button = new Button
        {
            Text = $"{actionText}    ›",
            Dock = DockStyle.Fill,
            BackColor = accent,
            ForeColor = Color.White,
            FlatStyle = FlatStyle.Flat,
            Font = new Font("Segoe UI", 9.5F, FontStyle.Bold),
            Cursor = Cursors.Hand,
            Margin = new Padding(0, 6, 0, 0)
        };
        button.FlatAppearance.BorderSize = 0;
        var hover = ControlPaint.Light(accent, 0.12F);
        button.MouseEnter += (_, _) => button.BackColor = hover;
        button.MouseLeave += (_, _) => button.BackColor = accent;
        button.Click += (_, _) => action();
        content.Controls.Add(button, 0, 4);
        card.Controls.Add(content);
        AttachHover(card, card);
        return card;
    }

    private void UpdateResponsiveLayout()
    {
        var stacked = _choices.ClientSize.Width < 680;
        _choices.SuspendLayout();
        _choices.Controls.Remove(_roomCard);
        _choices.Controls.Remove(_localCard);
        _choices.ColumnCount = stacked ? 1 : 2;
        _choices.RowCount = stacked ? 2 : 1;
        _choices.ColumnStyles.Clear();
        _choices.RowStyles.Clear();
        if (stacked)
        {
            _choices.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100));
            _choices.RowStyles.Add(new RowStyle(SizeType.Percent, 50));
            _choices.RowStyles.Add(new RowStyle(SizeType.Percent, 50));
            _localCard.Margin = new Padding(0, 2, 0, 8);
            _roomCard.Margin = new Padding(0, 0, 0, 2);
            _choices.Controls.Add(_localCard, 0, 0);
            _choices.Controls.Add(_roomCard, 0, 1);
        }
        else
        {
            _choices.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 50));
            _choices.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 50));
            _choices.RowStyles.Add(new RowStyle(SizeType.Percent, 100));
            _localCard.Margin = new Padding(0, 5, 12, 4);
            _roomCard.Margin = new Padding(0, 5, 0, 4);
            _choices.Controls.Add(_localCard, 0, 0);
            _choices.Controls.Add(_roomCard, 1, 0);
        }
        _choices.ResumeLayout(true);
    }

    private static void AttachHover(Control control, ModeCardPanel card)
    {
        control.MouseEnter += (_, _) => card.SetHovered(true);
        control.MouseLeave += (_, _) => card.SetHovered(card.ClientRectangle.Contains(card.PointToClient(Cursor.Position)));
        foreach (Control child in control.Controls)
        {
            AttachHover(child, card);
        }
    }

    private enum ModeIconKind
    {
        Local,
        Network
    }

    private sealed class ModeIconControl : Control
    {
        private readonly ModeIconKind _kind;
        private readonly Color _accent;

        public ModeIconControl(ModeIconKind kind, Color accent)
        {
            _kind = kind;
            _accent = accent;
            SetStyle(ControlStyles.UserPaint | ControlStyles.AllPaintingInWmPaint | ControlStyles.OptimizedDoubleBuffer | ControlStyles.ResizeRedraw, true);
        }

        protected override void OnPaint(PaintEventArgs e)
        {
            base.OnPaint(e);
            var graphics = e.Graphics;
            graphics.SmoothingMode = SmoothingMode.AntiAlias;
            var badge = new RectangleF(0, 8, 76, 76);
            using var fill = new SolidBrush(Color.FromArgb(36, _accent));
            using var outline = new Pen(Color.FromArgb(92, _accent), 1.2F);
            using var rounded = CreateRoundedRectangle(badge, 20);
            graphics.FillPath(fill, rounded);
            graphics.DrawPath(outline, rounded);
            if (_kind == ModeIconKind.Local)
            {
                DrawController(graphics, badge);
            }
            else
            {
                DrawNetwork(graphics, badge);
            }
        }

        private void DrawController(Graphics graphics, RectangleF badge)
        {
            var centerX = badge.Left + badge.Width / 2;
            var centerY = badge.Top + badge.Height / 2 + 2;
            using var pen = new Pen(_accent, 3F) { StartCap = LineCap.Round, EndCap = LineCap.Round, LineJoin = LineJoin.Round };
            using var controller = new GraphicsPath();
            controller.AddBezier(centerX - 23, centerY - 5, centerX - 24, centerY + 1, centerX - 27, centerY + 17, centerX - 19, centerY + 17);
            controller.AddLine(centerX - 19, centerY + 17, centerX - 9, centerY + 9);
            controller.AddLine(centerX - 9, centerY + 9, centerX + 9, centerY + 9);
            controller.AddLine(centerX + 9, centerY + 9, centerX + 19, centerY + 17);
            controller.AddBezier(centerX + 19, centerY + 17, centerX + 27, centerY + 17, centerX + 24, centerY + 1, centerX + 23, centerY - 5);
            controller.AddBezier(centerX + 23, centerY - 5, centerX + 22, centerY - 12, centerX + 15, centerY - 13, centerX + 8, centerY - 10);
            controller.AddLine(centerX + 8, centerY - 10, centerX - 8, centerY - 10);
            controller.AddBezier(centerX - 8, centerY - 10, centerX - 15, centerY - 13, centerX - 22, centerY - 12, centerX - 23, centerY - 5);
            graphics.DrawPath(pen, controller);
            graphics.DrawLine(pen, centerX - 15, centerY - 1, centerX - 15, centerY + 7);
            graphics.DrawLine(pen, centerX - 19, centerY + 3, centerX - 11, centerY + 3);
            using var dot = new SolidBrush(_accent);
            graphics.FillEllipse(dot, centerX + 9, centerY - 3, 5, 5);
            graphics.FillEllipse(dot, centerX + 16, centerY + 3, 5, 5);
        }

        private void DrawNetwork(Graphics graphics, RectangleF badge)
        {
            var centerX = badge.Left + badge.Width / 2;
            var centerY = badge.Top + badge.Height / 2 + 15;
            using var pen = new Pen(_accent, 3F) { StartCap = LineCap.Round, EndCap = LineCap.Round };
            graphics.DrawArc(pen, centerX - 25, centerY - 34, 50, 42, 225, 90);
            graphics.DrawArc(pen, centerX - 17, centerY - 25, 34, 29, 225, 90);
            graphics.DrawArc(pen, centerX - 9, centerY - 16, 18, 16, 225, 90);
            using var dot = new SolidBrush(_accent);
            graphics.FillEllipse(dot, centerX - 3, centerY + 3, 6, 6);
        }
    }

    private sealed class GameBadgeControl : Control
    {
        private readonly string _gameName;

        public GameBadgeControl(string gameName)
        {
            _gameName = gameName;
            SetStyle(ControlStyles.UserPaint | ControlStyles.AllPaintingInWmPaint | ControlStyles.OptimizedDoubleBuffer | ControlStyles.ResizeRedraw, true);
        }

        protected override void OnPaint(PaintEventArgs e)
        {
            base.OnPaint(e);
            var graphics = e.Graphics;
            graphics.SmoothingMode = SmoothingMode.AntiAlias;
            using var path = CreateRoundedRectangle(new RectangleF(1, 1, Width - 2, Height - 2), 14);
            using var fill = new LinearGradientBrush(ClientRectangle, Color.FromArgb(91, 52, 144), Color.FromArgb(42, 84, 139), 20F);
            graphics.FillPath(fill, path);
            var glyph = _gameName switch { "Chess" => "♞", "Ludo" => "●", _ => "⌗" };
            using var font = new Font("Segoe UI Symbol", 24F, FontStyle.Bold);
            using var brush = new SolidBrush(Color.White);
            using var format = new StringFormat { Alignment = StringAlignment.Center, LineAlignment = StringAlignment.Center };
            graphics.DrawString(glyph, font, brush, ClientRectangle, format);
        }
    }

    private sealed class ModeCardPanel : Panel
    {
        private readonly Color _accent;
        private bool _hovered;

        public ModeCardPanel(Color accent)
        {
            _accent = accent;
            BackColor = Canvas;
            SetStyle(ControlStyles.UserPaint | ControlStyles.AllPaintingInWmPaint | ControlStyles.OptimizedDoubleBuffer | ControlStyles.ResizeRedraw, true);
        }

        public void SetHovered(bool hovered)
        {
            if (_hovered == hovered)
            {
                return;
            }
            _hovered = hovered;
            Invalidate();
        }

        protected override void OnPaintBackground(PaintEventArgs e)
        {
            if (ClientSize.Width < 2 || ClientSize.Height < 2)
            {
                return;
            }

            var graphics = e.Graphics;
            graphics.SmoothingMode = SmoothingMode.AntiAlias;
            var bounds = new RectangleF(0.5F, 0.5F, ClientSize.Width - 1, ClientSize.Height - 1);
            using var path = CreateRoundedRectangle(bounds, 18);
            using var fill = new LinearGradientBrush(bounds, Color.FromArgb(31, 31, 49), Color.FromArgb(24, 29, 44), 24F);
            graphics.FillPath(fill, path);
            using var border = new Pen(Color.FromArgb(_hovered ? 180 : 72, _accent), _hovered ? 1.6F : 1F);
            graphics.DrawPath(border, path);
            if (_hovered)
            {
                using var accentLine = new Pen(Color.FromArgb(190, _accent), 2F);
                graphics.DrawLine(accentLine, bounds.X + 20, bounds.Y + 1, bounds.Right - 20, bounds.Y + 1);
            }
        }
    }

    private static GraphicsPath CreateRoundedRectangle(RectangleF bounds, float radius)
    {
        var path = new GraphicsPath();
        var diameter = radius * 2;
        path.AddArc(bounds.X, bounds.Y, diameter, diameter, 180, 90);
        path.AddArc(bounds.Right - diameter, bounds.Y, diameter, diameter, 270, 90);
        path.AddArc(bounds.Right - diameter, bounds.Bottom - diameter, diameter, diameter, 0, 90);
        path.AddArc(bounds.X, bounds.Bottom - diameter, diameter, diameter, 90, 90);
        path.CloseFigure();
        return path;
    }
}
