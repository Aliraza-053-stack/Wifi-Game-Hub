using WiFiGameHub.Networking;
using System.Drawing.Drawing2D;
using System.Drawing.Text;

namespace WiFiGameHub.Forms;

public sealed class DashboardForm : Form
{
    private static readonly Color Canvas = Color.FromArgb(15, 16, 28);
    private static readonly Color MutedText = Color.FromArgb(158, 165, 190);
    private static readonly Color Accent = Color.FromArgb(145, 92, 246);
    private static readonly Color BlueAccent = Color.FromArgb(69, 150, 255);
    private readonly Action<string> _navigate;
    private readonly MultiplayerSession? _session;
    private readonly Label _playersValue = new();
    private readonly Label _playersDetail = new();
    private readonly Label _roomValue = new();
    private readonly Label _roomDetail = new();
    private readonly Label _discoveryValue = new();
    private readonly Label _discoveryDetail = new();
    private readonly Label _gameSectionTitle = new();
    private TableLayoutPanel? _rootLayout;

    public DashboardForm(Action<string> navigate, MultiplayerSession? session = null)
    {
        _navigate = navigate;
        _session = session;
        Text = "Dashboard";
        BackColor = Canvas;
        ForeColor = Color.White;
        FormBorderStyle = FormBorderStyle.None;
        Dock = DockStyle.Fill;
        Padding = new Padding(2);

        var root = new TableLayoutPanel
        {
            Dock = DockStyle.Fill,
            ColumnCount = 1,
            RowCount = 5,
            BackColor = Canvas,
            Padding = Padding.Empty,
            Margin = Padding.Empty
        };
        root.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100));
        root.RowStyles.Add(new RowStyle(SizeType.Absolute, 136));
        root.RowStyles.Add(new RowStyle(SizeType.Absolute, 104));
        root.RowStyles.Add(new RowStyle(SizeType.Absolute, 48));
        root.RowStyles.Add(new RowStyle(SizeType.Percent, 100));
        root.RowStyles.Add(new RowStyle(SizeType.Absolute, 44));
        _rootLayout = root;

        root.Controls.Add(CreateWelcomePanel(), 0, 0);
        root.Controls.Add(CreateStatusStrip(), 0, 1);
        root.Controls.Add(CreateSectionHeading(), 0, 2);
        root.Controls.Add(CreateGameCards(), 0, 3);
        root.Controls.Add(CreateDashboardFooter(), 0, 4);
        Controls.Add(root);

        if (_session is not null)
        {
            _session.StateChanged += Session_StateChanged;
            _session.ConnectionChanged += Session_ConnectionChanged;
            Disposed += (_, _) =>
            {
                _session.StateChanged -= Session_StateChanged;
                _session.ConnectionChanged -= Session_ConnectionChanged;
            };
            UpdateSessionSummary(_session.CurrentState);
        }
    }

    private Control CreateWelcomePanel()
    {
        var welcome = new GradientWelcomePanel
        {
            Dock = DockStyle.Fill,
            Margin = new Padding(0, 0, 0, 12),
            Padding = new Padding(26, 12, 22, 12)
        };
        var layout = new TableLayoutPanel
        {
            Dock = DockStyle.Fill,
            ColumnCount = 2,
            RowCount = 3,
            BackColor = Color.Transparent,
            Margin = Padding.Empty,
            Padding = Padding.Empty
        };
        layout.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 70));
        layout.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 30));
        layout.RowStyles.Add(new RowStyle(SizeType.Absolute, 24));
        layout.RowStyles.Add(new RowStyle(SizeType.Absolute, 42));
        layout.RowStyles.Add(new RowStyle(SizeType.Percent, 100));
        layout.Controls.Add(new Label
        {
            Text = "WIFI GAME HUB  /  YOUR PLAY SPACE",
            Dock = DockStyle.Fill,
            ForeColor = Color.FromArgb(220, 207, 255),
            Font = new Font("Segoe UI", 8.5F, FontStyle.Bold),
            TextAlign = ContentAlignment.MiddleLeft,
            BackColor = Color.Transparent
        }, 0, 0);
        layout.SetColumnSpan(layout.Controls[0], 2);
        layout.Controls.Add(new Label
        {
            Text = "Ready for your next match?",
            Dock = DockStyle.Fill,
            ForeColor = Color.White,
            Font = new Font("Segoe UI", 21F, FontStyle.Bold),
            TextAlign = ContentAlignment.MiddleLeft,
            BackColor = Color.Transparent,
            AutoEllipsis = true
        }, 0, 1);
        layout.Controls.Add(new Label
        {
            Text = "Choose a game for local play, or invite friends to a room.",
            Dock = DockStyle.Fill,
            ForeColor = Color.FromArgb(225, 222, 241),
            Font = new Font("Segoe UI", 9.5F),
            TextAlign = ContentAlignment.MiddleLeft,
            BackColor = Color.Transparent
        }, 0, 2);
        var roomButton = CreateActionButton("Play with friends", Color.FromArgb(38, 37, 61));
        roomButton.Margin = new Padding(8, 8, 0, 8);
        roomButton.FlatAppearance.BorderColor = Color.FromArgb(116, 95, 183);
        roomButton.FlatAppearance.BorderSize = 1;
        roomButton.Click += (_, _) => _navigate("Multiplayer");
        layout.Controls.Add(roomButton, 1, 1);
        layout.SetRowSpan(roomButton, 2);
        welcome.Controls.Add(layout);
        return welcome;
    }

    private Control CreateStatusStrip()
    {
        var strip = new TableLayoutPanel
        {
            Dock = DockStyle.Fill,
            ColumnCount = 4,
            RowCount = 1,
            BackColor = Canvas,
            Margin = new Padding(0, 0, 0, 10),
            Padding = Padding.Empty
        };
        for (var index = 0; index < 4; index++)
        {
            strip.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 25F));
        }

        var gamesValue = new Label { Text = "4 games" };
        var gamesDetail = new Label { Text = "Chess · Ludo · Tic-Tac-Toe · Carrom" };
        strip.Controls.Add(CreateMetric("GAMES", gamesValue, gamesDetail, BlueAccent), 0, 0);
        _playersValue.Text = "0 / 2";
        _playersDetail.Text = "No room connected";
        strip.Controls.Add(CreateMetric("PLAYERS", _playersValue, _playersDetail, Color.FromArgb(69, 201, 174)), 1, 0);
        _roomValue.Text = "Offline";
        _roomDetail.Text = "No active room";
        strip.Controls.Add(CreateMetric("ACTIVE ROOM", _roomValue, _roomDetail, Accent), 2, 0);
        _discoveryValue.Text = "Not started";
        _discoveryDetail.Text = "Open Multiplayer Rooms to scan";
        strip.Controls.Add(CreateMetric("ROOM SEARCH", _discoveryValue, _discoveryDetail, BlueAccent), 3, 0);
        return strip;
    }

    public void SetDiscoveryStatus(string status, string detail)
    {
        _discoveryValue.Text = status;
        _discoveryDetail.Text = detail;
    }

    public void SetGamesFocus(bool gamesOnly)
    {
        if (_rootLayout is null)
        {
            return;
        }

        _rootLayout.RowStyles[0] = new RowStyle(SizeType.Absolute, gamesOnly ? 0 : 136);
        _rootLayout.RowStyles[1] = new RowStyle(SizeType.Absolute, gamesOnly ? 0 : 104);
        _rootLayout.RowStyles[2] = new RowStyle(SizeType.Absolute, 58);
        _rootLayout.RowStyles[3] = new RowStyle(SizeType.Percent, 100);
        _rootLayout.RowStyles[4] = new RowStyle(SizeType.Absolute, 44);
        _gameSectionTitle.Text = gamesOnly ? "All games" : "Featured games";
    }

    private static Control CreateDashboardFooter()
    {
        var footer = new TableLayoutPanel
        {
            Dock = DockStyle.Fill,
            ColumnCount = 2,
            RowCount = 1,
            BackColor = Canvas,
            Padding = new Padding(4, 0, 4, 0),
            Margin = Padding.Empty
        };
        footer.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 50));
        footer.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 50));
        footer.Controls.Add(new Label
        {
            Text = "WIFI GAME HUB  ·  LOCAL PLAY  ·  LAN MULTIPLAYER",
            Dock = DockStyle.Fill,
            ForeColor = Color.FromArgb(112, 124, 151),
            Font = new Font("Segoe UI", 8F, FontStyle.Bold),
            TextAlign = ContentAlignment.MiddleLeft
        }, 0, 0);
        footer.Controls.Add(new Label
        {
            Text = "Developer: Ali Raza  ·  Project Supervisor: Sir Muhammad Abdullah",
            Dock = DockStyle.Fill,
            ForeColor = Color.FromArgb(158, 165, 190),
            Font = new Font("Segoe UI", 8F),
            TextAlign = ContentAlignment.MiddleRight
        }, 1, 0);
        return footer;
    }

    private Control CreateSectionHeading()
    {
        var heading = new TableLayoutPanel
        {
            Dock = DockStyle.Fill,
            ColumnCount = 1,
            RowCount = 1,
            BackColor = Canvas,
            Margin = Padding.Empty,
            Padding = new Padding(0, 4, 0, 0)
        };
        heading.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100));
        _gameSectionTitle.Text = "Featured games";
        _gameSectionTitle.Dock = DockStyle.Fill;
        _gameSectionTitle.ForeColor = Color.White;
        _gameSectionTitle.Font = new Font("Segoe UI", 15F, FontStyle.Bold);
        _gameSectionTitle.TextAlign = ContentAlignment.MiddleLeft;
        heading.Controls.Add(_gameSectionTitle, 0, 0);
        return heading;
    }

    private Control CreateGameCards()
    {
        var cards = new TableLayoutPanel
        {
            Dock = DockStyle.Fill,
            ColumnCount = 4,
            RowCount = 1,
            BackColor = Canvas,
            Margin = Padding.Empty,
            Padding = Padding.Empty
        };
        for (var index = 0; index < 4; index++)
        {
            cards.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 25F));
        }
        var games = new[]
        {
            CreateGameCard("Chess", "Classic strategy for two players.", "Chess", Accent, GameIconKind.Chess),
            CreateGameCard("Ludo", "A colorful race for 2–4 players.", "Ludo", BlueAccent, GameIconKind.Ludo),
            CreateGameCard("Tic-Tac-Toe", "A quick strategy match for two.", "Tic Tac Toe", Color.FromArgb(116, 127, 255), GameIconKind.TicTacToe),
            CreateGameCard("Carrom", "Neon-styled local practice board.", "Carrom", Color.FromArgb(60, 205, 220), GameIconKind.Carrom)
        };
        for (var index = 0; index < games.Length; index++)
        {
            games[index].Margin = new Padding(0, 0, index == games.Length - 1 ? 0 : 8, 0);
            cards.Controls.Add(games[index], index, 0);
        }
        return cards;
    }

    private Control CreateGameCard(string title, string description, string page, Color accent, GameIconKind icon)
    {
        var card = new DashboardCardPanel(accent)
        {
            Dock = DockStyle.Fill,
            Margin = new Padding(0, 2, 12, 8),
            Padding = new Padding(17, 15, 17, 16)
        };
        var content = new TableLayoutPanel
        {
            Dock = DockStyle.Fill,
            ColumnCount = 1,
            RowCount = 4,
            BackColor = Color.Transparent,
            Margin = Padding.Empty,
            Padding = Padding.Empty
        };
        content.RowStyles.Add(new RowStyle(SizeType.Absolute, 36));
        content.RowStyles.Add(new RowStyle(SizeType.Absolute, 38));
        content.RowStyles.Add(new RowStyle(SizeType.Percent, 100));
        content.RowStyles.Add(new RowStyle(SizeType.Absolute, 42));
        content.Controls.Add(new Label
        {
            Text = title,
            Dock = DockStyle.Fill,
            ForeColor = Color.White,
            Font = new Font("Segoe UI", 16F, FontStyle.Bold),
            TextAlign = ContentAlignment.MiddleLeft,
            BackColor = Color.Transparent
        }, 0, 0);
        content.Controls.Add(new Label
        {
            Text = description,
            Dock = DockStyle.Fill,
            ForeColor = MutedText,
            Font = new Font("Segoe UI", 9.5F),
            TextAlign = ContentAlignment.MiddleLeft,
            BackColor = Color.Transparent
        }, 0, 1);
        content.Controls.Add(new GamePreviewControl(icon, accent)
        {
            Name = $"{page.Replace(" ", string.Empty)}Preview",
            Dock = DockStyle.Fill,
            Margin = new Padding(0, 2, 0, 10)
        }, 0, 2);
        var open = CreateActionButton("Play Now  ›", accent);
        open.Click += (_, _) => _navigate(page);
        content.Controls.Add(open, 0, 3);
        card.Controls.Add(content);
        AttachHoverHandlers(card, card);
        return card;
    }

    private Control CreateMetric(string title, Label value, Label? detail, Color accent)
    {
        var card = new DashboardCardPanel(accent)
        {
            Dock = DockStyle.Fill,
            Margin = new Padding(0, 0, 10, 0),
            Padding = new Padding(13, 9, 10, 8)
        };
        var accentLine = new Panel { Dock = DockStyle.Left, Width = 3, BackColor = accent, Margin = new Padding(0, 0, 10, 0) };
        var content = new TableLayoutPanel
        {
            Dock = DockStyle.Fill,
            ColumnCount = 1,
            RowCount = detail is null ? 2 : 3,
            BackColor = Color.Transparent,
            Margin = Padding.Empty
        };
        content.RowStyles.Add(new RowStyle(SizeType.Percent, 32));
        content.RowStyles.Add(new RowStyle(SizeType.Percent, 38));
        if (detail is not null)
        {
            content.RowStyles.Add(new RowStyle(SizeType.Percent, 30));
        }
        content.Controls.Add(CreateEyebrow(title), 0, 0);
        value.Dock = DockStyle.Fill;
        value.ForeColor = Color.White;
        value.Font = new Font("Segoe UI", 11F, FontStyle.Bold);
        value.AutoEllipsis = true;
        value.TextAlign = ContentAlignment.MiddleLeft;
        content.Controls.Add(value, 0, 1);
        if (detail is not null)
        {
            detail.Dock = DockStyle.Fill;
            detail.ForeColor = MutedText;
            detail.Font = new Font("Segoe UI", 8F);
            detail.AutoEllipsis = true;
            detail.TextAlign = ContentAlignment.MiddleLeft;
            content.Controls.Add(detail, 0, 2);
        }
        card.Controls.Add(content);
        card.Controls.Add(accentLine);
        AttachHoverHandlers(card, card);
        return card;
    }

    private static void AttachHoverHandlers(Control control, DashboardCardPanel card)
    {
        control.MouseEnter += (_, _) => card.SetHovered(true);
        control.MouseLeave += (_, _) =>
            card.SetHovered(card.ClientRectangle.Contains(card.PointToClient(Cursor.Position)));
        foreach (Control child in control.Controls)
        {
            AttachHoverHandlers(child, card);
        }
    }

    private static Label CreateEyebrow(string text) => new()
    {
        Text = text,
        ForeColor = Color.FromArgb(151, 164, 188),
        Font = new Font("Segoe UI", 8F, FontStyle.Bold),
        AutoSize = true
    };

    private static Button CreateActionButton(string text, Color color)
    {
        var button = new Button
        {
            Text = text,
            Dock = DockStyle.Fill,
            BackColor = color,
            ForeColor = Color.White,
            FlatStyle = FlatStyle.Flat,
            Font = new Font("Segoe UI", 9F, FontStyle.Bold),
            Cursor = Cursors.Hand,
            Margin = Padding.Empty
        };
        button.FlatAppearance.BorderSize = 0;
        var hover = ControlPaint.Light(color, 0.12f);
        button.MouseEnter += (_, _) => button.BackColor = hover;
        button.MouseLeave += (_, _) => button.BackColor = color;
        return button;
    }

    private void Session_StateChanged(GameSessionState state)
    {
        if (InvokeRequired)
        {
            BeginInvoke(() => Session_StateChanged(state));
            return;
        }
        UpdateSessionSummary(state);
    }

    private void Session_ConnectionChanged(bool connected)
    {
        if (InvokeRequired)
        {
            BeginInvoke(() => Session_ConnectionChanged(connected));
            return;
        }
        UpdateSessionSummary(_session?.CurrentState);
    }

    private void UpdateSessionSummary(GameSessionState? state)
    {
        if (_session?.IsActive != true || state is null)
        {
            _playersValue.Text = "0 / 2";
            _playersDetail.Text = "No room connected";
            _roomValue.Text = "Offline";
            _roomDetail.Text = "No active room";
            return;
        }

        var connectedPlayers = state.Players.Count(player => player.Connected);
        var capacity = state.Game == "Ludo" ? 4 : 2;
        _playersValue.Text = $"{connectedPlayers} / {capacity}";
        _playersDetail.Text = connectedPlayers == 1 ? "1 player connected" : $"{connectedPlayers} players connected";
        _roomValue.Text = state.Game == "Chat" ? "Chat room" : state.IsGameOver ? $"{state.Game} complete" : state.Started ? $"{state.Game} in progress" : "Waiting";
        _roomDetail.Text = state.Game == "Chat" ? "Messaging room active" : state.IsGameOver ? "Match has ended" : state.Started ? "Match in progress" : "Room created; awaiting players";
    }

    private enum GameIconKind
    {
        Chess,
        Ludo,
        TicTacToe,
        Carrom
    }

    private sealed class GamePreviewControl : Control
    {
        private readonly GameIconKind _kind;
        private readonly Color _accent;

        public GamePreviewControl(GameIconKind kind, Color accent)
        {
            _kind = kind;
            _accent = accent;
            SetStyle(ControlStyles.UserPaint | ControlStyles.AllPaintingInWmPaint | ControlStyles.OptimizedDoubleBuffer | ControlStyles.ResizeRedraw | ControlStyles.SupportsTransparentBackColor, true);
            BackColor = Color.Transparent;
        }

        protected override void OnPaint(PaintEventArgs e)
        {
            base.OnPaint(e);
            var graphics = e.Graphics;
            graphics.SmoothingMode = SmoothingMode.AntiAlias;
            graphics.TextRenderingHint = TextRenderingHint.AntiAliasGridFit;
            if (ClientSize.Width < 30 || ClientSize.Height < 30)
            {
                return;
            }

            var surface = new RectangleF(1, 1, ClientSize.Width - 2, ClientSize.Height - 2);
            using (var background = new LinearGradientBrush(surface, Color.FromArgb(31, 31, 49), Color.FromArgb(19, 24, 40), 90F))
            using (var surfacePath = RoundedRectangle(surface, 14))
            using (var outline = new Pen(Color.FromArgb(50, _accent), 1F))
            using (var glow = new SolidBrush(Color.FromArgb(20, _accent)))
            {
                graphics.FillPath(background, surfacePath);
                graphics.FillEllipse(glow, surface.X + surface.Width * 0.26F, surface.Y + surface.Height * 0.04F,
                    surface.Width * 0.48F, surface.Height * 0.78F);
                graphics.DrawPath(outline, surfacePath);
            }

            switch (_kind)
            {
                case GameIconKind.Chess:
                    DrawChessPreview(graphics, surface);
                    break;
                case GameIconKind.Ludo:
                    DrawLudoPreview(graphics, surface);
                    break;
                case GameIconKind.TicTacToe:
                    DrawTicTacToePreview(graphics, surface);
                    break;
                case GameIconKind.Carrom:
                    DrawCarromPreview(graphics, surface);
                    break;
            }
        }

        private static void DrawCarromPreview(Graphics graphics, RectangleF surface)
        {
            var boardWidth = Math.Min(surface.Width * 0.78F, surface.Height * 1.18F);
            var boardHeight = boardWidth * 0.84F;
            if (boardWidth < 48 || boardHeight < 40)
            {
                return;
            }

            var board = new RectangleF(
                surface.X + (surface.Width - boardWidth) / 2F,
                surface.Y + (surface.Height - boardHeight) / 2F,
                boardWidth,
                boardHeight);
            var frame = new RectangleF(board.X - 8, board.Y - 8, board.Width + 16, board.Height + 16);
            using (var glow = new SolidBrush(Color.FromArgb(32, 60, 205, 220)))
            using (var framePath = RoundedRectangle(frame, 12))
            using (var frameBrush = new LinearGradientBrush(frame, Color.FromArgb(74, 49, 118), Color.FromArgb(35, 122, 147), 35F))
            using (var frameBorder = new Pen(Color.FromArgb(160, 74, 212, 226), 2F))
            {
                graphics.FillEllipse(glow, frame.X - 8, frame.Y - 4, frame.Width + 16, frame.Height + 8);
                graphics.FillPath(frameBrush, framePath);
                graphics.DrawPath(frameBorder, framePath);
            }
            using (var woodPath = RoundedRectangle(board, 7))
            using (var woodBrush = new LinearGradientBrush(board, Color.FromArgb(218, 173, 120), Color.FromArgb(160, 104, 73), 40F))
            {
                graphics.FillPath(woodBrush, woodPath);
            }

            var center = new PointF(board.X + board.Width / 2F, board.Y + board.Height / 2F);
            var markSize = Math.Min(board.Width, board.Height) * 0.4F;
            using var markPen = new Pen(Color.FromArgb(165, 86, 51, 53), Math.Max(1F, board.Width * 0.012F));
            graphics.DrawEllipse(markPen, center.X - markSize / 2F, center.Y - markSize / 2F, markSize, markSize);
            graphics.DrawEllipse(markPen, center.X - markSize * 0.3F, center.Y - markSize * 0.3F, markSize * 0.6F, markSize * 0.6F);
            using var baseline = new Pen(Color.FromArgb(175, 57, 224, 232), Math.Max(1.2F, board.Width * 0.014F));
            var baselineY = board.Bottom - board.Height * 0.18F;
            graphics.DrawLine(baseline, board.X + board.Width * 0.18F, baselineY, board.Right - board.Width * 0.18F, baselineY);

            var coinSize = Math.Max(4F, board.Width * 0.055F);
            DrawCarromCoin(graphics, center.X, center.Y, coinSize, Color.FromArgb(176, 49, 81));
            for (var index = 0; index < 9; index++)
            {
                var angle = index * MathF.Tau / 9F;
                DrawCarromCoin(graphics, center.X + MathF.Cos(angle) * markSize * 0.26F,
                    center.Y + MathF.Sin(angle) * markSize * 0.26F, coinSize * 0.82F,
                    index % 2 == 0 ? Color.FromArgb(237, 236, 229) : Color.FromArgb(39, 38, 51));
            }

            var pocketSize = Math.Max(7F, board.Width * 0.1F);
            using var pocketGlow = new SolidBrush(Color.FromArgb(85, 49, 222, 235));
            using var pocket = new SolidBrush(Color.FromArgb(230, 22, 18, 30));
            foreach (var (x, y) in new[]
            {
                (board.X + 3, board.Y + 3), (board.Right - 3, board.Y + 3),
                (board.X + 3, board.Bottom - 3), (board.Right - 3, board.Bottom - 3)
            })
            {
                graphics.FillEllipse(pocketGlow, x - pocketSize * 0.7F, y - pocketSize * 0.7F, pocketSize * 1.4F, pocketSize * 1.4F);
                graphics.FillEllipse(pocket, x - pocketSize / 2F, y - pocketSize / 2F, pocketSize, pocketSize);
            }

            DrawCarromCoin(graphics, center.X, baselineY, coinSize * 1.18F, Color.FromArgb(121, 190, 245));
        }

        private static void DrawCarromCoin(Graphics graphics, float centerX, float centerY, float size, Color color)
        {
            var bounds = new RectangleF(centerX - size / 2F, centerY - size / 2F, size, size);
            using var fill = new LinearGradientBrush(bounds, ControlPaint.Light(color, 0.18F), color, 45F);
            using var border = new Pen(Color.FromArgb(190, 240, 245, 255), Math.Max(1F, size * 0.08F));
            graphics.FillEllipse(fill, bounds);
            graphics.DrawEllipse(border, bounds);
        }

        private static void DrawChessPreview(Graphics graphics, RectangleF surface)
        {
            var boardSize = Math.Min(surface.Height - 28, surface.Width * 0.72F);
            if (boardSize < 48)
            {
                return;
            }

            var cell = boardSize / 8F;
            var left = surface.X + (surface.Width - boardSize) / 2F;
            var top = surface.Y + (surface.Height - boardSize) / 2F;
            var board = new RectangleF(left - 5, top - 5, boardSize + 10, boardSize + 10);
            using (var shadow = new SolidBrush(Color.FromArgb(110, 0, 0, 0)))
            using (var framePath = RoundedRectangle(board, 8))
            {
                graphics.FillPath(shadow, framePath);
            }

            var light = Color.FromArgb(146, 137, 161);
            var dark = Color.FromArgb(55, 53, 78);
            for (var row = 0; row < 8; row++)
            for (var column = 0; column < 8; column++)
            {
                var square = new RectangleF(left + column * cell, top + row * cell, cell + 0.5F, cell + 0.5F);
                using var squareBrush = new SolidBrush((row + column) % 2 == 0 ? light : dark);
                graphics.FillRectangle(squareBrush, square);
            }

            using var highlight = new SolidBrush(Color.FromArgb(90, 173, 120, 255));
            graphics.FillRectangle(highlight, left + cell * 4, top + cell * 6, cell, cell);
            graphics.FillRectangle(highlight, left + cell * 4, top + cell * 4, cell, cell);

            const string whiteBackRank = "♖♘♗♕♔♗♘♖";
            const string blackBackRank = "♜♞♝♛♚♝♞♜";
            using var pieceFont = new Font("Segoe UI Symbol", cell * 0.82F, FontStyle.Regular, GraphicsUnit.Pixel);
            using var whiteBrush = new SolidBrush(Color.FromArgb(255, 248, 229));
            using var blackBrush = new SolidBrush(Color.FromArgb(31, 30, 48));
            using var format = new StringFormat { Alignment = StringAlignment.Center, LineAlignment = StringAlignment.Center };
            for (var column = 0; column < 8; column++)
            {
                var fileBounds = new RectangleF(left + column * cell, top, cell, cell);
                graphics.DrawString(blackBackRank[column].ToString(), pieceFont, blackBrush, fileBounds, format);
                fileBounds.Y += cell;
                graphics.DrawString("♟", pieceFont, blackBrush, fileBounds, format);
                fileBounds.Y = top + cell * 6;
                graphics.DrawString("♙", pieceFont, whiteBrush, fileBounds, format);
                fileBounds.Y = top + cell * 7;
                graphics.DrawString(whiteBackRank[column].ToString(), pieceFont, whiteBrush, fileBounds, format);
            }
        }

        private static void DrawLudoPreview(Graphics graphics, RectangleF surface)
        {
            var boardSize = Math.Min(surface.Height - 28, surface.Width * 0.63F);
            if (boardSize < 54)
            {
                return;
            }

            var cell = boardSize / 15F;
            var dieSize = Math.Min(cell * 2.8F, 54F);
            var groupWidth = boardSize + dieSize + 24;
            var left = surface.X + (surface.Width - groupWidth) / 2F;
            var top = surface.Y + (surface.Height - boardSize) / 2F;
            var board = new RectangleF(left, top, boardSize, boardSize);
            var boardColors = new[]
            {
                Color.FromArgb(232, 86, 101),
                Color.FromArgb(242, 188, 74),
                Color.FromArgb(64, 183, 142),
                Color.FromArgb(76, 144, 239)
            };
            using (var shadow = new SolidBrush(Color.FromArgb(105, 0, 0, 0)))
            {
                graphics.FillRectangle(shadow, board.X + 3, board.Y + 4, board.Width, board.Height);
            }
            using (var boardBrush = new SolidBrush(Color.FromArgb(224, 226, 238)))
            {
                graphics.FillRectangle(boardBrush, board);
            }

            FillLudoBase(graphics, board, cell, 0, 0, boardColors[0]);
            FillLudoBase(graphics, board, cell, 9, 0, boardColors[1]);
            FillLudoBase(graphics, board, cell, 0, 9, boardColors[2]);
            FillLudoBase(graphics, board, cell, 9, 9, boardColors[3]);

            using var pathBrush = new SolidBrush(Color.FromArgb(246, 246, 250));
            for (var index = 6; index <= 8; index++)
            {
                graphics.FillRectangle(pathBrush, board.X + index * cell, board.Y + 6 * cell, cell, cell);
                graphics.FillRectangle(pathBrush, board.X + index * cell, board.Y + 8 * cell, cell, cell);
                graphics.FillRectangle(pathBrush, board.X + 6 * cell, board.Y + index * cell, cell, cell);
                graphics.FillRectangle(pathBrush, board.X + 8 * cell, board.Y + index * cell, cell, cell);
            }

            var center = new PointF(board.X + 7.5F * cell, board.Y + 7.5F * cell);
            FillLudoHomeTriangle(graphics, boardColors[0],
                new PointF(board.X + 6 * cell, board.Y + 6 * cell),
                new PointF(board.X + 9 * cell, board.Y + 6 * cell), center);
            FillLudoHomeTriangle(graphics, boardColors[1],
                new PointF(board.X + 9 * cell, board.Y + 6 * cell),
                new PointF(board.X + 9 * cell, board.Y + 9 * cell), center);
            FillLudoHomeTriangle(graphics, boardColors[3],
                new PointF(board.X + 6 * cell, board.Y + 9 * cell),
                new PointF(board.X + 9 * cell, board.Y + 9 * cell), center);
            FillLudoHomeTriangle(graphics, boardColors[2],
                new PointF(board.X + 6 * cell, board.Y + 6 * cell),
                new PointF(board.X + 6 * cell, board.Y + 9 * cell), center);

            DrawLudoToken(graphics, board.X + 7.5F * cell, board.Y + 6.5F * cell, boardColors[0], cell * 0.66F);
            DrawLudoToken(graphics, board.X + 8.5F * cell, board.Y + 7.5F * cell, boardColors[1], cell * 0.66F);
            DrawLudoToken(graphics, board.X + 7.5F * cell, board.Y + 8.5F * cell, boardColors[2], cell * 0.66F);
            DrawLudoToken(graphics, board.X + 6.5F * cell, board.Y + 7.5F * cell, boardColors[3], cell * 0.66F);

            var die = new RectangleF(board.Right + 24, board.Y + (board.Height - dieSize) / 2F, dieSize, dieSize);
            using (var dieShadow = new SolidBrush(Color.FromArgb(100, 0, 0, 0)))
            using (var diePath = RoundedRectangle(new RectangleF(die.X + 2, die.Y + 4, die.Width, die.Height), dieSize * 0.2F))
            using (var dieBrush = new LinearGradientBrush(die, Color.White, Color.FromArgb(208, 220, 247), 45F))
            using (var dieOutline = new Pen(Color.FromArgb(104, 119, 191), 1.4F))
            using (var dieFace = RoundedRectangle(die, dieSize * 0.2F))
            {
                graphics.FillPath(dieShadow, diePath);
                graphics.FillPath(dieBrush, dieFace);
                graphics.DrawPath(dieOutline, dieFace);
            }
            using var pipBrush = new SolidBrush(Color.FromArgb(86, 82, 171));
            var pip = dieSize * 0.13F;
            foreach (var (x, y) in new[] { (0.28F, 0.28F), (0.72F, 0.28F), (0.5F, 0.5F), (0.28F, 0.72F), (0.72F, 0.72F) })
            {
                graphics.FillEllipse(pipBrush, die.X + dieSize * x - pip / 2, die.Y + dieSize * y - pip / 2, pip, pip);
            }
        }

        private static void FillLudoHomeTriangle(Graphics graphics, Color color, PointF first, PointF second, PointF center)
        {
            using var brush = new SolidBrush(color);
            graphics.FillPolygon(brush, new[] { first, second, center });
        }

        private static void FillLudoBase(Graphics graphics, RectangleF board, float cell, int column, int row, Color color)
        {
            var area = new RectangleF(board.X + column * cell, board.Y + row * cell, cell * 6, cell * 6);
            using var baseBrush = new SolidBrush(color);
            graphics.FillRectangle(baseBrush, area);
            using var homeBrush = new SolidBrush(Color.FromArgb(245, 247, 252));
            using var homePen = new Pen(Color.FromArgb(55, 45, 54, 75), Math.Max(1F, cell * 0.09F));
            var home = new RectangleF(area.X + cell, area.Y + cell, cell * 4, cell * 4);
            graphics.FillRectangle(homeBrush, home);
            graphics.DrawRectangle(homePen, home.X, home.Y, home.Width, home.Height);
            DrawLudoToken(graphics, home.X + home.Width * 0.34F, home.Y + home.Height * 0.34F, color, cell * 0.78F);
            DrawLudoToken(graphics, home.X + home.Width * 0.66F, home.Y + home.Height * 0.66F, color, cell * 0.78F);
        }

        private static void DrawLudoToken(Graphics graphics, float centerX, float centerY, Color color, float size)
        {
            var bounds = new RectangleF(centerX - size / 2F, centerY - size / 2F, size, size);
            using var shadow = new SolidBrush(Color.FromArgb(85, 0, 0, 0));
            using var tokenBrush = new LinearGradientBrush(bounds, ControlPaint.Light(color, 0.22F), color, 45F);
            using var outline = new Pen(Color.FromArgb(230, 255, 255, 255), Math.Max(1F, size * 0.1F));
            graphics.FillEllipse(shadow, bounds.X + size * 0.08F, bounds.Y + size * 0.1F, size * 0.9F, size * 0.9F);
            graphics.FillEllipse(tokenBrush, bounds);
            graphics.DrawEllipse(outline, bounds);
            using var center = new SolidBrush(Color.FromArgb(225, 255, 255, 255));
            graphics.FillEllipse(center, bounds.X + size * 0.36F, bounds.Y + size * 0.36F, size * 0.28F, size * 0.28F);
        }

        private static void DrawTicTacToePreview(Graphics graphics, RectangleF surface)
        {
            var boardSize = Math.Min(surface.Height - 28, surface.Width * 0.56F);
            if (boardSize < 54)
            {
                return;
            }

            var cell = boardSize / 3F;
            var left = surface.X + (surface.Width - boardSize) / 2F;
            var top = surface.Y + (surface.Height - boardSize) / 2F;
            var board = new RectangleF(left - 12, top - 12, boardSize + 24, boardSize + 24);
            using (var glow = new SolidBrush(Color.FromArgb(30, 110, 105, 255)))
            {
                graphics.FillEllipse(glow, board.X - 14, board.Y - 8, board.Width + 28, board.Height + 16);
            }
            using (var boardBrush = new LinearGradientBrush(board, Color.FromArgb(39, 39, 65), Color.FromArgb(22, 30, 52), 45F))
            using (var boardPath = RoundedRectangle(board, 16))
            using (var border = new Pen(Color.FromArgb(100, 126, 128, 255), 1.3F))
            {
                graphics.FillPath(boardBrush, boardPath);
                graphics.DrawPath(border, boardPath);
            }

            using var gridPen = new Pen(Color.FromArgb(145, 137, 126, 250), Math.Max(2F, boardSize * 0.014F))
            {
                StartCap = LineCap.Round,
                EndCap = LineCap.Round
            };
            graphics.DrawLine(gridPen, left + cell, top + 8, left + cell, top + boardSize - 8);
            graphics.DrawLine(gridPen, left + cell * 2, top + 8, left + cell * 2, top + boardSize - 8);
            graphics.DrawLine(gridPen, left + 8, top + cell, left + boardSize - 8, top + cell);
            graphics.DrawLine(gridPen, left + 8, top + cell * 2, left + boardSize - 8, top + cell * 2);

            var markSize = cell * 0.52F;
            DrawTicTacToeMark(graphics, new RectangleF(left, top, cell, cell), true, markSize);
            DrawTicTacToeMark(graphics, new RectangleF(left + cell, top + cell, cell, cell), false, markSize);
            DrawTicTacToeMark(graphics, new RectangleF(left + cell * 2, top + cell * 2, cell, cell), true, markSize);
        }

        private static void DrawTicTacToeMark(Graphics graphics, RectangleF cell, bool isX, float size)
        {
            var centerX = cell.X + cell.Width / 2F;
            var centerY = cell.Y + cell.Height / 2F;
            var mark = new RectangleF(centerX - size / 2F, centerY - size / 2F, size, size);
            using var pen = new Pen(isX ? Color.FromArgb(100, 181, 255) : Color.FromArgb(205, 124, 255), Math.Max(3F, size * 0.12F))
            {
                StartCap = LineCap.Round,
                EndCap = LineCap.Round
            };
            if (isX)
            {
                graphics.DrawLine(pen, mark.Left, mark.Top, mark.Right, mark.Bottom);
                graphics.DrawLine(pen, mark.Right, mark.Top, mark.Left, mark.Bottom);
            }
            else
            {
                graphics.DrawEllipse(pen, mark);
            }
        }

        private static GraphicsPath RoundedRectangle(RectangleF bounds, float radius)
        {
            var path = new GraphicsPath();
            var diameter = radius * 2;
            path.AddArc(bounds.X, bounds.Y, diameter, diameter, 180, 90);
            path.AddArc(bounds.Right - diameter, bounds.Y, diameter, diameter, 270, 90);
            path.AddArc(bounds.Right - diameter, bounds.Bottom - diameter, diameter, diameter, 0, 90);
            path.AddArc(bounds.X, bounds.Bottom - diameter, diameter, diameter, 90, 90);
            path.CloseFigure();
            return path;
        }
    }

    private sealed class GradientWelcomePanel : Panel
    {
        public GradientWelcomePanel()
        {
            SetStyle(ControlStyles.UserPaint | ControlStyles.AllPaintingInWmPaint | ControlStyles.OptimizedDoubleBuffer | ControlStyles.ResizeRedraw, true);
        }

        protected override void OnPaintBackground(PaintEventArgs e)
        {
            if (ClientSize.Width < 2 || ClientSize.Height < 2)
            {
                return;
            }

            var graphics = e.Graphics;
            graphics.SmoothingMode = SmoothingMode.AntiAlias;
            var bounds = new RectangleF(0.5F, 0.5F, ClientSize.Width - 1, ClientSize.Height - 1);
            using var path = CreateRoundedRectangle(bounds, 20);
            using var brush = new LinearGradientBrush(bounds, Color.FromArgb(105, 56, 166), Color.FromArgb(39, 93, 160), 12F);
            graphics.FillPath(brush, path);
            using var glow = new SolidBrush(Color.FromArgb(24, 187, 157, 255));
            graphics.FillEllipse(glow, bounds.Right - 190, bounds.Y - 94, 270, 230);
            using var border = new Pen(Color.FromArgb(90, 200, 176, 255));
            graphics.DrawPath(border, path);
        }
    }

    private sealed class DashboardCardPanel : Panel
    {
        private readonly Color _accent;
        private readonly System.Windows.Forms.Timer _hoverTimer;
        private bool _hovered;
        private float _hoverStrength;

        public DashboardCardPanel(Color accent)
        {
            _accent = accent;
            BackColor = Canvas;
            SetStyle(ControlStyles.UserPaint | ControlStyles.AllPaintingInWmPaint | ControlStyles.OptimizedDoubleBuffer | ControlStyles.ResizeRedraw, true);
            _hoverTimer = new System.Windows.Forms.Timer { Interval = 16 };
            _hoverTimer.Tick += (_, _) =>
            {
                var target = _hovered ? 1F : 0F;
                _hoverStrength += (target - _hoverStrength) * 0.35F;
                if (Math.Abs(target - _hoverStrength) < 0.025F)
                {
                    _hoverStrength = target;
                    _hoverTimer.Stop();
                }
                Invalidate();
            };
        }

        public void SetHovered(bool hovered)
        {
            if (_hovered == hovered)
            {
                return;
            }

            _hovered = hovered;
            _hoverTimer.Start();
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                _hoverTimer.Dispose();
            }
            base.Dispose(disposing);
        }

        protected override void OnPaintBackground(PaintEventArgs e)
        {
            if (ClientSize.Width < 2 || ClientSize.Height < 2)
            {
                return;
            }

            var graphics = e.Graphics;
            graphics.SmoothingMode = SmoothingMode.AntiAlias;
            var bounds = new RectangleF(0.5F, 0.5F, ClientSize.Width - 1, ClientSize.Height - 1);
            if (_hoverStrength > 0.01F)
            {
                using var shadow = new SolidBrush(Color.FromArgb((int)(32 * _hoverStrength), 0, 0, 0));
                using var shadowPath = CreateRoundedRectangle(new RectangleF(bounds.X + 1, bounds.Y + 3, bounds.Width - 2, bounds.Height - 3), 16);
                graphics.FillPath(shadow, shadowPath);
                using var glow = new SolidBrush(Color.FromArgb((int)(20 * _hoverStrength), _accent));
                graphics.FillEllipse(glow, bounds.X + bounds.Width * 0.18F, bounds.Y - 8, bounds.Width * 0.64F, 42);
            }
            using var path = CreateRoundedRectangle(bounds, 16);
            using var fill = new LinearGradientBrush(bounds, Color.FromArgb(31, 31, 49), Color.FromArgb(25, 30, 45), 25F);
            graphics.FillPath(fill, path);
            using var border = new Pen(Color.FromArgb((int)(64 + 111 * _hoverStrength), _accent), 1F + 0.5F * _hoverStrength);
            graphics.DrawPath(border, path);
            if (_hoverStrength > 0.01F)
            {
                using var accentLine = new Pen(Color.FromArgb((int)(80 + 110 * _hoverStrength), _accent), 1F + _hoverStrength);
                graphics.DrawLine(accentLine, bounds.X + 18, bounds.Y + 1, bounds.Right - 18, bounds.Y + 1);
            }
        }
    }

    private static GraphicsPath CreateRoundedRectangle(RectangleF bounds, float radius)
    {
        var path = new GraphicsPath();
        var diameter = radius * 2;
        path.AddArc(bounds.X, bounds.Y, diameter, diameter, 180, 90);
        path.AddArc(bounds.Right - diameter, bounds.Y, diameter, diameter, 270, 90);
        path.AddArc(bounds.Right - diameter, bounds.Bottom - diameter, diameter, diameter, 0, 90);
        path.AddArc(bounds.X, bounds.Bottom - diameter, diameter, diameter, 90, 90);
        path.CloseFigure();
        return path;
    }
}
