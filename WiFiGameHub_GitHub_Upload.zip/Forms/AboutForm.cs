namespace WiFiGameHub.Forms;

public class AboutForm : Form
{
    public AboutForm()
    {
        Text = "About";
        BackColor = Color.FromArgb(18, 18, 25);
        FormBorderStyle = FormBorderStyle.None;
        Dock = DockStyle.Fill;
        Padding = new Padding(20);

        var title = new Label
        {
            Text = "About WiFi Game Hub",
            ForeColor = Color.White,
            Font = new Font("Segoe UI", 20F, FontStyle.Bold),
            AutoSize = true,
            Dock = DockStyle.Top
        };

        var body = new Label
        {
            Text = "WiFi Game Hub is a C# Windows desktop application for board-game play and network exploration. It includes Windows Wi-Fi scanning, Chess, Ludo, Tic-Tac-Toe and a Carrom practice preview, UDP room discovery, and host-authoritative game synchronization over TCP and JSON. Cross-PC gameplay still requires manual testing on two Windows computers.\n\nDeveloper: Ali Raza\nProject Supervisor: Sir Muhammad Abdullah\nTechnologies: C#, .NET 8, Windows Forms, TCP, UDP, JSON\nVersion: 1.0",
            ForeColor = Color.FromArgb(215, 220, 235),
            Font = new Font("Segoe UI", 12F),
            AutoSize = true,
            Dock = DockStyle.Top,
            MaximumSize = new Size(760, 0),
            Padding = new Padding(0, 12, 0, 0)
        };

        Controls.Add(body);
        Controls.Add(title);
    }
}
