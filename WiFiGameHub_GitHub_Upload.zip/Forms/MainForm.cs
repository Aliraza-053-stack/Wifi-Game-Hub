using WiFiGameHub.Services;
using WiFiGameHub.Networking;

namespace WiFiGameHub.Forms;

public class MainForm : Form
{
    private static readonly Color Canvas = Color.FromArgb(15, 16, 28);
    private static readonly Color SidebarColor = Color.FromArgb(11, 12, 22);
    private static readonly Color Accent = Color.FromArgb(145, 92, 246);
    private readonly Panel _sidebar = new();
    private readonly Panel _content = new();
    private readonly Label _titleLabel = new();
    private readonly Dictionary<string, Form> _pages = new(StringComparer.Ordinal);
    private readonly Dictionary<string, Button> _navigationButtons = new(StringComparer.Ordinal);
    private readonly MultiplayerSession _multiplayerSession = new();
    private string _discoveryStatus = "Not started";
    private string _discoveryDetail = "Open Multiplayer Rooms to scan";

    private readonly bool _enableNetworkProbes;

    public MainForm(bool enableNetworkProbes = true)
    {
        _enableNetworkProbes = enableNetworkProbes;
        AppPreferences.Load();
        Text = "WiFi Game Hub";
        Width = 1280;
        Height = 820;
        MinimumSize = new Size(960, 680);
        StartPosition = FormStartPosition.CenterScreen;
        BackColor = Canvas;
        Font = new Font("Segoe UI", 10F);
        FormClosing += MainForm_FormClosing;

        _sidebar.Width = 228;
        _sidebar.Dock = DockStyle.Left;
        _sidebar.BackColor = SidebarColor;
        _sidebar.Padding = new Padding(14, 14, 12, 14);

        var brand = new Panel { Dock = DockStyle.Top, Height = 100, Padding = new Padding(8, 8, 0, 0) };
        brand.Controls.Add(new Label
        {
            Text = "◈  WIFI GAME HUB",
            ForeColor = Color.White,
            Font = new Font("Segoe UI", 14F, FontStyle.Bold),
            AutoSize = true,
            Location = new Point(2, 8)
        });
        brand.Controls.Add(new Label
        {
            Text = "PLAY TOGETHER. ANYWHERE.",
            ForeColor = Color.FromArgb(164, 151, 196),
            Font = new Font("Segoe UI", 8F, FontStyle.Bold),
            AutoSize = true,
            Location = new Point(4, 38)
        });

        var navigation = new FlowLayoutPanel
        {
            Dock = DockStyle.Fill,
            FlowDirection = FlowDirection.TopDown,
            WrapContents = false,
            AutoScroll = true,
            BackColor = SidebarColor,
            Padding = Padding.Empty,
            Margin = Padding.Empty
        };
        var navItems = new (string Label, string Page)[]
        {
            ("Dashboard", "Dashboard"),
            ("Games", "Games"),
            ("Multiplayer Rooms", "Multiplayer Rooms"),
            ("Chat", "Chat"),
            ("Network Center", "Wi‑Fi Networks"),
            ("Chess", "Chess"),
            ("Ludo Arena", "Ludo"),
            ("Tic Tac Toe", "Tic Tac Toe"),
            ("Carrom", "Carrom"),
            ("Settings", "Settings"),
            ("About", "About")
        };

        foreach (var (label, pageName) in navItems)
        {
            var button = new Button
            {
                Text = $"{GetNavigationGlyph(label)}    {label}",
                Tag = pageName,
                Width = 192,
                Height = 42,
                TextAlign = ContentAlignment.MiddleLeft,
                Padding = new Padding(12, 0, 0, 0),
                Margin = new Padding(0, 2, 0, 4),
                FlatStyle = FlatStyle.Flat,
                BackColor = SidebarColor,
                ForeColor = Color.FromArgb(173, 174, 197),
                Font = new Font("Segoe UI", 9.5F, FontStyle.Bold),
                Cursor = Cursors.Hand
            };
            button.FlatAppearance.BorderSize = 0;
            button.FlatAppearance.MouseOverBackColor = Color.FromArgb(31, 29, 47);
            button.Click += (_, _) => Navigate(pageName);
            _navigationButtons[pageName] = button;
            navigation.Controls.Add(button);
        }

        var sidebarFooter = new Panel { Dock = DockStyle.Bottom, Height = 52, Padding = new Padding(8, 8, 0, 0) };
        sidebarFooter.Controls.Add(new Label
        {
            Text = ".NET 8  |  WINDOWS",
            ForeColor = Color.FromArgb(103, 122, 150),
            Font = new Font("Segoe UI", 8F, FontStyle.Bold),
            AutoSize = true
        });
        _sidebar.Controls.Add(navigation);
        _sidebar.Controls.Add(sidebarFooter);
        _sidebar.Controls.Add(brand);

        var mainArea = new Panel { Dock = DockStyle.Fill, BackColor = Canvas, Padding = new Padding(22, 0, 22, 18) };
        var header = new Panel { Dock = DockStyle.Top, Height = 68, BackColor = Canvas };
        _titleLabel.Text = "Dashboard";
        _titleLabel.ForeColor = Color.White;
        _titleLabel.Font = new Font("Segoe UI", 17F, FontStyle.Bold);
        _titleLabel.AutoSize = true;
        _titleLabel.Location = new Point(0, 20);
        var headerStatus = new Label
        {
            Text = "LOCAL PLAY  ·  LAN MULTIPLAYER",
            ForeColor = Color.FromArgb(153, 146, 177),
            Font = new Font("Segoe UI", 8F, FontStyle.Bold),
            AutoSize = true,
            Anchor = AnchorStyles.Top | AnchorStyles.Right
        };
        headerStatus.Location = new Point(Width - _sidebar.Width - 220, 28);
        header.Controls.Add(_titleLabel);
        header.Controls.Add(headerStatus);

        _content.Dock = DockStyle.Fill;
        _content.BackColor = Canvas;
        _content.Padding = Padding.Empty;
        mainArea.Controls.Add(_content);
        mainArea.Controls.Add(header);
        Controls.Add(mainArea);
        Controls.Add(_sidebar);

        Navigate("Dashboard");
        FormClosed += (_, _) => _multiplayerSession.Dispose();
    }

    private void MainForm_FormClosing(object? sender, FormClosingEventArgs e)
    {
        if (_multiplayerSession.IsActive
            && _multiplayerSession.CurrentState is { Started: true, IsGameOver: false })
        {
            if (_multiplayerSession.CurrentState.Players.Any(player =>
                player.PlayerId == _multiplayerSession.LocalPlayerId && player.Connected))
            {
                MessageBox.Show(
                    this,
                    "You cannot close the application while a game is running.",
                    Text,
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Information);
                e.Cancel = true;
            }
        }
    }

    private void Navigate(string pageName)
    {
        if (string.IsNullOrWhiteSpace(pageName))
        {
            return;
        }

        var navigationKey = pageName;
        pageName = pageName switch
        {
            "Games" => "Dashboard",
            "Multiplayer Rooms" or "Chat" => "Multiplayer",
            _ => pageName
        };

        if (!_pages.TryGetValue(pageName, out var page))
        {
            page = pageName switch
            {
                "Dashboard" => CreateDashboard(),
                "Wi‑Fi Networks" => new WifiForm(_enableNetworkProbes),
                "Multiplayer" => CreateMultiplayerForm(),
                "Chess" => new GameModeForm("Chess", "Take turns and enjoy a classic two-player strategy match.", () => Navigate("Chess Solo"), () => NavigateToRoom("Chess"), () => Navigate("Dashboard")),
                "Ludo" => new GameModeForm("Ludo", "Play with 2–4 people on this computer. Pass the device for each turn.", () => Navigate("Ludo Solo"), () => NavigateToRoom("Ludo"), () => Navigate("Dashboard")),
                "Tic Tac Toe" => new GameModeForm("Tic-Tac-Toe", "Play a quick two-player match locally, taking turns on this device.", () => Navigate("Tic Tac Toe Solo"), () => NavigateToRoom("Tic Tac Toe"), () => Navigate("Dashboard")),
                "Carrom" => new GameModeForm("Carrom", "Play a two-player Carrom match locally or over your Wi-Fi network.", () => Navigate("Carrom Solo"), () => NavigateToRoom("Carrom"), () => Navigate("Dashboard")),
                "Chess Solo" => new ChessForm(onExit: () => Navigate("Dashboard")),
                "Chess Room" => new ChessForm(_multiplayerSession, () => Navigate("Dashboard")),
                "Ludo Solo" => new LudoForm(onExit: () => Navigate("Dashboard")),
                "Ludo Room" => new LudoForm(_multiplayerSession, () => Navigate("Dashboard")),
                "Tic Tac Toe Solo" => new TicTacToeForm(onExit: () => Navigate("Dashboard")),
                "Tic Tac Toe Room" => new TicTacToeForm(_multiplayerSession, () => Navigate("Dashboard")),
                "Carrom Solo" => new CarromForm(() => Navigate("Dashboard")),
                "Carrom Room" => new CarromForm(() => Navigate("Dashboard"), _multiplayerSession),
                "Settings" => new SettingsForm(),
                "About" => new AboutForm(),
                _ => throw new InvalidOperationException($"No form is registered for the page: {pageName}")
            };
            _pages[pageName] = page;
        }

        _content.SuspendLayout();
        _content.Controls.Clear();
        _titleLabel.Text = navigationKey switch
        {
            "Games" => "Games",
            "Multiplayer Rooms" => "Multiplayer Rooms",
            "Chat" => "Chat",
            "Wi‑Fi Networks" => "Network Center",
            "Multiplayer" => "Game Lobby",
            "Ludo" or "Ludo Solo" or "Ludo Room" => "Ludo Arena",
            "Chess Solo" or "Chess Room" => "Chess",
            "Tic Tac Toe Solo" or "Tic Tac Toe Room" => "Tic Tac Toe",
            "Carrom Solo" or "Carrom Room" or "Carrom" => "Carrom",
            _ => pageName
        };

        page.TopLevel = false;
        page.FormBorderStyle = FormBorderStyle.None;
        page.Dock = DockStyle.Fill;
        if (page is DashboardForm dashboard)
        {
            dashboard.SetGamesFocus(navigationKey == "Games");
        }
        page.Show();
        _content.Controls.Add(page);
        _content.ResumeLayout(true);

        if (navigationKey == "Chat" && page is MultiplayerForm lobby)
        {
            lobby.SelectGame("Chat Only");
        }

        foreach (var (key, button) in _navigationButtons)
        {
            var active = string.Equals(key, navigationKey, StringComparison.Ordinal)
                || (navigationKey.StartsWith("Chess ", StringComparison.Ordinal) && key == "Chess")
                || (navigationKey.StartsWith("Ludo ", StringComparison.Ordinal) && key == "Ludo")
                || (navigationKey.StartsWith("Tic Tac Toe ", StringComparison.Ordinal) && key == "Tic Tac Toe")
                || (navigationKey.StartsWith("Carrom ", StringComparison.Ordinal) && key == "Carrom");
            button.BackColor = active ? Color.FromArgb(43, 33, 65) : SidebarColor;
            button.ForeColor = active ? Color.White : Color.FromArgb(173, 174, 197);
            button.FlatAppearance.BorderColor = active ? Accent : SidebarColor;
            button.FlatAppearance.BorderSize = active ? 1 : 0;
        }
    }

    private DashboardForm CreateDashboard()
    {
        var dashboard = new DashboardForm(Navigate, _multiplayerSession);
        dashboard.SetDiscoveryStatus(_discoveryStatus, _discoveryDetail);
        return dashboard;
    }

    private MultiplayerForm CreateMultiplayerForm()
    {
        var lobby = new MultiplayerForm(_multiplayerSession, game =>
        {
            var pageName = game switch
            {
                "TicTacToe" => "Tic Tac Toe Room",
                "Chess" => "Chess Room",
                "Ludo" => "Ludo Room",
                "Carrom" => "Carrom Room",
                _ => throw new InvalidOperationException($"No game screen is available for room game: {game}")
            };
            Navigate(pageName);
        }, () => Navigate("Dashboard"));
        lobby.DiscoveryStatusChanged += (status, detail) =>
        {
            _discoveryStatus = status;
            _discoveryDetail = detail;
            if (_pages.TryGetValue("Dashboard", out var page) && page is DashboardForm dashboard && !dashboard.IsDisposed)
            {
                dashboard.SetDiscoveryStatus(status, detail);
            }
        };
        return lobby;
    }

    private static string GetNavigationGlyph(string label) => label switch
    {
        "Dashboard" => "⌂",
        "Games" => "◇",
        "Multiplayer Rooms" => "▣",
        "Chat" => "◌",
        "Network Center" => "⌁",
        "Chess" => "♞",
        "Ludo Arena" => "●",
        "Tic Tac Toe" => "⊞",
        "Carrom" => "◉",
        "Settings" => "⚙",
        _ => "ⓘ"
    };

    private void NavigateToRoom(string game)
    {
        var sessionGame = game switch { "Tic Tac Toe" => "TicTacToe", _ => game };
        if (_multiplayerSession.IsActive && _multiplayerSession.Game == sessionGame)
        {
            Navigate($"{game} Room");
            return;
        }

        Navigate("Multiplayer");
        if (_pages.TryGetValue("Multiplayer", out var lobby) && lobby is MultiplayerForm multiplayerForm)
        {
            multiplayerForm.SelectGame(game);
        }
    }
}