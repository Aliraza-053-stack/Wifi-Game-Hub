using System.Numerics;
using WiFiGameHub.Games.Carrom;
using Xunit;

namespace WiFiGameHub.Tests;

public class CarromRulesTests
{
    [Fact]
    public void Players_Are_Assigned_White_And_Black_And_A_Valid_Own_Coin_Keeps_Turn()
    {
        var (board, rules) = PrepareShot(CarromPieceType.White);

        Assert.True(rules.TryProcessShot(board, Shot(1, board, CarromPieceType.White), out var result));

        Assert.True(result!.OwnCoinPocketed);
        Assert.Equal(0, rules.CurrentPlayerIndex);
        Assert.Equal(1, rules.PocketedCoins[0]);
        Assert.Equal(0, rules.PocketedCoins[1]);
        Assert.Equal(0, rules.Scores[0]);
        Assert.Equal(0, rules.Scores[1]);
    }

    [Fact]
    public void Pocketing_An_Opponent_Coin_Does_Not_Count_And_Returns_It_To_Board()
    {
        var (board, rules) = PrepareShot(CarromPieceType.Black);
        var black = board.Pieces.First(piece => piece.Type == CarromPieceType.Black);

        Assert.True(rules.TryProcessShot(board, Shot(1, board, CarromPieceType.Black), out var result));

        Assert.False(result!.OwnCoinPocketed);
        Assert.Equal(1, rules.CurrentPlayerIndex);
        Assert.Equal(0, rules.PocketedCoins[0]);
        Assert.True(black.IsActive);
    }

    [Fact]
    public void Queen_Cannot_Be_Claimed_Before_An_Own_Colour_Coin_Is_Pocketed()
    {
        var (board, rules) = PrepareShot(CarromPieceType.Queen);

        Assert.True(rules.TryProcessShot(board, Shot(1, board, CarromPieceType.Queen), out var result));

        Assert.True(result!.QueenReturned);
        Assert.False(result.QueenClaimed);
        Assert.False(rules.QueenClaimed);
        Assert.Null(rules.QueenPendingCoverByPlayer);
        Assert.True(board.Pieces.Single(piece => piece.Type == CarromPieceType.Queen).IsActive);
    }

    [Fact]
    public void Eligible_Player_Can_Cover_Queen_In_The_Same_Shot()
    {
        var board = new CarromPhysicsEngine();
        var rules = new CarromRulesEngine();
        var firstWhite = board.Pieces.First(piece => piece.Type == CarromPieceType.White);
        Deactivate(board, firstWhite.Id, 0);
        Assert.True(rules.TryProcessShot(board, new CarromShotResult(1,
            [new CarromPocketedPiece(firstWhite.Id, CarromPieceType.White, firstWhite.Position)], false), out _));

        var queen = board.Pieces.Single(piece => piece.Type == CarromPieceType.Queen);
        var secondWhite = board.Pieces.Last(piece => piece.Type == CarromPieceType.White && piece.IsActive);
        Deactivate(board, queen.Id, secondWhite.Id, 1);
        Assert.True(rules.TryProcessShot(board, new CarromShotResult(2,
            [
                new CarromPocketedPiece(queen.Id, CarromPieceType.Queen, queen.Position),
                new CarromPocketedPiece(secondWhite.Id, CarromPieceType.White, secondWhite.Position)
            ], false), out var result));

        Assert.True(result!.QueenClaimed);
        Assert.True(rules.QueenClaimed);
        Assert.Null(rules.QueenPendingCoverByPlayer);
        Assert.Equal(0, rules.CurrentPlayerIndex);
    }

    [Fact]
    public void Queen_Must_Be_Covered_On_The_Next_Shot_Or_Is_Returned()
    {
        var board = new CarromPhysicsEngine();
        var rules = new CarromRulesEngine();
        var white = board.Pieces.First(piece => piece.Type == CarromPieceType.White);
        Deactivate(board, white.Id, 0);
        Assert.True(rules.TryProcessShot(board, new CarromShotResult(1,
            [new CarromPocketedPiece(white.Id, CarromPieceType.White, white.Position)], false), out _));

        var queen = board.Pieces.Single(piece => piece.Type == CarromPieceType.Queen);
        Deactivate(board, queen.Id, 1);
        Assert.True(rules.TryProcessShot(board, new CarromShotResult(2,
            [new CarromPocketedPiece(queen.Id, CarromPieceType.Queen, queen.Position)], false), out var pendingResult));
        Assert.False(pendingResult!.QueenReturned);
        Assert.Equal(0, rules.CurrentPlayerIndex);
        Assert.Equal(0, rules.QueenPendingCoverByPlayer);

        Assert.True(rules.TryProcessShot(board, new CarromShotResult(3, Array.Empty<CarromPocketedPiece>(), false), out var missedCover));
        Assert.True(missedCover!.QueenReturned);
        Assert.False(rules.QueenClaimed);
        Assert.Null(rules.QueenPendingCoverByPlayer);
        Assert.True(board.Pieces.Single(piece => piece.Type == CarromPieceType.Queen).IsActive);
        Assert.Equal(1, rules.CurrentPlayerIndex);
    }

    [Fact]
    public void Striker_Foul_Returns_Pocketed_Coin_Tracks_Penalty_And_Passes_Turn()
    {
        var (board, rules) = PrepareShot(CarromPieceType.White);
        var white = board.Pieces.First(piece => piece.Type == CarromPieceType.White);
        Assert.True(rules.TryProcessShot(board, new CarromShotResult(1,
            [new CarromPocketedPiece(white.Id, CarromPieceType.White, white.Position)], true), out var result));

        Assert.True(result!.IsFoul);
        Assert.Equal("The striker was pocketed.", result.FoulReason);
        Assert.Equal(1, rules.Fouls[0]);
        Assert.Equal(1, rules.CurrentPlayerIndex);
        Assert.True(white.IsActive);
        Assert.Equal(0, rules.PocketedCoins[0]);
    }

    [Fact]
    public void Queen_Pocketed_During_Striker_Foul_Is_Returned()
    {
        var board = new CarromPhysicsEngine();
        var rules = new CarromRulesEngine();
        var queen = board.Pieces.Single(piece => piece.Type == CarromPieceType.Queen);
        Deactivate(board, queen.Id, 0);

        Assert.True(rules.TryProcessShot(board, new CarromShotResult(1,
            [new CarromPocketedPiece(queen.Id, CarromPieceType.Queen, queen.Position)], true), out var result));

        Assert.True(result!.QueenReturned);
        Assert.False(rules.QueenClaimed);
        Assert.True(queen.IsActive);
    }

    [Fact]
    public void Clearing_Own_Coins_Completes_Board_Awards_Remaining_Opponent_Coins_And_Winner()
    {
        var board = new CarromPhysicsEngine();
        var rules = new CarromRulesEngine(new CarromRulesOptions(MaximumBoards: 1));
        var whitePieces = board.Pieces.Where(piece => piece.Type == CarromPieceType.White).ToArray();
        Deactivate(board, whitePieces.Select(piece => piece.Id).ToArray(), 0);
        var resultPieces = whitePieces.Select(piece =>
            new CarromPocketedPiece(piece.Id, CarromPieceType.White, piece.Position)).ToArray();

        Assert.True(rules.TryProcessShot(board, new CarromShotResult(1, resultPieces, false), out var result));

        Assert.True(result!.BoardCompleted);
        Assert.True(result.MatchCompleted);
        Assert.Equal(0, result.MatchWinnerIndex);
        Assert.Equal(9, result.WhiteScore);
        Assert.Equal(0, result.BlackScore);
    }

    [Fact]
    public void Covered_Queen_Bonus_Is_Awarded_Only_To_The_Board_Winner()
    {
        var board = new CarromPhysicsEngine();
        var rules = new CarromRulesEngine(new CarromRulesOptions(MaximumBoards: 1));
        var whitePieces = board.Pieces.Where(piece => piece.Type == CarromPieceType.White).ToArray();
        var shotNumber = 0;
        foreach (var white in whitePieces.Take(8))
        {
            shotNumber++;
            Deactivate(board, white.Id, shotNumber - 1);
            Assert.True(rules.TryProcessShot(board, new CarromShotResult(shotNumber,
                [new CarromPocketedPiece(white.Id, CarromPieceType.White, white.Position)], false), out _));
        }

        var finalWhite = whitePieces[8];
        var queen = board.Pieces.Single(piece => piece.Type == CarromPieceType.Queen);
        shotNumber++;
        Deactivate(board, finalWhite.Id, queen.Id, shotNumber - 1);
        Assert.True(rules.TryProcessShot(board, new CarromShotResult(shotNumber,
            [
                new CarromPocketedPiece(finalWhite.Id, CarromPieceType.White, finalWhite.Position),
                new CarromPocketedPiece(queen.Id, CarromPieceType.Queen, queen.Position)
            ], false), out var result));

        Assert.True(result!.QueenClaimed);
        Assert.True(result.BoardCompleted);
        Assert.True(result.MatchCompleted);
        Assert.Equal(0, result.MatchWinnerIndex);
        Assert.Equal(12, result.WhiteScore);
        Assert.Equal(9, rules.TotalPocketedCoins[0]);
        Assert.Equal(3, rules.QueenBonuses[0]);
    }

    [Fact]
    public void Reprocessing_The_Same_Shot_Does_Not_Duplicate_Pocketing_Or_Scoring()
    {
        var (board, rules) = PrepareShot(CarromPieceType.White);
        var shot = Shot(1, board, CarromPieceType.White);

        Assert.True(rules.TryProcessShot(board, shot, out _));
        Assert.False(rules.TryProcessShot(board, shot, out _));
        Assert.Equal(1, rules.PocketedCoins[0]);
        Assert.Equal(1, rules.LastProcessedShotNumber);
    }

    private static (CarromPhysicsEngine Board, CarromRulesEngine Rules) PrepareShot(CarromPieceType type)
    {
        var board = new CarromPhysicsEngine();
        var piece = board.Pieces.First(piece => piece.Type == type);
        Deactivate(board, piece.Id, 0);
        return (board, new CarromRulesEngine());
    }

    private static CarromShotResult Shot(int number, CarromPhysicsEngine board, CarromPieceType type)
    {
        var piece = board.Pieces.First(piece => piece.Type == type && !piece.IsActive);
        return new CarromShotResult(number, [new CarromPocketedPiece(piece.Id, piece.Type, piece.Position)], false);
    }

    private static void Deactivate(CarromPhysicsEngine board, int id, int shotNumber) =>
        Deactivate(board, [id], shotNumber);

    private static void Deactivate(CarromPhysicsEngine board, int firstId, int secondId, int shotNumber) =>
        Deactivate(board, [firstId, secondId], shotNumber);

    private static void Deactivate(CarromPhysicsEngine board, int[] ids, int shotNumber)
    {
        var snapshots = board.CreateSnapshot()
            .Select(piece => ids.Contains(piece.Id) ? piece with { IsActive = false } : piece)
            .ToArray();
        board.RestoreSnapshot(snapshots, shotNumber);
    }
}
