using System.Net;
using System.Net.Sockets;
using System.Reflection;
using System.Windows.Forms;
using WiFiGameHub.Forms;
using WiFiGameHub.Networking;
using Xunit;

namespace WiFiGameHub.Tests;

public class GameChatPanelTests
{
    [Fact]
    public async Task Chat_Works_Locally_Without_A_Joined_Room()
    {
        using var panel = new GameChatPanel(null);
        var input = GetControl<TextBox>(panel, "_messageInput");
        var send = GetControl<Button>(panel, "_sendButton");

        Assert.True(input.Enabled);
        input.Text = "Local note";
        Assert.True(send.Enabled);

        var sendMethod = typeof(GameChatPanel).GetMethod("SendMessageAsync", BindingFlags.NonPublic | BindingFlags.Instance);
        Assert.NotNull(sendMethod);
        await (Task)sendMethod!.Invoke(panel, null)!;

        Assert.Equal(string.Empty, input.Text);
        var messages = GetField<List<GameChatEntry>>(panel, "_pendingMessages");
        var message = Assert.Single(messages);
        Assert.Equal("You", message.SenderName);
        Assert.Equal("Local note", message.Text);
        Assert.Equal("local", message.RoomId);
    }

    [Fact]
    public async Task Host_Can_Send_A_Chat_Message_From_The_Panel()
    {
        using var session = new MultiplayerSession();
        session.StartHost("Chess", GetAvailablePort(), "Chess Host");
        using var panel = new GameChatPanel(session);
        var received = new TaskCompletionSource<GameChatEntry>(TaskCreationOptions.RunContinuationsAsynchronously);
        session.ChatReceived += entry => received.TrySetResult(entry);
        var input = GetControl<TextBox>(panel, "_messageInput");
        var send = GetControl<Button>(panel, "_sendButton");
        input.Text = "Hello from chat";

        Assert.True(input.Enabled);
        Assert.True(send.Enabled);
        var sendMethod = typeof(GameChatPanel).GetMethod("SendMessageAsync", BindingFlags.NonPublic | BindingFlags.Instance);
        Assert.NotNull(sendMethod);
        var task = (Task)sendMethod!.Invoke(panel, null)!;
        await task;
        var message = await received.Task.WaitAsync(TimeSpan.FromSeconds(2));

        Assert.Equal(string.Empty, input.Text);
        Assert.Equal("Chess Host", message.SenderName);
        Assert.Equal("Hello from chat", message.Text);
        Assert.Single(GetField<List<GameChatEntry>>(panel, "_pendingMessages"));
    }

    private static T GetControl<T>(GameChatPanel panel, string name) where T : Control =>
        (T)GetField<object>(panel, name);

    private static T GetField<T>(GameChatPanel panel, string name)
    {
        var field = typeof(GameChatPanel).GetField(name, BindingFlags.NonPublic | BindingFlags.Instance);
        Assert.NotNull(field);
        return (T)field!.GetValue(panel)!;
    }

    private static int GetAvailablePort()
    {
        using var listener = new TcpListener(IPAddress.Loopback, 0);
        listener.Start();
        return ((IPEndPoint)listener.LocalEndpoint).Port;
    }
}
