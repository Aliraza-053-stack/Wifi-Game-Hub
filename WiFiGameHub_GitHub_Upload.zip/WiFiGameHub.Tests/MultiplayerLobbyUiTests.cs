using System.Net;
using System.Net.Sockets;
using System.Reflection;
using System.Windows.Forms;
using WiFiGameHub.Forms;
using WiFiGameHub.Networking;
using Xunit;

namespace WiFiGameHub.Tests;

public class MultiplayerLobbyUiTests
{
    [Fact]
    public async Task Host_Can_Create_And_Close_A_Room_Through_The_Lobby()
    {
        using var session = new MultiplayerSession();
        using var lobby = new MultiplayerForm(session);
        GetField<TextBox>(lobby, "_playerName").Text = "Host Player";
        GetField<ComboBox>(lobby, "_gameChoice").SelectedItem = "Chess";
        GetField<TextBox>(lobby, "_portText").Text = GetAvailablePort().ToString();

        await InvokeTask(lobby, "ToggleHostAsync");

        Assert.True(session.IsHost);
        Assert.Equal(12, session.RoomId.Length);
        Assert.Equal($"Room ID  {session.RoomId}", GetField<Label>(lobby, "_roomIdLabel").Text);
        Assert.Equal("Close Room", GetField<Button>(lobby, "_hostButton").Text);

        Invoke(lobby, "LeaveRoom");
        Assert.False(session.IsActive);
        Assert.Empty(GetField<ListBox>(lobby, "_playerList").Items);
    }

    [Fact]
    public async Task Invalid_Room_ID_Is_Reported_Without_Connecting()
    {
        using var session = new MultiplayerSession();
        using var lobby = new MultiplayerForm(session);
        GetField<TextBox>(lobby, "_hostAddressText").Text = "127.0.0.1";
        GetField<TextBox>(lobby, "_roomIdText").Text = string.Empty;

        await InvokeTask(lobby, "JoinByIdAsync");

        Assert.False(session.IsActive);
        Assert.Contains("valid room ID", GetField<Label>(lobby, "_connectionStatus").Text);
    }

    [Fact]
    public void Discovered_Room_Is_Shown_With_Actual_Host_And_Game_Data()
    {
        using var lobby = new MultiplayerForm();
        var announcement = new LanRoomAnnouncement
        {
            RoomId = "room12345678",
            RoomName = "Chess Room",
            Game = "Chess",
            HostName = "Host Player",
            HostIp = "127.0.0.1",
            Port = 45456,
            CurrentPlayers = 1,
            MaxPlayers = 2,
            Status = "Waiting"
        };
        GetField<LanRoomDirectory>(lobby, "_discoveredRooms").Upsert(announcement);
        Invoke(lobby, "RefreshRoomList");

        var rooms = GetField<ListView>(lobby, "_roomList");
        var room = Assert.Single(rooms.Items.Cast<ListViewItem>());
        Assert.Equal("Host Player", room.Text);
        Assert.Equal("Chess", room.SubItems[1].Text);
        Assert.Equal("1", room.SubItems[2].Text);
        Assert.Equal("Waiting", room.SubItems[3].Text);
    }

    [Fact]
    public void Host_Cannot_Start_Until_A_Second_Connected_Player_Joins()
    {
        using var session = new MultiplayerSession();
        session.StartHost("Chess", GetAvailablePort(), "Host Player");
        using var lobby = new MultiplayerForm(session, _ => { });
        var start = GetField<Button>(lobby, "_startGameButton");

        Assert.False(start.Enabled);
        Assert.Equal("WAITING FOR PLAYERS", GetField<Label>(lobby, "_lobbyStateLabel").Text);

        Invoke(lobby, "OpenRoomGame");

        Assert.Contains("Waiting for another connected player", GetField<Label>(lobby, "_connectionStatus").Text);
    }

    [Fact]
    public async Task Host_Can_Open_Game_When_Existing_Room_State_Has_Two_Connected_Players()
    {
        using var host = new MultiplayerSession();
        using var guest = new MultiplayerSession();
        host.StartHost("Chess", GetAvailablePort(), "Host Player");
        using var lobby = new MultiplayerForm(host, game => Assert.Equal("Chess", game));

        await guest.JoinAsync("127.0.0.1", host.Port, host.RoomId, "Chess", "Guest Player");
        await WaitUntilAsync(() => host.CurrentState is { Started: true, Players.Count: 2 });
        Invoke(lobby, "RefreshRoomSessionState", host.CurrentState!);
        Invoke(lobby, "RefreshLobbyControls");

        var start = GetField<Button>(lobby, "_startGameButton");
        Assert.True(start.Enabled);
        Assert.Contains(GetField<ListBox>(lobby, "_playerList").Items.Cast<string>(), line => line.Contains("Host Player"));
        Assert.Contains(GetField<ListBox>(lobby, "_playerList").Items.Cast<string>(), line => line.Contains("Guest Player"));
        Click(start);
    }

    [Fact]
    public async Task Guest_Sees_Open_Game_Only_After_The_Room_Is_Started_And_Can_Leave()
    {
        using var host = new MultiplayerSession();
        using var guest = new MultiplayerSession();
        host.StartHost("TicTacToe", GetAvailablePort(), "Host Player");
        await guest.JoinAsync("127.0.0.1", host.Port, host.RoomId, "TicTacToe", "Guest Player");
        await WaitUntilAsync(() => guest.CurrentState is { Started: true, Players.Count: 2 });

        using var lobby = new MultiplayerForm(guest, game => Assert.Equal("TicTacToe", game));
        var start = GetField<Button>(lobby, "_startGameButton");
        Assert.Equal("Open Game", start.Text);
        Assert.True(start.Enabled);
        Click(start);

        Invoke(lobby, "LeaveRoom");
        Assert.False(guest.IsActive);
        Assert.False(GetField<Button>(lobby, "_leaveRoomButton").Enabled);
    }

    [Fact]
    public void Lobby_Includes_Chat_Tab_For_Chat_Only_Rooms()
    {
        using var session = new MultiplayerSession();
        session.StartHost("Chat", GetAvailablePort(), "Host Player");
        using var lobby = new MultiplayerForm(session);

        Assert.Single(FindControls<GameChatPanel>(lobby));
        Assert.False(GetField<Button>(lobby, "_startGameButton").Visible);
        Assert.True(GetField<Button>(lobby, "_leaveRoomButton").Enabled);
    }

    [Fact]
    public void Back_Button_Invokes_The_Return_Action()
    {
        var wentBack = false;
        using var lobby = new MultiplayerForm(onBack: () => wentBack = true);
        var back = FindControls<Button>(lobby).Single(button => button.Text.Contains("Back", StringComparison.Ordinal));

        Click(back);

        Assert.True(wentBack);
    }

    private static void Click(Button button) =>
        typeof(Button).GetMethod("OnClick", BindingFlags.NonPublic | BindingFlags.Instance)!
            .Invoke(button, new object[] { EventArgs.Empty });

    private static void Invoke(object instance, string methodName, params object[]? arguments) =>
        instance.GetType().GetMethod(methodName, BindingFlags.NonPublic | BindingFlags.Instance)!
            .Invoke(instance, arguments);

    private static Task InvokeTask(object instance, string methodName, params object[]? arguments) =>
        (Task)instance.GetType().GetMethod(methodName, BindingFlags.NonPublic | BindingFlags.Instance)!
            .Invoke(instance, arguments)!;

    private static T GetField<T>(object instance, string name)
    {
        var field = instance.GetType().GetField(name, BindingFlags.NonPublic | BindingFlags.Instance);
        Assert.NotNull(field);
        return (T)field!.GetValue(instance)!;
    }

    private static IEnumerable<T> FindControls<T>(Control parent) where T : Control
    {
        foreach (Control child in parent.Controls)
        {
            if (child is T match)
            {
                yield return match;
            }
            foreach (var nested in FindControls<T>(child))
            {
                yield return nested;
            }
        }
    }

    private static async Task WaitUntilAsync(Func<bool> condition)
    {
        var timeout = DateTime.UtcNow + TimeSpan.FromSeconds(5);
        while (!condition())
        {
            if (DateTime.UtcNow >= timeout)
            {
                throw new TimeoutException("Timed out while waiting for the LAN session state.");
            }
            await Task.Delay(20);
        }
    }

    private static int GetAvailablePort()
    {
        using var listener = new TcpListener(IPAddress.Loopback, 0);
        listener.Start();
        return ((IPEndPoint)listener.LocalEndpoint).Port;
    }
}
