using WiFiGameHub.Games.Chess;
using Xunit;

namespace WiFiGameHub.Tests;

public class ChessGameTests
{
    [Fact]
    public void Standard_Position_Has_Twenty_Legal_Opening_Moves()
    {
        var game = new ChessGame();

        Assert.Equal(20, Enumerable.Range(0, ChessGame.BoardSize)
            .Sum(row => Enumerable.Range(0, ChessGame.BoardSize)
                .Sum(column => game.GetLegalMoves(row, column).Count)));
    }

    [Fact]
    public void Standard_Position_Has_Four_Hundred_Legal_Two_Ply_Lines()
    {
        Assert.Equal(400, CountLegalLines(new ChessGame(), 2));
    }

    [Fact]
    public void Move_Cannot_Expose_The_King_To_Check()
    {
        var game = CreateGame("k3r3/8/8/8/8/8/4R3/4K3 w - - 0 1");

        Assert.False(game.TryMove(6, 4, 6, 5));
        Assert.True(game.GetLegalMoves(6, 4).All(move => move.Column == 4));
    }

    [Fact]
    public void Checkmate_Is_Detected_After_A_Legal_Mating_Move()
    {
        var game = new ChessGame();

        Assert.True(game.TryMove(6, 4, 4, 4));
        Assert.True(game.TryMove(1, 4, 3, 4));
        Assert.True(game.TryMove(7, 3, 3, 7));
        Assert.True(game.TryMove(0, 1, 2, 2));
        Assert.True(game.TryMove(7, 5, 4, 2));
        Assert.True(game.TryMove(0, 6, 2, 5));
        Assert.True(game.TryMove(3, 7, 1, 5));

        Assert.True(game.IsGameOver);
        Assert.False(game.IsDraw);
        Assert.Equal(ChessSide.White, game.Winner);
        Assert.EndsWith("#", game.MoveHistory[^1]);
    }

    [Fact]
    public void Castling_Moves_The_Rook_And_Revokes_Both_Rights()
    {
        var game = CreateGame("r3k2r/8/8/8/8/8/8/R3K2R w KQkq - 0 1");

        Assert.True(game.TryMove(7, 4, 7, 6));

        var board = game.Board;
        Assert.Equal('K', board[7, 6]);
        Assert.Equal('R', board[7, 5]);
        Assert.Equal("kq", game.ToFen().Split(' ')[2]);
    }

    [Fact]
    public void En_Passant_Captures_The_Pawn_On_The_Passing_Square()
    {
        var game = CreateGame("4k3/8/8/3pP3/8/8/8/4K3 w - d6 0 1");

        Assert.True(game.TryMove(3, 4, 2, 3));

        var board = game.Board;
        Assert.Equal('P', board[2, 3]);
        Assert.Equal('\0', board[3, 3]);
    }

    [Fact]
    public void Pawn_Promotion_Uses_The_Selected_Piece()
    {
        var game = CreateGame("4k3/P7/8/8/8/8/8/4K3 w - - 0 1");

        Assert.True(game.TryMove(1, 0, 0, 0, 'N'));

        Assert.Equal('N', game.Board[0, 0]);
        Assert.Contains("=N", game.MoveHistory[^1]);
    }

    [Fact]
    public void Stalemate_Is_Reported_As_A_Draw()
    {
        var game = CreateGame("7k/5Q2/6K1/8/8/8/8/8 b - - 0 1");

        Assert.True(game.IsGameOver);
        Assert.True(game.IsDraw);
        Assert.True(game.IsStalemate);
        Assert.Null(game.Winner);
    }

    [Fact]
    public void Insufficient_Material_Draw_Is_Not_Reported_As_Stalemate()
    {
        var game = CreateGame("4k3/8/8/8/8/8/8/4K3 w - - 0 1");

        Assert.True(game.IsGameOver);
        Assert.True(game.IsDraw);
        Assert.False(game.IsStalemate);
    }

    [Fact]
    public void Fen_Round_Trip_Preserves_Position_And_Special_Move_State()
    {
        var game = new ChessGame();
        Assert.True(game.TryMove(6, 4, 4, 4));
        var restored = CreateGame(game.ToFen(), game.MoveHistory);

        Assert.Equal(game.ToFen(), restored.ToFen());
        Assert.Equal(game.MoveHistory, restored.MoveHistory);
    }

    private static ChessGame CreateGame(string fen, IReadOnlyList<string>? history = null)
    {
        var game = new ChessGame();
        game.LoadFen(fen, history);
        return game;
    }

    private static int CountLegalLines(ChessGame game, int depth)
    {
        if (depth == 0) return 1;
        var board = game.Board;
        var count = 0;
        for (var row = 0; row < ChessGame.BoardSize; row++)
        {
            for (var column = 0; column < ChessGame.BoardSize; column++)
            {
                if (board[row, column] == '\0') continue;
                foreach (var target in game.GetLegalMoves(row, column))
                {
                    var next = CreateGame(game.ToFen(), game.MoveHistory);
                    if (next.TryMove(row, column, target.Row, target.Column))
                    {
                        count += CountLegalLines(next, depth - 1);
                    }
                }
            }
        }
        return count;
    }
}
