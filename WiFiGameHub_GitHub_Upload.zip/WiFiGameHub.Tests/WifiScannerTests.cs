using WiFiGameHub.Services;
using WiFiGameHub.Forms;
using System.Reflection;
using System.Windows.Forms;
using Xunit;

namespace WiFiGameHub.Tests;

public class WifiScannerTests
{
    [Fact]
    public void Parser_Keeps_Strongest_Signal_Per_Network()
    {
        const string output = """
            SSID 1 : CampusNet
                Authentication : WPA2-Personal
                BSSID 1 : 00:11:22:33:44:55
                     Signal : 38%
                BSSID 2 : 00:11:22:33:44:66
                     Signal : 81%
            SSID 2 : Guest
                Authentication : Open
                BSSID 1 : 00:11:22:33:44:77
                     Signal : 62%
            """;

        var networks = WifiScanner.ParseNetworksOutput(output);

        Assert.Equal(2, networks.Count);
        Assert.Equal("CampusNet", networks[0].Ssid);
        Assert.Equal(81, networks[0].SignalStrength);
        Assert.Equal("WPA2-Personal", networks[0].Authentication);
        Assert.Equal("Guest", networks[1].Ssid);
        Assert.Equal(62, networks[1].SignalStrength);
    }

    [Fact]
    public void Parser_Returns_No_Networks_For_Empty_Output()
    {
        Assert.Empty(WifiScanner.ParseNetworksOutput(string.Empty));
    }

    [Fact]
    public void Scan_Result_Identifies_The_Connected_Network()
    {
        const string networks = """
            SSID 1 : CampusNet
                Authentication : WPA2-Personal
                     Signal : 81%
            SSID 2 : Guest
                Authentication : Open
                     Signal : 42%
            """;
        const string interfaces = """
            Name : Wi-Fi
            State : connected
            SSID : CampusNet
            BSSID : 00:11:22:33:44:55
            """;

        var result = WifiScanner.CreateScanResult(networks, interfaces);

        Assert.True(result.WifiEnabled);
        Assert.Equal("CampusNet", result.ConnectedNetwork);
        Assert.True(result.Networks.Single(network => network.Ssid == "CampusNet").IsConnected);
        Assert.False(result.Networks.Single(network => network.Ssid == "Guest").IsConnected);
    }

    [Fact]
    public void Wifi_Form_Renders_All_Scan_Results_And_Connected_Status()
    {
        using var form = new WifiForm(scanOnLoad: false);
        var networks = new[]
        {
            new WifiNetwork { Ssid = "CampusNet", SignalStrength = 81, Authentication = "WPA2-Personal", IsConnected = true },
            new WifiNetwork { Ssid = "Guest", SignalStrength = 42, Authentication = "Open" }
        };
        ApplyScanResult(form, new WifiScanResult(true, "CampusNet", networks, null));

        var list = GetField<ListView>(form, "_networkList");
        Assert.Equal(2, list.Items.Count);
        Assert.Equal("CampusNet", list.Items[0].Text);
        Assert.Equal("81%", list.Items[0].SubItems[1].Text);
        Assert.Equal("Connected", list.Items[0].SubItems[3].Text);
        Assert.Equal("Available", list.Items[1].SubItems[3].Text);
    }

    [Fact]
    public void Wifi_Form_Shows_Empty_State_And_Scan_Error()
    {
        using var form = new WifiForm(scanOnLoad: false);
        ApplyScanResult(form, new WifiScanResult(null, string.Empty, Array.Empty<WifiNetwork>(), "Access is denied"));

        Assert.Equal("Scan failed: Access is denied", GetField<Label>(form, "_statusLabel").Text);
        Assert.Contains("Could not scan", GetField<Label>(form, "_emptyState").Text);
        Assert.Empty(GetField<ListView>(form, "_networkList").Items);
    }

    [Fact]
    public void Wifi_Form_Shows_Empty_State_When_No_Networks_Are_Found()
    {
        using var form = new WifiForm(scanOnLoad: false);
        ApplyScanResult(form, new WifiScanResult(true, string.Empty, Array.Empty<WifiNetwork>(), null));

        Assert.Equal("No networks found", GetField<Label>(form, "_statusLabel").Text);
        Assert.Contains("No nearby networks", GetField<Label>(form, "_emptyState").Text);
    }

    private static void ApplyScanResult(WifiForm form, WifiScanResult result) =>
        typeof(WifiForm).GetMethod("ApplyScanResult", BindingFlags.NonPublic | BindingFlags.Instance)!
            .Invoke(form, new object[] { result });

    private static T GetField<T>(object instance, string name) =>
        (T)instance.GetType().GetField(name, BindingFlags.NonPublic | BindingFlags.Instance)!.GetValue(instance)!;
}