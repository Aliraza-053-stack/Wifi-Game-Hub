using System.Drawing;
using System.Reflection;
using System.Numerics;
using System.Windows.Forms;
using WiFiGameHub.Games.Carrom;
using WiFiGameHub.Forms;
using Xunit;

namespace WiFiGameHub.Tests;

public class CarromFormTests
{
    [Fact]
    public void Carrom_Screen_Shows_Local_Match_Controls_And_Unscored_Players()
    {
        using var form = new CarromForm();
        var controls = FindControls<Control>(form).ToArray();

        Assert.Contains(controls.OfType<Label>(), label => label.Text == "CARROM");
        Assert.Contains(controls.OfType<Label>(), label => label.Text.Contains("PLAYER 1 · READY TO SHOOT", StringComparison.Ordinal));
        Assert.Contains(controls.OfType<Label>(), label => label.Text.Contains("Queen: available", StringComparison.OrdinalIgnoreCase));
        Assert.Equal(2, controls.OfType<Label>().Count(label => label.Text == "Left 9 · In 0 · Pts 0 · F 0"));
        Assert.Equal(0, GetField<TrackBar>(form, "_power").Minimum);
        Assert.Equal(100, GetField<TrackBar>(form, "_power").Maximum);
        Assert.Contains(controls.OfType<Button>(), button => button.Text == "Reset Board");
        Assert.Contains(controls.OfType<Button>(), button => button.Text == "Exit Game");
        Assert.Null(GetField<WiFiGameHub.Networking.MultiplayerSession?>(form, "_session"));
    }

    [Fact]
    public void Carrom_Board_Scales_To_Square_And_Shows_Nineteen_Carrom_Pieces()
    {
        using var form = new CarromForm();
        var board = GetField<Control>(form, "_board");
        var boardType = board.GetType();
        board.Dock = DockStyle.None;
        board.Size = new Size(420, 330);

        var bounds = (RectangleF)boardType.GetProperty("BoardBounds", BindingFlags.NonPublic | BindingFlags.Instance)!.GetValue(board)!;
        var coinCount = (int)boardType.GetProperty("CoinCount", BindingFlags.NonPublic | BindingFlags.Instance)!.GetValue(board)!;
        Assert.Equal(bounds.Width, bounds.Height);
        Assert.True(bounds.Width <= 318);
        Assert.True(bounds.Left >= 0 && bounds.Top >= 0);
        Assert.Equal(19, coinCount);

        board.Size = new Size(280, 440);
        var tallBounds = (RectangleF)boardType.GetProperty("BoardBounds", BindingFlags.NonPublic | BindingFlags.Instance)!.GetValue(board)!;
        Assert.Equal(tallBounds.Width, tallBounds.Height);
        Assert.True(tallBounds.Width <= 268);
        Assert.True(tallBounds.Top >= 0);
    }

    [Fact]
    public void Carrom_Board_Renders_Its_Custom_Live_Board()
    {
        using var form = new CarromForm();
        var board = GetField<Control>(form, "_board");
        board.Dock = DockStyle.None;
        board.Size = new Size(420, 420);
        using var bitmap = new Bitmap(board.Size.Width, board.Size.Height);

        board.DrawToBitmap(bitmap, new Rectangle(Point.Empty, board.Size));

        var renderedPixels = 0;
        for (var y = 0; y < bitmap.Height; y += 2)
        for (var x = 0; x < bitmap.Width; x += 2)
        {
            if (bitmap.GetPixel(x, y).ToArgb() != board.BackColor.ToArgb())
            {
                renderedPixels++;
            }
        }
        Assert.True(renderedPixels > 10_000);
    }

    [Fact]
    public void Carrom_Board_Allows_Striker_Positioning_And_Fires_A_Real_Shot_On_Release()
    {
        using var form = new CarromForm();
        var board = GetField<Control>(form, "_board");
        var boardType = board.GetType();
        board.Dock = DockStyle.None;
        board.Size = new Size(400, 400);
        var bounds = (RectangleF)boardType.GetProperty("BoardBounds", BindingFlags.NonPublic | BindingFlags.Instance)!.GetValue(board)!;

        InvokeMouse(board, "OnMouseDown", ScreenPoint(bounds, 330, 812));
        InvokeMouse(board, "OnMouseMove", ScreenPoint(bounds, 350, 812));
        InvokeMouse(board, "OnMouseUp", ScreenPoint(bounds, 350, 812));
        Assert.InRange(Math.Abs(350F - (float)boardType.GetProperty("StrikerPosition", BindingFlags.NonPublic | BindingFlags.Instance)!.GetValue(board)!), 0F, 1F);

        InvokeMouse(board, "OnMouseDown", ScreenPoint(bounds, 350, 812));
        InvokeMouse(board, "OnMouseMove", ScreenPoint(bounds, 500, 450));
        Assert.True((bool)boardType.GetProperty("HasAimPreview", BindingFlags.NonPublic | BindingFlags.Instance)!.GetValue(board)!);
        InvokeMouse(board, "OnMouseUp", ScreenPoint(bounds, 500, 450));
        Assert.True((bool)boardType.GetProperty("IsShotInProgress", BindingFlags.NonPublic | BindingFlags.Instance)!.GetValue(board)!);

        GetField<TrackBar>(form, "_power").Value = 77;
        typeof(Button).GetMethod("OnClick", BindingFlags.NonPublic | BindingFlags.Instance)!
            .Invoke(GetField<Button>(form, "_resetButton"), new object[] { EventArgs.Empty });
        Assert.Equal(500F, (float)boardType.GetProperty("StrikerPosition", BindingFlags.NonPublic | BindingFlags.Instance)!.GetValue(board)!);
        Assert.False((bool)boardType.GetProperty("HasAimPreview", BindingFlags.NonPublic | BindingFlags.Instance)!.GetValue(board)!);
        Assert.Equal(50, GetField<TrackBar>(form, "_power").Value);
    }

    private static Point ScreenPoint(RectangleF bounds, float x, float y) =>
        new((int)MathF.Round(bounds.X + bounds.Width * x / 1000F),
            (int)MathF.Round(bounds.Y + bounds.Height * y / 1000F));

    private static void InvokeMouse(Control control, string methodName, Point point)
    {
        var method = control.GetType().GetMethod(methodName, BindingFlags.NonPublic | BindingFlags.Instance)!;
        method.Invoke(control, new object[] { new MouseEventArgs(MouseButtons.Left, 1, point.X, point.Y, 0) });
    }

    public class CarromPhysicsEngineTests
    {
        [Fact]
        public void Default_Board_Contains_Expected_Pieces_And_Striker_Can_Be_Placed_On_Baseline()
        {
            var engine = new CarromPhysicsEngine();

            Assert.Equal(1, engine.Pieces.Count(piece => piece.Type == CarromPieceType.Striker));
            Assert.Equal(9, engine.Pieces.Count(piece => piece.Type == CarromPieceType.Black));
            Assert.Equal(9, engine.Pieces.Count(piece => piece.Type == CarromPieceType.White));
            Assert.Equal(1, engine.Pieces.Count(piece => piece.Type == CarromPieceType.Queen));
            Assert.True(engine.TryPlaceStriker(1_000F));
            Assert.Equal(CarromPhysicsEngine.MaximumStrikerX, engine.Striker.Position.X);
        }

        [Fact]
        public void Striker_Placement_Rejects_A_Position_Occupied_By_A_Coin()
        {
            var engine = CreateEngine(
                Piece(CarromPieceType.Striker, 500, 812, 36, 1.65F),
                Piece(CarromPieceType.Black, 500, 760, 21, 1));

            Assert.False(engine.TryPlaceStriker(500));
            Assert.Equal(500, engine.Striker.Position.X);
        }

        [Fact]
        public void Shooting_Clamps_Power_And_Uses_Requested_Direction()
        {
            var engine = new CarromPhysicsEngine();

            Assert.True(engine.Shoot(Vector2.UnitX, 1_000F));
            Assert.Equal(CarromPhysicsEngine.MaximumShotSpeed, engine.Striker.Velocity.X);
            Assert.Equal(0F, engine.Striker.Velocity.Y);
            Assert.Equal(1F, CarromPhysicsEngine.GetShotPower(1_000F, 100F));
            Assert.Equal(0F, CarromPhysicsEngine.GetShotPower(0F, 100F));
        }

        [Fact]
        public void Friction_Slows_And_Eventually_Stops_Moving_Pieces()
        {
            var engine = CreateEngine(Piece(CarromPieceType.Striker, 500, 500, 20, 1));
            Assert.True(engine.Shoot(Vector2.UnitX, 30F));

            var initialSpeed = engine.Striker.Velocity.Length();
            var result = AdvanceUntilSettled(engine);

            Assert.NotNull(result);
            Assert.False(engine.IsMoving);
            Assert.Equal(Vector2.Zero, engine.Striker.Velocity);
            Assert.True(engine.Striker.Position.X > 500F);
            Assert.True(initialSpeed <= CarromPhysicsEngine.MaximumShotSpeed);
        }

        [Fact]
        public void Striker_Collision_Transfers_Momentum_To_Coin()
        {
            var engine = CreateEngine(
                Piece(CarromPieceType.Striker, 300, 500, 20, 1.65F),
                Piece(CarromPieceType.White, 360, 500, 20, 1));
            var coin = engine.Pieces.Single(piece => piece.Type == CarromPieceType.White);

            Assert.True(engine.Shoot(Vector2.UnitX, 55F));
            var result = AdvanceUntilSettled(engine);

            Assert.NotNull(result);
            Assert.True(coin.Position.X > 360F);
        }

        [Fact]
        public void Coin_Collision_Transfers_Momentum_Between_Coins()
        {
            var engine = CreateEngine(
                Piece(CarromPieceType.Striker, 250, 500, 18, 1.65F),
                Piece(CarromPieceType.White, 310, 500, 18, 1),
                Piece(CarromPieceType.Black, 360, 500, 18, 1));
            var secondCoin = engine.Pieces.Single(piece => piece.Type == CarromPieceType.Black);

            Assert.True(engine.Shoot(Vector2.UnitX, 55F));
            var result = AdvanceUntilSettled(engine);

            Assert.NotNull(result);
            Assert.True(secondCoin.Position.X > 360F);
        }

        [Fact]
        public void Board_Boundary_Reflects_A_Piece_Back_Into_Play()
        {
            var engine = CreateEngine(Piece(CarromPieceType.Striker, 830, 500, 20, 1));

            Assert.True(engine.Shoot(Vector2.UnitX, 100F));
            engine.Advance(TimeSpan.FromMilliseconds(80));

            Assert.True(engine.Striker.Position.X <= CarromPhysicsEngine.BoardMaximum - engine.Striker.Radius);
            Assert.True(engine.Striker.Velocity.X < 0F);
        }

        [Fact]
        public void Coin_Entering_Corner_Pocket_Is_Removed_And_Recorded()
        {
            var engine = CreateEngine(
                Piece(CarromPieceType.Striker, 260, 260, 18, 1.65F),
                Piece(CarromPieceType.Black, 195, 195, 18, 1));
            var black = engine.Pieces.Single(piece => piece.Type == CarromPieceType.Black);

            Assert.True(engine.Shoot(new Vector2(-1F, -1F), 65F));
            var result = AdvanceUntilSettled(engine);

            Assert.NotNull(result);
            Assert.False(black.IsActive);
            Assert.Contains(result!.PocketedPieces, piece => piece.Type == CarromPieceType.Black);
        }

        [Fact]
        public void Striker_Pocket_Is_Reported_As_Foul_And_Striker_Returns_To_Baseline()
        {
            var engine = CreateEngine(Piece(CarromPieceType.Striker, 180, 180, 18, 1));

            Assert.True(engine.Shoot(new Vector2(-1F, -1F), 35F));
            var result = AdvanceUntilSettled(engine);

            Assert.NotNull(result);
            Assert.True(result!.StrikerFoul);
            Assert.True(engine.Striker.IsActive);
            Assert.Equal(CarromPhysicsEngine.StrikerBaselineY, engine.Striker.Position.Y);
            Assert.DoesNotContain(result.PocketedPieces, piece => piece.Type == CarromPieceType.Striker);
        }

        [Fact]
        public void Physics_Uses_Elapsed_Time_And_Is_Independent_Of_Render_Tick_Splitting()
        {
            var oneStep = CreateEngine(Piece(CarromPieceType.Striker, 500, 500, 20, 1));
            var splitSteps = CreateEngine(Piece(CarromPieceType.Striker, 500, 500, 20, 1));
            Assert.True(oneStep.Shoot(Vector2.UnitX, 28F));
            Assert.True(splitSteps.Shoot(Vector2.UnitX, 28F));

            oneStep.Advance(TimeSpan.FromSeconds(1));
            for (var index = 0; index < 120; index++)
            {
                splitSteps.Advance(TimeSpan.FromSeconds(CarromPhysicsEngine.FixedStepSeconds));
            }

            Assert.InRange(Vector2.Distance(oneStep.Striker.Position, splitSteps.Striker.Position), 0F, 0.02F);
            Assert.InRange(Vector2.Distance(oneStep.Striker.Velocity, splitSteps.Striker.Velocity), 0F, 0.02F);
        }

        [Fact]
        public void Completed_Shot_Changes_Turn_And_Tracks_Pocket_History()
        {
            var state = new CarromGameState();
            state.BeginShot();
            state.CompleteShot(new CarromShotResult(1,
                [new CarromPocketedPiece(2, CarromPieceType.White, new Vector2(107, 107))], false));

            Assert.Equal(1, state.CurrentPlayerIndex);
            Assert.Equal(1, state.ShotsTaken);
            Assert.False(state.IsShotInProgress);
            Assert.Contains(CarromPieceType.White, state.PocketedHistory);
        }

        private static CarromPhysicsEngine CreateEngine(params CarromPieceDefinition[] pieces) => new(pieces);

        private static CarromPieceDefinition Piece(CarromPieceType type, float x, float y, float radius, float mass) =>
            new((int)type, type, new Vector2(x, y), radius, mass);

        private static CarromShotResult? AdvanceUntilSettled(CarromPhysicsEngine engine)
        {
            CarromShotResult? result = null;
            for (var frame = 0; frame < 1_200 && result is null; frame++)
            {
                result = engine.Advance(TimeSpan.FromSeconds(1D / 60D));
            }
            return result;
        }
    }

    private static T GetField<T>(object instance, string name) =>
        (T)instance.GetType().GetField(name, BindingFlags.NonPublic | BindingFlags.Instance)!.GetValue(instance)!;

    private static IEnumerable<T> FindControls<T>(Control parent) where T : Control
    {
        foreach (Control child in parent.Controls)
        {
            if (child is T match)
            {
                yield return match;
            }

            foreach (var nested in FindControls<T>(child))
            {
                yield return nested;
            }
        }
    }
}
