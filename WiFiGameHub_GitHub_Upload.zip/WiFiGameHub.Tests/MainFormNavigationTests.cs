using System.Reflection;
using System.Windows.Forms;
using WiFiGameHub.Forms;
using WiFiGameHub.Networking;
using Xunit;

namespace WiFiGameHub.Tests;

public class MainFormNavigationTests
{
    [Theory]
    [InlineData("Dashboard")]
    [InlineData("Games")]
    [InlineData("Wi‑Fi Networks")]
    [InlineData("Multiplayer Rooms")]
    [InlineData("Chat")]
    [InlineData("Chess")]
    [InlineData("Ludo")]
    [InlineData("Tic Tac Toe")]
    [InlineData("Carrom")]
    [InlineData("Settings")]
    [InlineData("About")]
    public void Navigation_Opens_Expected_Page(string pageName)
    {
        var form = new MainForm(enableNetworkProbes: false);
        var sidebarField = typeof(MainForm).GetField("_sidebar", BindingFlags.NonPublic | BindingFlags.Instance);
        var contentField = typeof(MainForm).GetField("_content", BindingFlags.NonPublic | BindingFlags.Instance);
        var titleField = typeof(MainForm).GetField("_titleLabel", BindingFlags.NonPublic | BindingFlags.Instance);

        Assert.NotNull(sidebarField);
        Assert.NotNull(contentField);
        Assert.NotNull(titleField);

        var sidebar = (Panel)sidebarField!.GetValue(form)!;
        var navigationPanel = sidebar.Controls.OfType<FlowLayoutPanel>().Single();
        var button = navigationPanel.Controls.OfType<Button>().SingleOrDefault(candidate => Equals(candidate.Tag, pageName));
        var content = (Panel)contentField!.GetValue(form)!;
        var title = (Label)titleField!.GetValue(form)!;

        Assert.NotNull(button);
        typeof(Button).GetMethod("OnClick", BindingFlags.NonPublic | BindingFlags.Instance)!
            .Invoke(button, new object[] { EventArgs.Empty });

        var expectedTitle = pageName switch
        {
            "Wi‑Fi Networks" => "Network Center",
            "Multiplayer Rooms" => "Multiplayer Rooms",
            "Ludo" => "Ludo Arena",
            _ => pageName
        };
        Assert.Equal(expectedTitle, title.Text);
        Assert.True(content.Controls.Count > 0, $"The content panel did not load the {pageName} page.");
        form.Dispose();
    }

    [Fact]
    public void Chat_Navigation_Opens_The_Lobby_In_Chat_Only_Mode()
    {
        using var form = new MainForm(enableNetworkProbes: false);
        var navigation = GetField<Panel>(form, "_sidebar").Controls.OfType<FlowLayoutPanel>().Single();
        var chatButton = navigation.Controls.OfType<Button>().Single(button => Equals(button.Tag, "Chat"));

        Click(chatButton);

        var lobby = Assert.IsType<MultiplayerForm>(GetField<Panel>(form, "_content").Controls[0]);
        Assert.Equal("Chat Only", GetField<ComboBox>(lobby, "_gameChoice").SelectedItem);
        Assert.Equal("Chat", GetField<Label>(form, "_titleLabel").Text);
    }

    [Fact]
    public void Games_Navigation_Focuses_The_Existing_Game_Cards()
    {
        using var form = new MainForm(enableNetworkProbes: false);
        var navigation = GetField<Panel>(form, "_sidebar").Controls.OfType<FlowLayoutPanel>().Single();
        var gamesButton = navigation.Controls.OfType<Button>().Single(button => Equals(button.Tag, "Games"));
        Click(gamesButton);

        var dashboard = Assert.IsType<DashboardForm>(GetField<Dictionary<string, Form>>(form, "_pages")["Dashboard"]);
        var root = Assert.IsType<TableLayoutPanel>(dashboard.Controls[0]);
        Assert.Equal(0F, root.RowStyles[0].Height);
        Assert.Contains(FindControls<Label>(dashboard), label => label.Text == "All games");

        var dashboardButton = navigation.Controls.OfType<Button>().Single(button => Equals(button.Tag, "Dashboard"));
        Click(dashboardButton);
        Assert.Equal(136F, root.RowStyles[0].Height);
        Assert.Contains(FindControls<Label>(dashboard), label => label.Text == "Featured games");
    }

    [Fact]
    public void Chess_Navigation_Shows_Mode_Selection_Before_Starting_A_Game()
    {
        using var form = new MainForm(enableNetworkProbes: false);
        var content = GetField<Panel>(form, "_content");
        var navigation = GetField<Panel>(form, "_sidebar").Controls.OfType<FlowLayoutPanel>().Single();
        var chessButton = navigation.Controls.OfType<Button>().Single(button => Equals(button.Tag, "Chess"));
        Click(chessButton);

        Assert.IsType<GameModeForm>(content.Controls[0]);
    }

    [Fact]
    public void Game_Mode_Back_Returns_To_The_Dashboard()
    {
        using var form = new MainForm(enableNetworkProbes: false);
        var navigation = GetField<Panel>(form, "_sidebar").Controls.OfType<FlowLayoutPanel>().Single();
        Click(navigation.Controls.OfType<Button>().Single(button => Equals(button.Tag, "Ludo")));

        var content = GetField<Panel>(form, "_content");
        Assert.IsType<GameModeForm>(content.Controls[0]);
        var backButton = FindControls<Button>(content.Controls[0])
            .Single(button => button.Text.Contains("Back to games", StringComparison.Ordinal));
        Click(backButton);

        Assert.IsType<DashboardForm>(content.Controls[0]);
        Assert.Equal("Dashboard", GetField<Label>(form, "_titleLabel").Text);
    }

    [Theory]
    [InlineData("Chess", "Chess Solo", typeof(ChessForm), "Chess")]
    [InlineData("Ludo", "Ludo Solo", typeof(LudoForm), "Ludo")]
    [InlineData("Tic Tac Toe", "Tic Tac Toe Solo", typeof(TicTacToeForm), "Tic Tac Toe")]
    [InlineData("Carrom", "Carrom Solo", typeof(CarromForm), "Carrom")]
    public void Game_Mode_Opens_Local_Play_Or_The_Correct_Room_Lobby(
        string game,
        string soloPage,
        Type expectedType,
        string expectedLobbyGame)
    {
        using var form = new MainForm(enableNetworkProbes: false);
        var navigation = GetField<Panel>(form, "_sidebar").Controls.OfType<FlowLayoutPanel>().Single();
        var gameButton = navigation.Controls.OfType<Button>().Single(button => Equals(button.Tag, game));
        Click(gameButton);

        var mode = Assert.IsType<GameModeForm>(GetField<Panel>(form, "_content").Controls[0]);
        var soloButton = FindControls<Button>(mode).Single(button => button.Text.StartsWith("Play Locally", StringComparison.Ordinal));
        Click(soloButton);

        var pages = GetField<Dictionary<string, Form>>(form, "_pages");
        var soloForm = pages[soloPage];
        Assert.Equal(expectedType, soloForm.GetType());
        if (soloForm is not CarromForm)
        {
            Assert.Null(GetField<MultiplayerSession?>(soloForm, "_session"));
        }

        Click(gameButton);
        mode = Assert.IsType<GameModeForm>(GetField<Panel>(form, "_content").Controls[0]);
        var roomButton = FindControls<Button>(mode).Single(button => button.Text.StartsWith("Find a Room", StringComparison.Ordinal));
        Click(roomButton);

        var lobby = Assert.IsType<MultiplayerForm>(GetField<Panel>(form, "_content").Controls[0]);
        Assert.Equal(expectedLobbyGame, GetField<ComboBox>(lobby, "_gameChoice").SelectedItem);
    }

    [Fact]
    public void Carrom_Room_Entry_Uses_Existing_Lobby_With_Host_And_Join_Enabled()
    {
        using var form = new MainForm(enableNetworkProbes: false);
        var navigation = GetField<Panel>(form, "_sidebar").Controls.OfType<FlowLayoutPanel>().Single();
        Click(navigation.Controls.OfType<Button>().Single(button => Equals(button.Tag, "Carrom")));
        var content = GetField<Panel>(form, "_content");
        var mode = Assert.IsType<GameModeForm>(content.Controls[0]);
        Click(FindControls<Button>(mode).Single(button => button.Text.StartsWith("Find a Room", StringComparison.Ordinal)));

        var lobby = Assert.IsType<MultiplayerForm>(content.Controls[0]);
        Assert.Equal("Carrom", GetField<ComboBox>(lobby, "_gameChoice").SelectedItem);
        Assert.True(GetField<Button>(lobby, "_hostButton").Enabled);
        Assert.False(GetField<Button>(lobby, "_joinButton").Enabled);
        Assert.True(GetField<Button>(lobby, "_joinByIdButton").Enabled);
        Assert.DoesNotContain("not implemented", GetField<Label>(lobby, "_connectionStatus").Text, StringComparison.OrdinalIgnoreCase);
    }

    [Fact]
    public void Solo_Chess_Uses_Local_Form_And_Room_Option_Selects_Chess_In_Lobby()
    {
        using var form = new MainForm(enableNetworkProbes: false);
        var content = GetField<Panel>(form, "_content");
        var sidebar = GetField<Panel>(form, "_sidebar");
        var navigation = sidebar.Controls.OfType<FlowLayoutPanel>().Single();
        var chessButton = navigation.Controls.OfType<Button>().Single(button => Equals(button.Tag, "Chess"));
        Click(chessButton);

        var mode = Assert.IsType<GameModeForm>(content.Controls[0]);
        var buttons = FindControls<Button>(mode).ToArray();
        Click(buttons.Single(button => button.Text.StartsWith("Play Locally", StringComparison.Ordinal)));

        var pages = GetField<Dictionary<string, Form>>(form, "_pages");
        var soloChess = Assert.IsType<ChessForm>(pages["Chess Solo"]);
        Assert.Null(GetField<WiFiGameHub.Networking.MultiplayerSession?>(soloChess, "_session"));

        Click(chessButton);
        mode = Assert.IsType<GameModeForm>(content.Controls[0]);
        buttons = FindControls<Button>(mode).ToArray();
        Click(buttons.Single(button => button.Text.StartsWith("Find a Room", StringComparison.Ordinal)));

        var lobby = Assert.IsType<MultiplayerForm>(content.Controls[0]);
        var gameChoice = GetField<ComboBox>(lobby, "_gameChoice");
        Assert.Equal("Chess", gameChoice.SelectedItem);
    }

    [Fact]
    public void Chess_Exit_Control_Returns_To_The_Dashboard()
    {
        using var form = new MainForm(enableNetworkProbes: false);
        var navigation = GetField<Panel>(form, "_sidebar").Controls.OfType<FlowLayoutPanel>().Single();
        Click(navigation.Controls.OfType<Button>().Single(button => Equals(button.Tag, "Chess")));
        var mode = Assert.IsType<GameModeForm>(GetField<Panel>(form, "_content").Controls[0]);
        Click(FindControls<Button>(mode).Single(button => button.Text.StartsWith("Play Locally", StringComparison.Ordinal)));

        var chess = Assert.IsType<ChessForm>(GetField<Panel>(form, "_content").Controls[0]);
        Click(GetField<Button>(chess, "_exit"));

        Assert.IsType<DashboardForm>(GetField<Panel>(form, "_content").Controls[0]);
    }

    private static T GetField<T>(object instance, string name)
    {
        var field = instance.GetType().GetField(name, BindingFlags.NonPublic | BindingFlags.Instance);
        Assert.NotNull(field);
        return (T)field!.GetValue(instance)!;
    }

    private static void Click(Button button) =>
        typeof(Button).GetMethod("OnClick", BindingFlags.NonPublic | BindingFlags.Instance)!
            .Invoke(button, new object[] { EventArgs.Empty });

    private static IEnumerable<T> FindControls<T>(Control parent) where T : Control
    {
        foreach (Control child in parent.Controls)
        {
            if (child is T match)
            {
                yield return match;
            }

            foreach (var nested in FindControls<T>(child))
            {
                yield return nested;
            }
        }
    }
}
