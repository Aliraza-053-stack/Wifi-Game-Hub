using WiFiGameHub.Games.Ludo;
using Xunit;

namespace WiFiGameHub.Tests;

public class LudoGameTests
{
    [Fact]
    public void Turn_Advancement_Skips_Inactive_Players_And_Keeps_Their_Colors()
    {
        var game = new LudoGame(4, () => 6, playerColors: new[] { "Red", "Yellow", "Green", "Blue" });
        var positions = Enumerable.Repeat(-1, 16).ToArray();
        positions[4] = 0;
        game.RestoreState(positions, 0, 0, 0, false, string.Empty, Array.Empty<string>());
        Assert.Equal(39, game.GetTrackCell(1, 0) ?? -1);
        game.SetPlayerActive(0, false);
        game.SetPlayerActive(1, false);

        Assert.Equal(2, game.CurrentPlayerIndex);
        Assert.False(game.HasLegalMove(0));
        Assert.False(game.Players[0].IsActive);
    }

    [Fact]
    public void Forfeit_Ends_Ludo_Without_Changing_Normal_Win_Rules()
    {
        var game = new LudoGame(2);
        game.EndByForfeit("Remaining Player");

        Assert.True(game.IsGameOver);
        Assert.Equal("Remaining Player", game.Winner);
        Assert.Contains("won by forfeit", game.MoveHistory[^1], StringComparison.OrdinalIgnoreCase);
    }

    [Fact]
    public void A_Standard_Game_Has_Four_Colored_Players_With_Four_Tokens_Each()
    {
        var game = new LudoGame();

        Assert.Equal(new[] { "Red", "Blue", "Green", "Yellow" }, game.Players.Select(player => player.Color));
        Assert.All(game.Players, player => Assert.Equal(4, player.Tokens.Count));
    }

    [Fact]
    public void A_Standard_Roll_Produces_Valid_Dice_Value()
    {
        var game = new LudoGame();

        var value = game.RollDice();

        Assert.InRange(value, 1, 6);
    }

    [Fact]
    public void Token_Cannot_Leave_Home_Without_A_Six()
    {
        var game = CreateGame(2);

        Assert.Equal(2, game.RollDice());
        Assert.False(game.CanMoveToken(0, 0));
        Assert.Equal(1, game.CurrentPlayerIndex);
    }

    [Fact]
    public void Six_Allows_Token_To_Leave_Home()
    {
        var game = CreateGame(6);
        var player = game.Players[0];

        Assert.Equal(6, game.RollDice());
        Assert.True(game.MoveToken(0, 0));
        Assert.Equal(0, player.Tokens[0].Position);
        Assert.Equal(0, game.CurrentPlayerIndex);
    }

    [Fact]
    public void Players_Are_Stopped_When_They_Have_No_Valid_Move()
    {
        var game = CreateGame(3);

        Assert.Equal(3, game.RollDice());
        Assert.False(game.HasLegalMove(0));
        Assert.Equal(1, game.CurrentPlayerIndex);
        Assert.Equal(0, game.LastDiceValue);
    }

    [Fact]
    public void Token_Must_Roll_Exact_Value_To_Finish()
    {
        var game = CreateGame(2);
        game.Players[0].Tokens[0].Position = LudoGame.FinishPosition - 1;

        Assert.Equal(2, game.RollDice());
        Assert.False(game.CanMoveToken(0, 0));
    }

    [Fact]
    public void Opponent_Is_Cut_On_Non_Safe_Shared_Cell()
    {
        var game = CreateGame(1, 1);
        game.Players[0].Tokens[0].Position = 0;
        game.Players[1].Tokens[0].Position = 40;

        game.RollDice();
        Assert.True(game.MoveToken(0, 0));

        Assert.True(game.Players[1].Tokens[0].IsAtHome);
    }

    [Fact]
    public void Opponent_Is_Protected_On_Safe_Cell()
    {
        var game = CreateGame(1, 1);
        game.Players[0].Tokens[0].Position = 7;
        game.Players[1].Tokens[0].Position = 47;

        game.RollDice();
        Assert.True(game.MoveToken(0, 0));

        Assert.False(game.Players[1].Tokens[0].IsAtHome);
    }

    [Fact]
    public void Non_Six_Switches_Turn_And_Six_Retains_Turn()
    {
        var game = CreateGame(6, 2);
        game.Players[0].Tokens[0].Position = 0;

        game.RollDice();
        game.MoveToken(0, 0);
        Assert.Equal(0, game.CurrentPlayerIndex);

        game.RollDice();
        game.MoveToken(0, 0);
        Assert.Equal(1, game.CurrentPlayerIndex);
    }

    [Fact]
    public void Winner_Is_Detected_When_Last_Token_Finishes_Exactly()
    {
        var game = CreateGame(1, 1);
        for (var tokenIndex = 0; tokenIndex < 3; tokenIndex++)
        {
            game.Players[0].Tokens[tokenIndex].Position = LudoGame.FinishPosition;
        }
        game.Players[0].Tokens[3].Position = LudoGame.FinishPosition - 1;

        game.RollDice();
        Assert.True(game.MoveToken(0, 3));

        Assert.True(game.IsGameOver);
        Assert.Equal("Red", game.Winner);
    }

    [Fact]
    public void Invalid_Player_And_Token_Indexes_Are_Rejected()
    {
        var game = CreateGame(6);

        Assert.False(game.CanMoveToken(-1, 0));
        Assert.False(game.CanMoveToken(0, 4));
        Assert.False(game.MoveToken(0, 4));
    }

    private static LudoGame CreateGame(params int[] rolls)
    {
        var nextRoll = 0;
        return new LudoGame(2, () => rolls[nextRoll++ % rolls.Length]);
    }
}
