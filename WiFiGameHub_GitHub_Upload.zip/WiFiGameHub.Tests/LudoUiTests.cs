using System.Drawing;
using System.Reflection;
using System.Windows.Forms;
using WiFiGameHub.Forms;
using WiFiGameHub.Games.Ludo;
using Xunit;

namespace WiFiGameHub.Tests;

public class LudoUiTests
{
    [Theory]
    [InlineData(600, 480)]
    [InlineData(480, 600)]
    public void Resized_Board_Renders_And_Uses_Aligned_Token_HitTargets(int width, int height)
    {
        var game = new LudoGame(2, () => 6);
        game.RollDice();
        using var board = new LudoBoard
        {
            Size = new Size(width, height),
            Game = game,
            HighlightedTokens = new[] { 0 }
        };
        (int Player, int Token)? selected = null;
        board.TokenSelected += (player, token) => selected = (player, token);

        using var bitmap = new Bitmap(width, height);
        board.DrawToBitmap(bitmap, new Rectangle(0, 0, width, height));
        ClickLudoToken(board, width, height, 0, 0);

        Assert.NotNull(selected);
        Assert.Equal((0, 0), selected!.Value);
    }

    [Fact]
    public void Rolling_A_Six_Highlights_Only_EngineLegal_Tokens_And_Updates_Player_Status()
    {
        using var form = new LudoForm();
        var game = new LudoGame(2, () => 6, new[] { "Morgan", "Riley" });
        SetField(form, "_game", game);
        typeof(LudoForm).GetMethod("RollDice", BindingFlags.NonPublic | BindingFlags.Instance)!
            .Invoke(form, null);

        var board = GetField<LudoBoard>(form, "_board");
        Assert.Equal(new[] { 0, 1, 2, 3 }, board.HighlightedTokens.OrderBy(index => index));
        Assert.Equal("RED TURN  ·  Morgan", GetField<Label>(form, "_turnLabel").Text);
        Assert.Contains("MORGAN", GetField<Label[]>(form, "_playerStatusLabels")[0].Text.ToUpperInvariant());
        Assert.Equal(6, game.LastDiceValue);
    }

    [Fact]
    public void Exit_Control_Invokes_The_Return_Action()
    {
        var exited = false;
        using var form = new LudoForm(onExit: () => exited = true);
        var exit = GetField<Button>(form, "_exitButton");

        typeof(Button).GetMethod("OnClick", BindingFlags.NonPublic | BindingFlags.Instance)!
            .Invoke(exit, new object[] { EventArgs.Empty });

        Assert.True(exited);
    }

    private static void ClickLudoToken(LudoBoard board, int width, int height, int row, int column)
    {
        var boardSize = Math.Min(width, height) - 16;
        var cell = boardSize / 15f;
        var boardLeft = (width - boardSize) / 2f;
        var boardTop = (height - boardSize) / 2f;
        var slotX = 1 + column * 3;
        var slotY = 1 + row * 3;
        var point = new Point(
            (int)(boardLeft + (slotX + 0.5f) * cell),
            (int)(boardTop + (slotY + 0.5f) * cell));
        typeof(Control).GetMethod("OnMouseClick", BindingFlags.NonPublic | BindingFlags.Instance)!
            .Invoke(board, new object[] { new MouseEventArgs(MouseButtons.Left, 1, point.X, point.Y, 0) });
    }

    private static T GetField<T>(object instance, string name)
    {
        var field = instance.GetType().GetField(name, BindingFlags.NonPublic | BindingFlags.Instance);
        Assert.NotNull(field);
        return (T)field!.GetValue(instance)!;
    }

    private static void SetField<T>(object instance, string name, T value)
    {
        var field = instance.GetType().GetField(name, BindingFlags.NonPublic | BindingFlags.Instance);
        Assert.NotNull(field);
        field!.SetValue(instance, value);
    }
}
