using WiFiGameHub.Games.TicTacToe;
using Xunit;

namespace WiFiGameHub.Tests;

public class TicTacToeGameTests
{
    [Fact]
    public void X_Wins_On_Three_In_A_Row()
    {
        var game = new TicTacToeGame();

        Assert.True(game.MakeMove(0, 0, "X"));
        Assert.True(game.MakeMove(1, 0, "O"));
        Assert.True(game.MakeMove(0, 1, "X"));
        Assert.True(game.MakeMove(1, 1, "O"));
        Assert.True(game.MakeMove(0, 2, "X"));

        Assert.True(game.IsGameOver);
        Assert.Equal("X", game.Winner);
        Assert.Equal(3, game.WinningLine.Count);
    }

    [Fact]
    public void Illegal_Move_Is_Rejected_When_Cell_Is_Already_Filled()
    {
        var game = new TicTacToeGame();

        Assert.True(game.MakeMove(2, 2, "X"));
        Assert.False(game.MakeMove(2, 2, "O"));
    }

    [Fact]
    public void O_Can_Win_And_Turn_Changes_After_Valid_Moves()
    {
        var game = new TicTacToeGame();

        Assert.True(game.MakeMove(0, 0, "X"));
        Assert.Equal("O", game.CurrentPlayer);
        Assert.True(game.MakeMove(0, 1, "O"));
        Assert.True(game.MakeMove(1, 0, "X"));
        Assert.True(game.MakeMove(1, 1, "O"));
        Assert.True(game.MakeMove(2, 2, "X"));
        Assert.True(game.MakeMove(2, 1, "O"));

        Assert.True(game.IsGameOver);
        Assert.Equal("O", game.Winner);
        Assert.Equal(1, game.OScore);
    }

    [Fact]
    public void Wrong_Player_And_Out_Of_Bounds_Moves_Are_Rejected()
    {
        var game = new TicTacToeGame();

        Assert.False(game.MakeMove(0, 0, "O"));
        Assert.False(game.MakeMove(-1, 0, "X"));
        Assert.False(game.MakeMove(0, 3, "X"));
    }

    [Fact]
    public void Draw_Is_Detected_When_Board_Is_Full_Without_A_Winner()
    {
        var game = new TicTacToeGame();

        game.Board[0, 0] = TicTacToeMark.X;
        game.Board[0, 1] = TicTacToeMark.O;
        game.Board[0, 2] = TicTacToeMark.X;
        game.Board[1, 0] = TicTacToeMark.X;
        game.Board[1, 1] = TicTacToeMark.O;
        game.Board[1, 2] = TicTacToeMark.O;
        game.Board[2, 0] = TicTacToeMark.O;
        game.Board[2, 1] = TicTacToeMark.X;
        game.Board[2, 2] = TicTacToeMark.Empty;

        Assert.True(game.MakeMove(2, 2, "X"));
        Assert.True(game.IsGameOver);
        Assert.True(game.IsDraw);
    }

    [Fact]
    public void Reset_Begins_New_Round_And_Preserves_Score()
    {
        var game = new TicTacToeGame();
        Assert.True(game.MakeMove(0, 0, "X"));
        Assert.True(game.MakeMove(1, 0, "O"));
        Assert.True(game.MakeMove(0, 1, "X"));
        Assert.True(game.MakeMove(1, 1, "O"));
        Assert.True(game.MakeMove(0, 2, "X"));

        game.ResetBoard();

        Assert.Equal(1, game.XScore);
        Assert.Equal("X", game.CurrentPlayer);
        Assert.False(game.IsGameOver);
        Assert.All(game.Board.Cast<TicTacToeMark>(), mark => Assert.Equal(TicTacToeMark.Empty, mark));
    }
}
