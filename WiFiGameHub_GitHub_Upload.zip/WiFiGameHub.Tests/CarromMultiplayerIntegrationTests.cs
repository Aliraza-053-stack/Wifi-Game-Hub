using System.Numerics;
using System.Reflection;
using System.Text.Json;
using WiFiGameHub.Games.Carrom;
using WiFiGameHub.Networking;
using Xunit;

namespace WiFiGameHub.Tests;

public sealed class CarromMultiplayerIntegrationTests
{
    [Fact]
    public async Task Queen_Cover_Is_Synchronized_After_Authoritative_Shot()
    {
        using var host = new MultiplayerSession();
        using var guest = new MultiplayerSession();
        host.StartHost("Carrom", GetAvailablePort(), "White Player");
        ConfigureHost(host, CreateBoard(queenAndWhiteAtPocket: true), CreateRules(whitePocketed: 1, whiteTotal: 1));
        await guest.JoinAsync("127.0.0.1", host.Port, host.RoomId, "Carrom", "Black Player");
        await WaitUntilAsync(() => guest.CurrentState is { Started: true, Players.Count: 2 });

        Assert.True(await host.SendActionAsync(CreateShot(500F, 500F, 1000F)));
        await WaitUntilAsync(() => guest.CurrentState?.CarromLastShotActionId == host.CurrentState?.CarromLastShotActionId
            && guest.CurrentState?.CarromQueenClaimed == true);

        Assert.True(host.CurrentState!.CarromQueenClaimed);
        Assert.Equal(0, host.CurrentState.CarromQueenClaimedByPlayer);
        Assert.Equal(0, guest.CurrentState!.CarromQueenClaimedByPlayer);
        Assert.Equal(2, guest.CurrentState.CarromWhitePocketedCoins);
        Assert.Equal(host.CurrentState.CarromPieces, guest.CurrentState.CarromPieces);
    }

    [Fact]
    public async Task Striker_Foul_Is_Synchronized_And_Passes_The_Turn()
    {
        using var host = new MultiplayerSession();
        using var guest = new MultiplayerSession();
        host.StartHost("Carrom", GetAvailablePort(), "White Player");
        ConfigureHost(host, CreateBoard(strikerAtFoulLine: true), CreateRules());
        await guest.JoinAsync("127.0.0.1", host.Port, host.RoomId, "Carrom", "Black Player");
        await WaitUntilAsync(() => guest.CurrentState is { Started: true, Players.Count: 2 });

        Assert.True(await host.SendActionAsync(CreateShot(240F, 318F, 786F)));
        Assert.True(host.CurrentState!.CarromWhiteFouls == 1, host.CurrentState.CarromLastResult);
        await WaitUntilAsync(() => guest.CurrentState?.CarromWhiteFouls == 1);

        Assert.Equal(1, host.CurrentState!.CarromWhiteFouls);
        Assert.Equal(1, guest.CurrentState!.CarromWhiteFouls);
        Assert.Equal(1, guest.CurrentState.CarromCurrentPlayerIndex);
        Assert.Equal(host.CurrentState.CarromPieces, guest.CurrentState.CarromPieces);
    }

    [Fact]
    public async Task Match_Completion_And_Final_Score_Are_Synchronized()
    {
        using var host = new MultiplayerSession();
        using var guest = new MultiplayerSession();
        host.StartHost("Carrom", GetAvailablePort(), "White Player");
        ConfigureHost(host,
            CreateBoard(onlyFinalWhiteCoin: true),
            CreateRules(whiteScore: 24, whitePocketed: 8, whiteTotal: 8, queenClaimed: true, queenClaimedBy: 0));
        await guest.JoinAsync("127.0.0.1", host.Port, host.RoomId, "Carrom", "Black Player");
        await WaitUntilAsync(() => guest.CurrentState is { Started: true, Players.Count: 2 });

        Assert.True(await host.SendActionAsync(CreateShot(500F, 500F, 1000F)));
        await WaitUntilAsync(() => guest.CurrentState is { IsGameOver: true });

        Assert.True(host.CurrentState!.IsGameOver);
        Assert.Equal(host.LocalPlayerId, host.CurrentState.WinnerId);
        Assert.Equal(host.CurrentState.WinnerId, guest.CurrentState!.WinnerId);
        Assert.Equal(27, guest.CurrentState.CarromWhiteScore);
        Assert.Equal(3, guest.CurrentState.CarromWhiteQueenBonus);
        Assert.Equal(host.CurrentState.CarromWhiteTotalPocketedCoins, guest.CurrentState.CarromWhiteTotalPocketedCoins);

        Assert.True(await guest.SendActionAsync(new GameActionRequest { Action = "carrom-reset" }));
        await WaitUntilAsync(() => host.CurrentState is { IsGameOver: false, CarromWhiteScore: 0 }
            && guest.CurrentState is { IsGameOver: false, CarromWhiteScore: 0 });
        Assert.Equal(host.CurrentState!.CarromPieces, guest.CurrentState!.CarromPieces);
    }

    [Fact]
    public async Task Client_Rejects_Forged_And_Stale_Host_Snapshots()
    {
        using var host = new MultiplayerSession();
        using var guest = new MultiplayerSession();
        host.StartHost("Carrom", GetAvailablePort(), "White Player");
        await guest.JoinAsync("127.0.0.1", host.Port, host.RoomId, "Carrom", "Black Player");
        await WaitUntilAsync(() => guest.CurrentState is { Started: true, Players.Count: 2 });
        var acceptedState = guest.CurrentState!;
        var forged = JsonSerializer.Deserialize<GameSessionState>(JsonSerializer.Serialize(acceptedState))!;
        forged.Revision++;
        forged.CarromWhiteScore = 500;

        SendClientState(guest, "spoofed-host", forged);
        Assert.Equal(acceptedState.Revision, guest.CurrentState!.Revision);
        Assert.Equal(0, guest.CurrentState.CarromWhiteScore);

        var stale = JsonSerializer.Deserialize<GameSessionState>(JsonSerializer.Serialize(acceptedState))!;
        stale.Revision--;
        SendClientState(guest, host.LocalPlayerId, stale);
        Assert.Equal(acceptedState.Revision, guest.CurrentState!.Revision);
        Assert.Equal(0, guest.CurrentState.CarromWhiteScore);
    }

    private static CarromPhysicsEngine CreateBoard(
        bool queenAndWhiteAtPocket = false,
        bool strikerAtFoulLine = false,
        bool onlyFinalWhiteCoin = false)
    {
        var template = new CarromPhysicsEngine();
        var definitions = template.Pieces.Select(piece =>
        {
            var position = piece.Position;
            if (piece.Type == CarromPieceType.Black)
            {
                var index = piece.Id - 1;
                position = new Vector2(300F + index % 3 * 75F, 300F + index / 3 * 65F);
            }
            else if (piece.Type == CarromPieceType.White)
            {
                var index = piece.Id - 10;
                position = new Vector2(560F + index % 3 * 75F, 300F + index / 3 * 65F);
            }
            else if (piece.Type == CarromPieceType.Queen)
            {
                position = new Vector2(500F, 500F);
            }
            else if (piece.Type == CarromPieceType.Striker && strikerAtFoulLine)
            {
                position = new Vector2(240F, CarromPhysicsEngine.StrikerBaselineY);
            }

            if (queenAndWhiteAtPocket && piece.Id is 10 or 19)
            {
                position = new Vector2(140F, 150F);
            }
            else if (onlyFinalWhiteCoin && piece.Id == 10)
            {
                position = new Vector2(140F, 150F);
            }

            return new CarromPieceDefinition(piece.Id, piece.Type, position, piece.Radius, piece.Mass);
        }).ToArray();
        var board = new CarromPhysicsEngine(definitions);
        if (onlyFinalWhiteCoin)
        {
            var snapshots = board.CreateSnapshot()
                .Select(piece => piece with { IsActive = piece.Type == CarromPieceType.Striker || piece.Id == 10 })
                .ToArray();
            board.RestoreSnapshot(snapshots, 0);
        }
        return board;
    }

    private static CarromRulesEngine CreateRules(
        int whiteScore = 0,
        int whitePocketed = 0,
        int whiteTotal = 0,
        bool queenClaimed = false,
        int? queenClaimedBy = null)
    {
        var rules = new CarromRulesEngine();
        rules.RestoreState(0, 0, whiteScore, 0, 0, 0, whitePocketed, 0,
            whiteTotal, 0, 0, 0, null, queenClaimed, queenClaimedBy,
            false, false, null, 0);
        return rules;
    }

    private static void ConfigureHost(
        MultiplayerSession host,
        CarromPhysicsEngine board,
        CarromRulesEngine rules)
    {
        typeof(MultiplayerSession).GetField("_carrom", BindingFlags.NonPublic | BindingFlags.Instance)!
            .SetValue(host, board);
        typeof(MultiplayerSession).GetField("_carromRules", BindingFlags.NonPublic | BindingFlags.Instance)!
            .SetValue(host, rules);
    }

    private static void SendClientState(MultiplayerSession client, string senderId, GameSessionState state) =>
        typeof(MultiplayerSession).GetMethod("HandleClientMessage", BindingFlags.NonPublic | BindingFlags.Instance)!
            .Invoke(client, [new NetworkMessage
            {
                SenderId = senderId,
                RoomId = state.RoomId,
                Type = NetworkMessageType.GameState,
                Payload = JsonSerializer.Serialize(state)
            }]);

    private static GameActionRequest CreateShot(float strikerX, float pullX, float pullY) => new()
    {
        Action = "carrom-shot",
        CarromStrikerX = strikerX,
        CarromAimX = pullX,
        CarromAimY = pullY,
        CarromPower = 100F
    };

    private static int GetAvailablePort()
    {
        using var listener = new System.Net.Sockets.TcpListener(System.Net.IPAddress.Loopback, 0);
        listener.Start();
        return ((System.Net.IPEndPoint)listener.LocalEndpoint).Port;
    }

    private static async Task WaitUntilAsync(Func<bool> condition)
    {
        var timeout = DateTime.UtcNow + TimeSpan.FromSeconds(5);
        while (!condition())
        {
            if (DateTime.UtcNow >= timeout)
            {
                throw new TimeoutException("The Carrom multiplayer state did not synchronize in time.");
            }
            await Task.Delay(20);
        }
    }
}
