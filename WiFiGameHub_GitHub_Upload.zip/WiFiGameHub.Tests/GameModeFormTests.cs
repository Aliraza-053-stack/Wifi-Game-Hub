using System.Windows.Forms;
using WiFiGameHub.Forms;
using Xunit;

namespace WiFiGameHub.Tests;

public class GameModeFormTests
{
    [Fact]
    public void Mode_Cards_Open_Independent_Solo_And_Room_Flows()
    {
        var soloOpened = false;
        var roomOpened = false;
        using var form = new GameModeForm(
            "Chess",
            "Play locally.",
            () => soloOpened = true,
            () => roomOpened = true);

        var buttons = FindControls<Button>(form).ToArray();
        Assert.Contains(buttons, button => button.Text.StartsWith("Play Locally", StringComparison.Ordinal));
        Assert.Contains(buttons, button => button.Text.StartsWith("Find a Room", StringComparison.Ordinal));
        Assert.Contains(FindControls<Label>(form), label => label.Text == "Choose Your Game Mode");
        Click(buttons.Single(button => button.Text.StartsWith("Play Locally", StringComparison.Ordinal)));
        Assert.True(soloOpened);
        Assert.False(roomOpened);

        Click(buttons.Single(button => button.Text.StartsWith("Find a Room", StringComparison.Ordinal)));
        Assert.True(roomOpened);
    }

    [Fact]
    public void Back_Button_Invokes_The_Previous_Screen_Callback()
    {
        var wentBack = false;
        using var form = new GameModeForm("Ludo", "Play locally.", () => { }, () => { }, () => wentBack = true);
        var backButton = FindControls<Button>(form).Single(button => button.Text.Contains("Back to games", StringComparison.Ordinal));

        Click(backButton);

        Assert.True(wentBack);
    }

    [Theory]
    [InlineData("Chess")]
    [InlineData("Ludo")]
    [InlineData("Tic-Tac-Toe")]
    public void Mode_Screen_Shows_Selected_Game(string gameName)
    {
        using var form = new GameModeForm(gameName, "Play locally.", () => { }, () => { });

        Assert.Contains(FindControls<Label>(form), label => label.Text == $"{gameName}  ·  Pick how you want to play");
    }

    private static IEnumerable<T> FindControls<T>(Control parent) where T : Control
    {
        foreach (Control child in parent.Controls)
        {
            if (child is T match)
            {
                yield return match;
            }

            foreach (var nested in FindControls<T>(child))
            {
                yield return nested;
            }
        }
    }

    private static void Click(Button button) =>
        typeof(Button).GetMethod("OnClick", System.Reflection.BindingFlags.NonPublic | System.Reflection.BindingFlags.Instance)!
            .Invoke(button, new object[] { EventArgs.Empty });
}
