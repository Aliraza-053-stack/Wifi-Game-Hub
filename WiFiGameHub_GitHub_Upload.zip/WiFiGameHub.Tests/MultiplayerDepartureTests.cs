using System.Net;
using System.Net.Sockets;
using System.Reflection;
using System.Windows.Forms;
using WiFiGameHub.Forms;
using WiFiGameHub.Networking;
using Xunit;

namespace WiFiGameHub.Tests;

public class MultiplayerDepartureTests
{
    [Theory]
    [InlineData("Chess")]
    [InlineData("Ludo")]
    [InlineData("TicTacToe")]
    public async Task Leaving_Two_Player_Match_Declares_The_Remaining_Player_Winner(string game)
    {
        using var host = new MultiplayerSession(() => 6);
        using var guest = new MultiplayerSession();
        host.StartHost(game, GetAvailablePort(), "Host Player");
        await guest.JoinAsync("127.0.0.1", host.Port, host.RoomId, game, "Guest Player");
        await WaitUntilAsync(() => host.CurrentState is { Players.Count: 2 }
            && guest.CurrentState is { Players.Count: 2 });

        if (game == "Ludo")
        {
            Assert.True(await host.SendActionAsync(new GameActionRequest { Action = "start" }));
            await WaitUntilAsync(() => host.CurrentState is { Started: true, LudoTokenPositions.Length: 8 });
        }
        else
        {
            await WaitUntilAsync(() => host.CurrentState is { Started: true });
        }

        var guestId = guest.LocalPlayerId;
        await guest.LeaveGameAsync();
        await WaitUntilAsync(() => host.CurrentState is
            { IsGameOver: true, IsForfeit: true, WinnerId: var winnerId } && winnerId == host.LocalPlayerId);

        Assert.Equal("Guest Player", host.CurrentState!.LastDepartedPlayerName);
        Assert.Contains(host.CurrentState.Players, player => player.PlayerId == guestId && !player.Connected);
        Assert.Contains(host.CurrentState.Players, player => player.PlayerId == host.LocalPlayerId && player.Connected);
        Assert.False(await host.SendActionAsync(new GameActionRequest { Action = "restart" }));
    }

    [Fact]
    public async Task Host_And_Guest_Receive_The_Same_Forfeit_Result_When_Host_Leaves_Match()
    {
        using var host = new MultiplayerSession();
        using var guest = new MultiplayerSession();
        host.StartHost("Chess", GetAvailablePort(), "Host Player");
        await guest.JoinAsync("127.0.0.1", host.Port, host.RoomId, "Chess", "Guest Player");
        await WaitUntilAsync(() => guest.CurrentState is { Started: true, Players.Count: 2 });

        await host.LeaveGameAsync();
        await WaitUntilAsync(() => guest.CurrentState is { IsGameOver: true, IsForfeit: true });

        Assert.True(host.CurrentState!.IsForfeit);
        Assert.Equal(host.CurrentState.WinnerId, guest.CurrentState!.WinnerId);
        Assert.Equal(guest.LocalPlayerId, guest.CurrentState.WinnerId);
        Assert.Equal("Host Player", guest.CurrentState.LastDepartedPlayerName);
    }

    [Theory]
    [InlineData("Chess")]
    [InlineData("Ludo")]
    [InlineData("TicTacToe")]
    public async Task Remaining_Player_Sees_A_Clear_Leave_And_Win_Notification(string game)
    {
        using var host = new MultiplayerSession(() => 6);
        using var guest = new MultiplayerSession();
        host.StartHost(game, GetAvailablePort(), "Host Player");
        await guest.JoinAsync("127.0.0.1", host.Port, host.RoomId, game, "Guest Player");
        await WaitUntilAsync(() => host.CurrentState is { Players.Count: 2 });
        if (game == "Ludo")
        {
            Assert.True(await host.SendActionAsync(new GameActionRequest { Action = "start" }));
            await WaitUntilAsync(() => guest.CurrentState is { Started: true });
        }
        else
        {
            await WaitUntilAsync(() => host.CurrentState is { Started: true });
        }

        await host.LeaveGameAsync();
        await WaitUntilAsync(() => guest.CurrentState is { IsGameOver: true, IsForfeit: true });

        using var form = game switch
        {
            "Chess" => (Form)new ChessForm(guest),
            "Ludo" => new LudoForm(guest),
            _ => new TicTacToeForm(guest)
        };
        var status = game switch
        {
            "Chess" => GetField<Label>(form, "_status").Text,
            "Ludo" => GetField<Label>(form, "_statusLabel").Text,
            _ => GetField<Label>(form, "_statusLabel").Text
        };
        Assert.Contains("Host Player has left the game. You Won!", status);
    }

    [Fact]
    public async Task Unexpected_Host_Disconnect_Declares_Local_Player_Winner_In_Two_Player_Game()
    {
        var host = new MultiplayerSession();
        using var guest = new MultiplayerSession();
        host.StartHost("TicTacToe", GetAvailablePort(), "Host Player");
        await guest.JoinAsync("127.0.0.1", host.Port, host.RoomId, "TicTacToe", "Guest Player");
        await WaitUntilAsync(() => guest.CurrentState is { Started: true, Players.Count: 2 });

        host.Dispose();
        await WaitUntilAsync(() => guest.CurrentState is { IsGameOver: true, IsForfeit: true });

        Assert.Equal(guest.LocalPlayerId, guest.CurrentState!.WinnerId);
        Assert.Equal("Host Player", guest.CurrentState.LastDepartedPlayerName);
    }

    [Fact]
    public async Task Unexpected_Host_Disconnect_During_Carrom_Ends_Match_And_Notifies_Guest()
    {
        var host = new MultiplayerSession();
        using var guest = new MultiplayerSession();
        var departureStatus = new TaskCompletionSource<string>(TaskCreationOptions.RunContinuationsAsynchronously);
        guest.StatusChanged += message =>
        {
            if (message.Contains("has left", StringComparison.OrdinalIgnoreCase))
            {
                departureStatus.TrySetResult(message);
            }
        };
        host.StartHost("Carrom", GetAvailablePort(), "Host Player");
        await guest.JoinAsync("127.0.0.1", host.Port, host.RoomId, "Carrom", "Guest Player");
        await WaitUntilAsync(() => guest.CurrentState is { Started: true, Players.Count: 2 });

        host.Dispose();
        await WaitUntilAsync(() => guest.CurrentState is { IsGameOver: true, IsForfeit: true });
        var message = await departureStatus.Task.WaitAsync(TimeSpan.FromSeconds(3));

        Assert.Equal(guest.LocalPlayerId, guest.CurrentState!.WinnerId);
        Assert.Equal("Host Player", guest.CurrentState.LastDepartedPlayerName);
        Assert.True(guest.CurrentState.Players.Single(player => player.PlayerId == guest.LocalPlayerId).Connected);
        Assert.Contains("Host Player has left", message);
    }

    [Fact]
    public async Task Ludo_Four_Players_Can_Continue_After_Departures_And_Declare_Final_Forfeit_Winner()
    {
        var diceRolls = new Queue<int>(new[] { 6, 1, 6, 6 });
        int RollDice() => diceRolls.Count > 0 ? diceRolls.Dequeue() : 6;

        using var host = new MultiplayerSession(RollDice);
        using var blue = new MultiplayerSession();
        using var green = new MultiplayerSession();
        using var yellow = new MultiplayerSession();
        host.StartHost("Ludo", GetAvailablePort(), "Red Player");
        await blue.JoinAsync("127.0.0.1", host.Port, host.RoomId, "Ludo", "Blue Player");
        await green.JoinAsync("127.0.0.1", host.Port, host.RoomId, "Ludo", "Green Player");
        await yellow.JoinAsync("127.0.0.1", host.Port, host.RoomId, "Ludo", "Yellow Player");
        await WaitUntilAsync(() => host.CurrentState is { Players.Count: 4 }
            && yellow.CurrentState is { Players.Count: 4 });
        Assert.True(await host.SendActionAsync(new GameActionRequest { Action = "start" }));
        await WaitUntilAsync(() => yellow.CurrentState is { Started: true });

        await blue.LeaveGameAsync();
        await WaitUntilAsync(() => host.CurrentState?.DepartureSequence == 1
            && green.CurrentState?.DepartureSequence == 1
            && yellow.CurrentState?.DepartureSequence == 1);
        Assert.False(host.CurrentState!.IsGameOver);
        Assert.Equal(3, host.CurrentState.Players.Count(player => player.Connected));
        Assert.Contains(host.CurrentState.Players, player => player.Name == "Blue Player" && !player.Connected);
        var hostLudo = (WiFiGameHub.Games.Ludo.LudoGame)typeof(MultiplayerSession)
            .GetField("_ludo", BindingFlags.NonPublic | BindingFlags.Instance)!.GetValue(host)!;
        var departedLudoIndex = hostLudo.Players.FindIndex(player => player.Name == "Blue Player");
        Assert.True(departedLudoIndex >= 0, string.Join(" / ", hostLudo.Players.Select(player => $"{player.Color}:{player.Name}:{player.IsActive}")));
        Assert.False(hostLudo.Players[departedLudoIndex].IsActive,
            string.Join(" / ", hostLudo.Players.Select(player => $"{player.Color}:{player.Name}:{player.IsActive}")));

        Assert.True(await host.SendActionAsync(new GameActionRequest { Action = "ludo-roll" }));
        Assert.True(await host.SendActionAsync(new GameActionRequest { Action = "ludo-move", TokenIndex = 0 }));
        Assert.Equal(0, host.CurrentState!.CurrentLudoPlayerIndex);
        Assert.True(await host.SendActionAsync(new GameActionRequest { Action = "ludo-roll" }));
        Assert.Equal(1, host.CurrentState!.PendingDiceValue);
        Assert.True(await host.SendActionAsync(new GameActionRequest { Action = "ludo-move", TokenIndex = 0 }));
        Assert.True(host.CurrentState!.CurrentLudoPlayerIndex == 2, string.Join(" | ", host.CurrentState.MoveHistory));
        await WaitUntilAsync(() => host.CurrentState?.CurrentPlayerId == green.LocalPlayerId);
        await WaitUntilAsync(() => green.CurrentState?.CurrentPlayerId == green.LocalPlayerId);

        Assert.True(await green.SendActionAsync(new GameActionRequest { Action = "ludo-roll" }));
        Assert.True(await green.SendActionAsync(new GameActionRequest { Action = "ludo-move", TokenIndex = 0 }));
        await green.LeaveGameAsync();
        await WaitUntilAsync(() => host.CurrentState?.DepartureSequence == 2);
        await WaitUntilAsync(() => yellow.CurrentState?.CurrentPlayerId == yellow.LocalPlayerId);
        Assert.False(host.CurrentState!.IsGameOver);
        Assert.Equal(2, host.CurrentState.Players.Count(player => player.Connected));
        Assert.Equal(yellow.LocalPlayerId, host.CurrentState.CurrentPlayerId);

        Assert.True(await yellow.SendActionAsync(new GameActionRequest { Action = "ludo-roll" }));
        Assert.True(await yellow.SendActionAsync(new GameActionRequest { Action = "ludo-move", TokenIndex = 0 }));
        await yellow.LeaveGameAsync();
        await WaitUntilAsync(() => host.CurrentState is
            { IsGameOver: true, IsForfeit: true, WinnerId: var winnerId } && winnerId == host.LocalPlayerId);
        Assert.Equal(1, host.CurrentState!.Players.Count(player => player.Connected));
        Assert.Equal("Yellow Player", host.CurrentState.LastDepartedPlayerName);
        Assert.Equal(3, host.CurrentState.DepartureSequence);

        var markDeparted = typeof(MultiplayerSession).GetMethod("MarkPlayerDeparted", BindingFlags.NonPublic | BindingFlags.Instance)!;
        Assert.False((bool)markDeparted.Invoke(host, new object[] { yellow.LocalPlayerId })!);
        Assert.Equal(3, host.CurrentState.DepartureSequence);
    }

    private static async Task WaitUntilAsync(Func<bool> condition)
    {
        var timeout = DateTime.UtcNow + TimeSpan.FromSeconds(8);
        while (!condition())
        {
            if (DateTime.UtcNow >= timeout)
            {
                throw new TimeoutException("Timed out while waiting for the multiplayer session state.");
            }
            await Task.Delay(20);
        }
    }

    private static int GetAvailablePort()
    {
        using var listener = new TcpListener(IPAddress.Loopback, 0);
        listener.Start();
        return ((IPEndPoint)listener.LocalEndpoint).Port;
    }

    private static T GetField<T>(object instance, string name) =>
        (T)instance.GetType().GetField(name, BindingFlags.NonPublic | BindingFlags.Instance)!.GetValue(instance)!;
}
