using System.Net;
using System.Net.Sockets;
using System.Reflection;
using System.Windows.Forms;
using WiFiGameHub.Forms;
using WiFiGameHub.Networking;
using Xunit;

namespace WiFiGameHub.Tests;

public class RoomReadinessTests
{
    [Fact]
    public void Local_Chess_And_TicTacToe_Start_Without_Waiting_For_A_Room_Player()
    {
        using var chess = new ChessForm();
        using var ticTacToe = new TicTacToeForm();

        Assert.DoesNotContain("wait", GetField<Label>(chess, "_status").Text, StringComparison.OrdinalIgnoreCase);
        Assert.DoesNotContain("wait", GetField<Label>(ticTacToe, "_statusLabel").Text, StringComparison.OrdinalIgnoreCase);
        var cells = GetField<Array>(ticTacToe, "_cells");
        Assert.True(((Control)cells.GetValue(0, 0)!).Enabled);
    }

    [Fact]
    public void Local_Ludo_Can_Roll_Immediately_Without_Waiting_For_A_Room_Player()
    {
        using var ludo = new LudoForm();

        Assert.Equal("Roll the dice to begin.", GetField<Label>(ludo, "_statusLabel").Text);
        Assert.True(GetField<Button>(ludo, "_rollButton").Enabled);
    }

    [Fact]
    public void Room_Games_Wait_For_The_Second_Player()
    {
        using var chessSession = CreateHostSession("Chess");
        using var chess = new ChessForm(chessSession);
        Assert.Contains("Waiting for another player", GetField<Label>(chess, "_status").Text);

        using var ticTacToeSession = CreateHostSession("TicTacToe");
        using var ticTacToe = new TicTacToeForm(ticTacToeSession);
        Assert.Contains("Waiting for second player", GetField<Label>(ticTacToe, "_statusLabel").Text);

        using var ludoSession = CreateHostSession("Ludo");
        using var ludo = new LudoForm(ludoSession);
        Assert.Contains("Waiting for a second player", GetField<Label>(ludo, "_statusLabel").Text);
        Assert.False(GetField<Button>(ludo, "_rollButton").Enabled);
        Assert.False(GetField<Button>(ludo, "_startMatchButton").Enabled);
    }

    private static MultiplayerSession CreateHostSession(string game)
    {
        var session = new MultiplayerSession();
        session.StartHost(game, GetAvailablePort(), "Room Host");
        return session;
    }

    private static T GetField<T>(object instance, string name)
    {
        var field = instance.GetType().GetField(name, BindingFlags.NonPublic | BindingFlags.Instance);
        Assert.NotNull(field);
        return (T)field!.GetValue(instance)!;
    }

    private static int GetAvailablePort()
    {
        using var listener = new TcpListener(IPAddress.Loopback, 0);
        listener.Start();
        return ((IPEndPoint)listener.LocalEndpoint).Port;
    }
}
