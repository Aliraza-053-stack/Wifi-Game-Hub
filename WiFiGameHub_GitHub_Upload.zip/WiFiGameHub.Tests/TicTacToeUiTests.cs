using System.Drawing;
using System.Reflection;
using System.Windows.Forms;
using WiFiGameHub.Forms;
using WiFiGameHub.Games.TicTacToe;
using Xunit;

namespace WiFiGameHub.Tests;

public class TicTacToeUiTests
{
    [Fact]
    public void Local_Board_Tracks_Turns_And_Reports_An_Occupied_Cell()
    {
        using var form = new TicTacToeForm();
        var cells = GetField<Array>(form, "_cells");
        ClickCell(cells, 0, 0);

        Assert.Equal("Occupied by X", GetCell(cells, 0, 0).AccessibleDescription);
        Assert.Equal("O", GetField<TicTacToeGame>(form, "_game").CurrentPlayer);
        Assert.Contains("Player O to move", GetField<Label>(form, "_statusLabel").Text);

        ClickCell(cells, 0, 0);
        Assert.Equal("That cell is already occupied.", GetField<Label>(form, "_statusLabel").Text);
    }

    [Fact]
    public void Winning_Round_Highlights_The_Engine_Winning_Line_And_Updates_Score()
    {
        using var form = new TicTacToeForm();
        var cells = GetField<Array>(form, "_cells");
        ClickCell(cells, 0, 0);
        ClickCell(cells, 1, 0);
        ClickCell(cells, 0, 1);
        ClickCell(cells, 1, 1);
        ClickCell(cells, 0, 2);

        Assert.Contains("Player X wins", GetField<Label>(form, "_statusLabel").Text);
        Assert.Contains("X  1", GetField<Label>(form, "_scoreLabel").Text);
        Assert.True(IsWinningCell(GetCell(cells, 0, 0)));
        Assert.True(IsWinningCell(GetCell(cells, 0, 1)));
        Assert.True(IsWinningCell(GetCell(cells, 0, 2)));
        Assert.False(IsWinningCell(GetCell(cells, 1, 0)));
    }

    [Fact]
    public void Draw_Round_Shows_Draw_Without_Highlighting_A_Winning_Line()
    {
        using var form = new TicTacToeForm();
        var cells = GetField<Array>(form, "_cells");
        var moves = new (int Row, int Column)[]
        {
            (0, 0), (0, 1), (0, 2), (1, 1), (1, 0), (2, 0), (1, 2), (2, 2), (2, 1)
        };
        foreach (var (row, column) in moves)
        {
            ClickCell(cells, row, column);
        }

        Assert.Contains("Draw", GetField<Label>(form, "_statusLabel").Text);
        Assert.All(cells.Cast<Control>(), cell => Assert.False(IsWinningCell((Button)cell)));
    }

    [Theory]
    [InlineData(720, 520)]
    [InlineData(520, 720)]
    public void Board_Remains_Square_And_Centered_After_Resize(int width, int height)
    {
        using var form = new TicTacToeForm();
        var host = GetField<Panel>(form, "_boardHost");
        host.Size = new Size(width, height);
        var board = host.Controls[0];

        Assert.Equal(board.Width, board.Height);
        Assert.Equal((host.ClientSize.Width - board.Width) / 2, board.Left);
        Assert.Equal((host.ClientSize.Height - board.Height) / 2, board.Top);
    }

    [Fact]
    public void Exit_Button_Invokes_Return_Callback()
    {
        var exited = false;
        using var form = new TicTacToeForm(onExit: () => exited = true);
        var exit = GetField<Button>(form, "_exitButton");

        typeof(Button).GetMethod("OnClick", BindingFlags.NonPublic | BindingFlags.Instance)!
            .Invoke(exit, new object[] { EventArgs.Empty });

        Assert.True(exited);
    }

    private static void ClickCell(Array cells, int row, int column)
    {
        var cell = GetCell(cells, row, column);
        typeof(TicTacToeForm).GetMethod("Cell_Click", BindingFlags.NonPublic | BindingFlags.Instance)!
            .Invoke(cell.FindForm(), new object?[] { cell, EventArgs.Empty });
    }

    private static Button GetCell(Array cells, int row, int column) =>
        (Button)cells.GetValue(row, column)!;

    private static bool IsWinningCell(Button cell) =>
        (bool)cell.GetType().GetProperty("IsWinningCell")!.GetValue(cell)!;

    private static T GetField<T>(object instance, string name)
    {
        var field = instance.GetType().GetField(name, BindingFlags.NonPublic | BindingFlags.Instance);
        Assert.NotNull(field);
        return (T)field!.GetValue(instance)!;
    }
}
