using System.Drawing;
using System.Windows.Forms;
using WiFiGameHub.Forms;
using Xunit;

namespace WiFiGameHub.Tests;

public class DashboardLayoutTests
{
    [Fact]
    public void Dashboard_Presents_Premium_Status_Cards_And_Four_Game_Cards()
    {
        using var dashboard = new DashboardForm(_ => { });
        var root = Assert.IsType<TableLayoutPanel>(dashboard.Controls[0]);
        var gameCards = Assert.IsType<TableLayoutPanel>(root.GetControlFromPosition(0, 3));
        var statusCards = Assert.IsType<TableLayoutPanel>(root.GetControlFromPosition(0, 1));
        var footer = Assert.IsType<TableLayoutPanel>(root.GetControlFromPosition(0, 4));
        var welcome = Assert.IsAssignableFrom<Panel>(root.GetControlFromPosition(0, 0));
        var welcomeLayout = Assert.IsType<TableLayoutPanel>(welcome.Controls[0]);
        var welcomeTitle = FindControls<Label>(welcome).Single(label => label.Text == "Ready for your next match?");

        Assert.Equal(5, root.RowCount);
        Assert.Equal(4, gameCards.ColumnCount);
        Assert.Equal(4, gameCards.Controls.Count);
        Assert.Equal(4, statusCards.ColumnCount);
        Assert.Equal(SizeType.Percent, root.RowStyles[3].SizeType);
        Assert.Equal(SizeType.Absolute, root.RowStyles[4].SizeType);
        Assert.Equal(42F, welcomeLayout.RowStyles[1].Height);
        Assert.True(welcomeLayout.RowStyles[1].Height >= welcomeTitle.Font.Height);
        Assert.Equal(ContentAlignment.MiddleLeft, welcomeTitle.TextAlign);
        Assert.All(gameCards.Controls.OfType<Panel>(), card =>
        {
            var cardLayout = Assert.IsType<TableLayoutPanel>(card.Controls[0]);
            var preview = Assert.IsAssignableFrom<Control>(cardLayout.GetControlFromPosition(0, 2));
            Assert.Equal("GamePreviewControl", preview.GetType().Name);
            Assert.Equal(DockStyle.Fill, preview.Dock);
            Assert.Equal(SizeType.Percent, cardLayout.RowStyles[2].SizeType);
            Assert.Equal(SizeType.Absolute, cardLayout.RowStyles[3].SizeType);
        });
        Assert.Equal(
            new[] { "ChessPreview", "LudoPreview", "TicTacToePreview", "CarromPreview" },
            gameCards.Controls.OfType<Panel>()
                .Select(card => card.Controls.OfType<TableLayoutPanel>().Single().GetControlFromPosition(0, 2)!.Name));
        Assert.Contains(FindControls<Label>(dashboard), label => label.Text == "4 games");
        Assert.DoesNotContain(FindControls<Control>(dashboard), control =>
            control.Text.Contains("NEARBY WI-FI", StringComparison.OrdinalIgnoreCase)
            || control.Text == "Refresh");
        Assert.Contains(FindControls<Label>(footer), label =>
            label.Text == "Developer: Ali Raza  ·  Project Supervisor: Sir Muhammad Abdullah");
        Assert.Contains(FindControls<Button>(dashboard), button => button.Text == "Play with friends");
        Assert.All(gameCards.Controls.OfType<Panel>(), card =>
        {
            Assert.Contains(FindControls<Button>(card), button => button.Text.StartsWith("Play Now", StringComparison.Ordinal));
        });
    }

    [Fact]
    public void Game_Cards_Keep_Their_Mode_Selection_Navigation()
    {
        var destinations = new List<string>();
        using var dashboard = new DashboardForm(destinations.Add);

        foreach (var button in FindControls<Button>(dashboard).Where(button => button.Text.StartsWith("Play Now", StringComparison.Ordinal)))
        {
            typeof(Button).GetMethod("OnClick", System.Reflection.BindingFlags.NonPublic | System.Reflection.BindingFlags.Instance)!
                .Invoke(button, new object[] { EventArgs.Empty });
        }

        Assert.Equal(new[] { "Chess", "Ludo", "Tic Tac Toe", "Carrom" }, destinations);
    }

    private static IEnumerable<T> FindControls<T>(Control parent) where T : Control
    {
        foreach (Control child in parent.Controls)
        {
            if (child is T match)
            {
                yield return match;
            }

            foreach (var nested in FindControls<T>(child))
            {
                yield return nested;
            }
        }
    }
}
