using System.Reflection;
using System.Drawing;
using System.Windows.Forms;
using WiFiGameHub.Forms;
using WiFiGameHub.Games.Chess;
using Xunit;

namespace WiFiGameHub.Tests;

public class ChessFormUiTests
{
    [Fact]
    public void Local_Board_Selection_Shows_Legal_Moves_And_Updates_The_Turn()
    {
        using var form = new ChessForm();
        var board = GetField<ChessBoardControl>(form, "_board");
        var clickSquare = typeof(ChessForm).GetMethod("Board_SquareClicked", BindingFlags.NonPublic | BindingFlags.Instance)!;

        clickSquare.Invoke(form, new object[] { 6, 4 });

        Assert.Equal((6, 4), board.SelectedSquare);
        Assert.Equal(2, board.LegalTargets.Count);

        clickSquare.Invoke(form, new object[] { 4, 4 });

        Assert.Null(board.SelectedSquare);
        Assert.Empty(board.LegalTargets);
        Assert.Equal("YOUR TURN  ·  Black", GetField<Label>(form, "_status").Text);
        Assert.Equal(Color.FromArgb(37, 36, 61), GetField<Panel>(form, "_blackPlayerCard").BackColor);
    }

    [Fact]
    public void Exit_Control_Invokes_The_Provided_Return_Action()
    {
        var exited = false;
        using var form = new ChessForm(onExit: () => exited = true);
        var exitButton = GetField<Button>(form, "_exit");

        Click(exitButton);

        Assert.True(exited);
    }

    [Fact]
    public void Stalemate_Uses_A_Specific_Draw_Notification()
    {
        using var form = new ChessForm();
        GetField<ChessGame>(form, "_game").LoadFen("7k/5Q2/6K1/8/8/8/8/8 b - - 0 1");
        typeof(ChessForm).GetMethod("RefreshGame", BindingFlags.NonPublic | BindingFlags.Instance)!
            .Invoke(form, new object[] { true });

        Assert.Equal("STALEMATE  ·  Draw", GetField<Label>(form, "_status").Text);
    }

    private static T GetField<T>(object instance, string name)
    {
        var field = instance.GetType().GetField(name, BindingFlags.NonPublic | BindingFlags.Instance);
        Assert.NotNull(field);
        return (T)field!.GetValue(instance)!;
    }

    private static void Click(Button button) =>
        typeof(Button).GetMethod("OnClick", BindingFlags.NonPublic | BindingFlags.Instance)!
            .Invoke(button, new object[] { EventArgs.Empty });
}
