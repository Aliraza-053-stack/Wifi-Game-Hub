using System.Net;
using System.Net.Sockets;
using System.Reflection;
using System.Text;
using System.Text.Json;
using System.Windows.Forms;
using WiFiGameHub.Forms;
using WiFiGameHub.Networking;
using Xunit;

namespace WiFiGameHub.Tests;

public class NetworkingTests
{
    [Fact]
    public void TicTacToe_Form_Ignores_Active_Ludo_Snapshot()
    {
        using var session = new MultiplayerSession();
        session.StartHost("Ludo", GetAvailablePort(), "Host");

        using var form = new TicTacToeForm(session);

        Assert.NotNull(form);
        Assert.Equal("Ludo", session.CurrentState!.Game);
    }

    [Fact]
    public async Task Room_Chat_Is_Relayed_With_Authenticated_Player_Name()
    {
        using var host = new MultiplayerSession();
        using var client = new MultiplayerSession();
        var hostChat = new TaskCompletionSource<GameChatEntry>(TaskCreationOptions.RunContinuationsAsynchronously);
        var clientChat = new TaskCompletionSource<GameChatEntry>(TaskCreationOptions.RunContinuationsAsynchronously);
        host.ChatReceived += entry => hostChat.TrySetResult(entry);
        client.ChatReceived += entry => clientChat.TrySetResult(entry);
        var port = GetAvailablePort();
        host.StartHost("TicTacToe", port, "Room Host");
        await client.JoinAsync("127.0.0.1", port, host.RoomId, "TicTacToe", "Guest Player");
        await WaitUntilAsync(() => client.LocalPlayerId.Length > 0);

        Assert.True(await client.SendChatAsync("Hello from the other player"));
        var hostEntry = await hostChat.Task.WaitAsync(TimeSpan.FromSeconds(3));
        var clientEntry = await clientChat.Task.WaitAsync(TimeSpan.FromSeconds(3));
        Assert.Equal("Guest Player", hostEntry.SenderName);
        Assert.Equal("Guest Player", clientEntry.SenderName);
        Assert.Equal("Hello from the other player", clientEntry.Text);
        Assert.Equal(host.RoomId, clientEntry.RoomId);
    }

    [Fact]
    public async Task Chat_Only_Room_Allows_Chat_Without_Starting_A_Game()
    {
        using var host = new MultiplayerSession();
        using var client = new MultiplayerSession();
        var hostChat = new TaskCompletionSource<GameChatEntry>(TaskCreationOptions.RunContinuationsAsynchronously);
        var clientChat = new TaskCompletionSource<GameChatEntry>(TaskCreationOptions.RunContinuationsAsynchronously);
        host.ChatReceived += entry => hostChat.TrySetResult(entry);
        client.ChatReceived += entry => clientChat.TrySetResult(entry);
        var port = GetAvailablePort();

        host.StartHost("Chat", port, "Chat Host");
        Assert.False(host.CurrentState!.Started);
        Assert.NotNull(LanDiscovery.ParseAnnouncement(JsonSerializer.Serialize(new LanRoomAnnouncement
        {
            RoomId = host.RoomId,
            RoomName = "Chat Only",
            Game = "Chat",
            HostName = "Chat Host",
            HostIp = "127.0.0.1",
            Port = port,
            CurrentPlayers = 1,
            MaxPlayers = 2
        })));
        await client.JoinAsync("127.0.0.1", port, host.RoomId, "Chat", "Chat Guest");
        await WaitUntilAsync(() => client.LocalPlayerId.Length > 0);

        Assert.False(await host.SendActionAsync(new GameActionRequest { Action = "tic-move", Row = 0, Column = 0 }));
        Assert.True(await client.SendChatAsync("Hello without starting a game"));
        var hostEntry = await hostChat.Task.WaitAsync(TimeSpan.FromSeconds(3));
        var clientEntry = await clientChat.Task.WaitAsync(TimeSpan.FromSeconds(3));
        Assert.Equal("Chat Guest", hostEntry.SenderName);
        Assert.Equal("Hello without starting a game", clientEntry.Text);
    }

    [Fact]
    public async Task Lobby_Can_Join_A_Room_Using_Host_Address_And_Copied_Room_Id()
    {
        using var host = new MultiplayerSession();
        using var client = new MultiplayerSession();
        var port = GetAvailablePort();
        host.StartHost("Chess", port, "Room Host");
        using var lobby = new MultiplayerForm(client);
        lobby.SelectGame("Chess");
        GetLobbyField<TextBox>(lobby, "_hostAddressText").Text = "127.0.0.1";
        GetLobbyField<TextBox>(lobby, "_portText").Text = port.ToString();
        GetLobbyField<TextBox>(lobby, "_roomIdText").Text = host.RoomId;
        GetLobbyField<TextBox>(lobby, "_playerName").Text = "Room Guest";

        var joinMethod = typeof(MultiplayerForm).GetMethod("JoinByIdAsync", BindingFlags.NonPublic | BindingFlags.Instance);
        Assert.NotNull(joinMethod);
        await (Task)joinMethod!.Invoke(lobby, null)!;
        await WaitUntilAsync(() => host.CurrentState?.Started == true
            && client.CurrentState?.Started == true
            && client.LocalPlayerId.Length > 0);

        Assert.True(client.IsActive);
        Assert.Equal(host.RoomId, client.RoomId);
        Assert.Equal("Chess", client.Game);
        Assert.True(host.CurrentState!.Started);
        Assert.Equal($"Room ID  {host.RoomId}", GetLobbyField<Label>(lobby, "_roomIdLabel").Text);
    }

    [Fact]
    public async Task Chess_Room_Synchronizes_Alternate_Turns_And_Room_Chat()
    {
        using var host = new MultiplayerSession();
        using var client = new MultiplayerSession();
        var hostChat = new TaskCompletionSource<GameChatEntry>(TaskCreationOptions.RunContinuationsAsynchronously);
        var clientChat = new TaskCompletionSource<GameChatEntry>(TaskCreationOptions.RunContinuationsAsynchronously);
        host.ChatReceived += entry => hostChat.TrySetResult(entry);
        client.ChatReceived += entry => clientChat.TrySetResult(entry);
        var port = GetAvailablePort();

        host.StartHost("Chess", port, "White Player");
        Assert.NotNull(LanDiscovery.ParseAnnouncement(JsonSerializer.Serialize(new LanRoomAnnouncement
        {
            RoomId = host.RoomId,
            RoomName = "Chess Room",
            Game = "Chess",
            HostName = "White Player",
            HostIp = "127.0.0.1",
            Port = port,
            CurrentPlayers = 1,
            MaxPlayers = 2
        })));
        await client.JoinAsync("127.0.0.1", port, host.RoomId, "Chess", "Black Player");
        await WaitUntilAsync(() => host.CurrentState?.Started == true
            && client.CurrentState?.Started == true
            && client.LocalPlayerId.Length > 0);

        Assert.Equal("White", host.CurrentState!.Players.Single(player => player.PlayerId == host.LocalPlayerId).Mark);
        Assert.Equal("Black", client.CurrentState!.Players.Single(player => player.PlayerId == client.LocalPlayerId).Mark);
        Assert.True(await host.SendActionAsync(new GameActionRequest
        {
            Action = "chess-move",
            FromRow = 6,
            FromColumn = 4,
            Row = 4,
            Column = 4
        }));
        await WaitUntilAsync(() => client.CurrentState?.ChessFen.Contains(" b ", StringComparison.Ordinal) == true);
        Assert.Equal(host.CurrentState!.ChessFen, client.CurrentState!.ChessFen);
        Assert.Equal(client.LocalPlayerId, client.CurrentState.CurrentPlayerId);
        Assert.False(await host.SendActionAsync(new GameActionRequest
        {
            Action = "chess-move",
            FromRow = 7,
            FromColumn = 6,
            Row = 5,
            Column = 5
        }));
        Assert.True(await client.SendActionAsync(new GameActionRequest
        {
            Action = "chess-move",
            FromRow = 1,
            FromColumn = 4,
            Row = 3,
            Column = 4
        }));
        await WaitUntilAsync(() => host.CurrentState?.ChessFen.Contains(" w ", StringComparison.Ordinal) == true
            && client.CurrentState?.ChessFen == host.CurrentState?.ChessFen);
        Assert.Equal(host.CurrentState!.ChessFen, client.CurrentState!.ChessFen);

        Assert.True(await client.SendChatAsync("Good opening"));
        var receivedAtHost = await hostChat.Task.WaitAsync(TimeSpan.FromSeconds(3));
        var receivedAtClient = await clientChat.Task.WaitAsync(TimeSpan.FromSeconds(3));
        Assert.Equal("Black Player", receivedAtHost.SenderName);
        Assert.Equal("Good opening", receivedAtClient.Text);
    }

    [Fact]
    public async Task Carrom_Room_Validates_Active_Player_And_Synchronizes_Host_Resolved_Shot()
    {
        using var host = new MultiplayerSession();
        using var guest = new MultiplayerSession();
        host.StartHost("Carrom", GetAvailablePort(), "White Player");
        await guest.JoinAsync("127.0.0.1", host.Port, host.RoomId, "Carrom", "Black Player");
        await WaitUntilAsync(() => host.CurrentState is { Started: true, Players.Count: 2 }
            && guest.CurrentState is { Started: true, Players.Count: 2 });

        Assert.Equal("White", host.CurrentState!.Players.Single(player => player.PlayerId == host.LocalPlayerId).Mark);
        Assert.Equal("Black", guest.CurrentState!.Players.Single(player => player.PlayerId == guest.LocalPlayerId).Mark);
        Assert.Equal(20, host.CurrentState.CarromPieces.Length);
        Assert.Equal(host.CurrentState.CarromPieces, guest.CurrentState.CarromPieces);
        Assert.Equal(host.LocalPlayerId, host.CurrentState.CurrentPlayerId);

        var rejection = new TaskCompletionSource<string>(TaskCreationOptions.RunContinuationsAsynchronously);
        guest.StatusChanged += message =>
        {
            if (message.Contains("Illegal action", StringComparison.OrdinalIgnoreCase))
            {
                rejection.TrySetResult(message);
            }
        };
        var revisionBeforeIllegalAction = host.CurrentState.Revision;
        Assert.True(await guest.SendActionAsync(CreateCarromShot(500F, 500F, 790F, 100F)));
        await rejection.Task.WaitAsync(TimeSpan.FromSeconds(5));
        Assert.Equal(revisionBeforeIllegalAction, host.CurrentState.Revision);

        var hostShot = CreateCarromShot(500F, 500F, 790F, 100F);
        Assert.True(await host.SendActionAsync(hostShot));
        await WaitUntilAsync(() => guest.CurrentState!.Revision == host.CurrentState!.Revision
            && guest.CurrentState.CarromShotNumber == 1);
        Assert.Equal(host.CurrentState!.CarromPieces, guest.CurrentState!.CarromPieces);
        Assert.Equal(guest.LocalPlayerId, guest.CurrentState.CurrentPlayerId);
        Assert.Equal(1, guest.CurrentState.CarromShotNumber);
        Assert.Equal(hostShot.ActionId, guest.CurrentState.CarromLastShotActionId);
        Assert.Equal(host.LocalPlayerId, guest.CurrentState.CarromLastShotPlayerId);
        Assert.Equal(host.CurrentState.CarromWhiteTotalPocketedCoins, guest.CurrentState.CarromWhiteTotalPocketedCoins);
        Assert.Equal(host.CurrentState.CarromWhiteQueenBonus, guest.CurrentState.CarromWhiteQueenBonus);
        Assert.Equal(host.CurrentState.CarromMatchDurationSeconds, guest.CurrentState.CarromMatchDurationSeconds);

        var revisionAfterShot = host.CurrentState.Revision;
        Assert.False(await host.SendActionAsync(hostShot));
        Assert.Equal(revisionAfterShot, host.CurrentState.Revision);
    }

    [Fact]
    public async Task Carrom_Network_Action_Rejects_Out_Of_Range_Striker_Position()
    {
        using var host = new MultiplayerSession();
        using var guest = new MultiplayerSession();
        host.StartHost("Carrom", GetAvailablePort(), "White Player");
        await guest.JoinAsync("127.0.0.1", host.Port, host.RoomId, "Carrom", "Black Player");
        await WaitUntilAsync(() => guest.CurrentState is { Started: true });

        Assert.False(await host.SendActionAsync(CreateCarromShot(900F, 900F, 790F, 100F)));
        Assert.Equal(0, host.CurrentState!.CarromShotNumber);
    }

    private static GameActionRequest CreateCarromShot(float strikerX, float pullX, float pullY, float power) => new()
    {
        Action = "carrom-shot",
        CarromStrikerX = strikerX,
        CarromAimX = pullX,
        CarromAimY = pullY,
        CarromPower = power
    };

    [Fact]
    public async Task Room_Image_Is_Relayed_And_Assembled_At_Host()
    {
        using var host = new MultiplayerSession();
        using var client = new MultiplayerSession();
        var hostImage = new TaskCompletionSource<SharedGameImage>(TaskCreationOptions.RunContinuationsAsynchronously);
        host.ImageReceived += image => hostImage.TrySetResult(image);
        var port = GetAvailablePort();
        host.StartHost("Ludo", port, "Room Host");
        await client.JoinAsync("127.0.0.1", port, host.RoomId, "Ludo", "Guest Player");
        await WaitUntilAsync(() => client.LocalPlayerId.Length > 0);

        var pictureBytes = Enumerable.Range(0, 80_000).Select(index => (byte)(index % 239)).ToArray();
        Assert.True(await client.SendImageAsync("shared.png", "image/png", pictureBytes));

        var received = await hostImage.Task.WaitAsync(TimeSpan.FromSeconds(5));
        Assert.Equal("Guest Player", received.SenderName);
        Assert.Equal("shared.png", received.FileName);
        Assert.Equal(pictureBytes, received.Bytes);
    }

    [Fact]
    public void Image_Chunks_Reassemble_Within_Size_Limit()
    {
        var bytes = Enumerable.Range(0, 100_000).Select(index => (byte)(index % 251)).ToArray();
        var chunks = GameImageAssembler.CreateChunks("board.png", "image/png", bytes).ToArray();
        var assembler = new GameImageAssembler();
        SharedGameImage? completed = null;

        foreach (var chunk in chunks.Reverse())
        {
            Assert.True(assembler.TryAddChunk(chunk, "Guest", out var result));
            completed ??= result;
        }

        Assert.NotNull(completed);
        Assert.Equal(bytes, completed!.Bytes);
        Assert.Equal("board.png", completed.FileName);
        Assert.Throws<ArgumentOutOfRangeException>(() => GameImageAssembler.CreateChunks(
            "too-large.png", "image/png", new byte[GameImageAssembler.ImageByteLimit + 1]).ToArray());
    }

    [Fact]
    public async Task Tcp_Server_Receives_Validated_Json_Message_From_Client()
    {
        var port = GetAvailablePort();
        var received = new TaskCompletionSource<NetworkMessage>(TaskCreationOptions.RunContinuationsAsynchronously);
        using var server = new GameServer(port);
        server.MessageReceived += (_, message) => received.TrySetResult(message);
        server.Start();

        using var client = new GameClient();
        await client.ConnectAsync("127.0.0.1", port);
        await client.SendMessageAsync(new NetworkMessage
        {
            SenderId = "test-player",
            PlayerName = "Test Player",
            Type = NetworkMessageType.JoinRequest,
            RoomId = "room-1",
            Payload = "TicTacToe"
        });

        var message = await received.Task.WaitAsync(TimeSpan.FromSeconds(5));

        Assert.Equal(NetworkMessageType.JoinRequest, message.Type);
        Assert.Equal("test-player", message.SenderId);
        Assert.Equal("Test Player", message.PlayerName);
        Assert.Equal("room-1", message.RoomId);
    }

    [Fact]
    public async Task TicTacToe_Authoritative_Host_Synchronizes_Moves_And_Rejects_Wrong_Turn()
    {
        var host = new MultiplayerSession();
        using var first = new MultiplayerSession();
        var port = GetAvailablePort();
        host.StartHost("TicTacToe", port, "Host");
        var announcement = LanDiscovery.ParseAnnouncement(JsonSerializer.Serialize(new LanRoomAnnouncement
        {
            RoomId = host.RoomId,
            RoomName = "Tic Tac Toe Room",
            Game = "TicTacToe",
            HostName = "Host",
            HostIp = "127.0.0.1",
            Port = port,
            CurrentPlayers = 1,
            MaxPlayers = 2
        }));
        Assert.NotNull(announcement);
        await first.JoinAsync(announcement!.HostIp, announcement.Port, announcement.RoomId, announcement.Game, "Guest");
        await WaitUntilAsync(() => first.LocalPlayerId.Length > 0 && host.CurrentState?.Started == true);
        Assert.Equal("X", host.CurrentState!.Players.Single(player => player.PlayerId == host.LocalPlayerId).Mark);
        Assert.Equal("O", host.CurrentState.Players.Single(player => player.PlayerId == first.LocalPlayerId).Mark);
        Assert.NotEqual(host.LocalPlayerId, first.LocalPlayerId);
        Assert.Equal(host.LocalPlayerId, host.CurrentState.CurrentPlayerId);

        Assert.True(await host.SendActionAsync(new GameActionRequest { Action = "tic-move", Row = 0, Column = 0 }));
        await WaitUntilAsync(() => first.CurrentState?.TicTacToeBoard[0] == Games.TicTacToe.TicTacToeMark.X);
        Assert.Equal(host.CurrentState!.Revision, first.CurrentState!.Revision);
        Assert.Equal(first.LocalPlayerId, first.CurrentState.CurrentPlayerId);

        var illegalMove = new TaskCompletionSource<string>(TaskCreationOptions.RunContinuationsAsynchronously);
        first.StatusChanged += message =>
        {
            if (message.Contains("Illegal action", StringComparison.OrdinalIgnoreCase))
            {
                illegalMove.TrySetResult(message);
            }
        };
        var revisionBeforeIllegalMove = host.CurrentState.Revision;
        Assert.True(await first.SendActionAsync(new GameActionRequest { Action = "tic-move", Row = 0, Column = 0 }));
        await illegalMove.Task.WaitAsync(TimeSpan.FromSeconds(5));
        Assert.Equal(revisionBeforeIllegalMove, host.CurrentState!.Revision);

        Assert.True(await first.SendActionAsync(new GameActionRequest { Action = "tic-move", Row = 1, Column = 1 }));
        await WaitUntilAsync(() => host.CurrentState!.TicTacToeBoard[4] == Games.TicTacToe.TicTacToeMark.O);
        await WaitUntilAsync(() => first.CurrentState?.Revision == host.CurrentState?.Revision);
        Assert.Equal(host.LocalPlayerId, first.CurrentState!.CurrentPlayerId);
        var revisionAfterLegalMove = host.CurrentState.Revision;
        var rejection = new TaskCompletionSource<string>(TaskCreationOptions.RunContinuationsAsynchronously);
        first.StatusChanged += message =>
        {
            if (message.Contains("Illegal action", StringComparison.OrdinalIgnoreCase))
            {
                rejection.TrySetResult(message);
            }
        };
        Assert.True(await first.SendActionAsync(new GameActionRequest { Action = "tic-move", Row = 1, Column = 2 }));
        await rejection.Task.WaitAsync(TimeSpan.FromSeconds(5));
        Assert.Equal(revisionAfterLegalMove, host.CurrentState!.Revision);

        Assert.True(await host.SendActionAsync(new GameActionRequest { Action = "tic-move", Row = 0, Column = 1 }));
        await WaitUntilAsync(() => first.CurrentState!.CurrentPlayerMark == "O");
        Assert.True(await first.SendActionAsync(new GameActionRequest { Action = "tic-move", Row = 1, Column = 2 }));
        await WaitUntilAsync(() => host.CurrentState!.CurrentPlayerMark == "X");
        Assert.True(await host.SendActionAsync(new GameActionRequest { Action = "tic-move", Row = 0, Column = 2 }));
        await WaitUntilAsync(() => first.CurrentState!.IsGameOver && first.CurrentState.XScore == 1);
        Assert.Equal(host.CurrentState!.TicTacToeBoard, first.CurrentState.TicTacToeBoard);
        Assert.Equal(host.CurrentState.XScore, first.CurrentState.XScore);

        Assert.True(await first.SendActionAsync(new GameActionRequest { Action = "restart" }));
        await WaitUntilAsync(() => first.CurrentState!.TicTacToeBoard.All(mark => mark == Games.TicTacToe.TicTacToeMark.Empty));
        Assert.Equal(1, first.CurrentState!.XScore);
        await WaitUntilAsync(() => host.CurrentState!.TicTacToeBoard.All(mark => mark == Games.TicTacToe.TicTacToeMark.Empty));
        Assert.True(await first.SendActionAsync(new GameActionRequest { Action = "new-match" }));
        await WaitUntilAsync(() => first.CurrentState!.XScore == 0 && first.CurrentState.OScore == 0);
        await WaitUntilAsync(() => host.CurrentState!.XScore == 0 && host.CurrentState.OScore == 0);

        host.Dispose();
    }

    [Fact]
    public async Task Ludo_Host_Dice_And_Token_State_Synchronize_To_Client()
    {
        var host = new MultiplayerSession(() => 6);
        using var client = new MultiplayerSession();
        using var secondClient = new MultiplayerSession();
        var port = GetAvailablePort();
        host.StartHost("Ludo", port, "Host");
        await client.JoinAsync("127.0.0.1", port, host.RoomId, "Ludo", "Guest");
        await WaitUntilAsync(() => host.CurrentState?.Players.Count == 2 && client.LocalPlayerId.Length > 0);
        await secondClient.JoinAsync("127.0.0.1", port, host.RoomId, "Ludo", "Guest Two");
        await WaitUntilAsync(() => host.CurrentState?.Players.Count == 3 && secondClient.LocalPlayerId.Length > 0);
        Assert.NotEqual(client.LocalPlayerId, secondClient.LocalPlayerId);

        Assert.True(await host.SendActionAsync(new GameActionRequest { Action = "start" }));
        await WaitUntilAsync(() => client.CurrentState?.Started == true && secondClient.CurrentState?.Started == true);
        Assert.True(await host.SendActionAsync(new GameActionRequest { Action = "ludo-roll" }));
        await WaitUntilAsync(() => client.CurrentState?.DiceValue == 6 && secondClient.CurrentState?.DiceValue == 6);
        Assert.Equal(6, client.CurrentState!.PendingDiceValue);

        var rejection = new TaskCompletionSource<string>(TaskCreationOptions.RunContinuationsAsynchronously);
        client.StatusChanged += message =>
        {
            if (message.Contains("Illegal action", StringComparison.OrdinalIgnoreCase))
            {
                rejection.TrySetResult(message);
            }
        };
        Assert.True(await client.SendActionAsync(new GameActionRequest { Action = "ludo-move", TokenIndex = 0 }));
        await rejection.Task.WaitAsync(TimeSpan.FromSeconds(5));
        Assert.True(await host.SendActionAsync(new GameActionRequest { Action = "ludo-move", TokenIndex = 0 }));
        await WaitUntilAsync(() => client.CurrentState!.LudoTokenPositions[0] == 0);
        await WaitUntilAsync(() => secondClient.CurrentState!.LudoTokenPositions[0] == 0);
        Assert.Equal(host.CurrentState!.Revision, client.CurrentState.Revision);
        Assert.Equal(host.CurrentState.LudoTokenPositions, client.CurrentState.LudoTokenPositions);
        Assert.Equal(host.CurrentState.LudoTokenPositions, secondClient.CurrentState!.LudoTokenPositions);

        host.Dispose();
    }

    [Fact]
    public async Task Disconnected_Player_Is_Marked_Disconnected_In_Host_State()
    {
        using var host = new MultiplayerSession();
        var client = new MultiplayerSession();
        var port = GetAvailablePort();
        host.StartHost("TicTacToe", port, "Host");
        await client.JoinAsync("127.0.0.1", port, host.RoomId, "TicTacToe", "Guest");
        await WaitUntilAsync(() => host.CurrentState?.Players.Count == 2 && client.LocalPlayerId.Length > 0);

        var guestId = client.LocalPlayerId;
        client.Dispose();
        await WaitUntilAsync(() => host.CurrentState?.Players.Any(player => player.PlayerId == guestId && !player.Connected) == true);

        Assert.Equal(2, host.CurrentState!.Players.Count);
    }

    [Fact]
    public void Invalid_Json_Message_Is_Rejected()
    {
        Assert.Throws<System.Text.Json.JsonException>(() => NetworkMessage.FromJson("not-json"));
    }

    [Fact]
    public async Task Tcp_Server_Rejects_Connections_Above_Room_Capacity()
    {
        var port = GetAvailablePort();
        using var server = new GameServer(port, maximumClients: 1);
        server.Start();
        using var first = new TcpClient();
        using var second = new TcpClient();
        await first.ConnectAsync("127.0.0.1", port);
        await WaitUntilAsync(() => server.ConnectedClientCount == 1);
        await second.ConnectAsync("127.0.0.1", port);
        await WaitUntilAsync(() => !second.Connected || server.ConnectedClientCount == 1);

        Assert.Equal(1, server.ConnectedClientCount);
    }

    [Fact]
    public void Lan_Discovery_Parses_Only_Valid_Room_Announcements()
    {
        var json = JsonSerializer.Serialize(new LanRoomAnnouncement
        {
            RoomId = "room-1",
            RoomName = "Ludo Room",
            Game = "Ludo",
            HostName = "Host",
            HostIp = "192.168.1.25",
            Port = 45456,
            CurrentPlayers = 1,
            MaxPlayers = 4
        });

        var room = LanDiscovery.ParseAnnouncement(json);

        Assert.NotNull(room);
        Assert.Equal("192.168.1.25", room.HostIp);
        Assert.Null(LanDiscovery.ParseAnnouncement("not-json"));
        Assert.Null(LanDiscovery.ParseAnnouncement("{}"));
    }

    [Fact]
    public void Room_Directory_Deduplicates_Announcements_And_Expires_Silent_Hosts()
    {
        var directory = new LanRoomDirectory();
        var firstSeen = DateTime.UtcNow;
        var room = new LanRoomAnnouncement
        {
            RoomId = "room-1",
            RoomName = "Ludo Room",
            Game = "Ludo",
            HostName = "Host One",
            HostIp = "192.168.1.20",
            Port = 45456,
            CurrentPlayers = 1,
            MaxPlayers = 4
        };

        directory.Upsert(room, firstSeen);
        directory.Upsert(new LanRoomAnnouncement
        {
            RoomId = room.RoomId,
            RoomName = room.RoomName,
            Game = room.Game,
            HostName = "Host One Updated",
            HostIp = room.HostIp,
            Port = room.Port,
            CurrentPlayers = 2,
            MaxPlayers = room.MaxPlayers
        }, firstSeen.AddSeconds(2));

        Assert.Equal(1, directory.Count);
        Assert.Equal("Host One Updated", Assert.Single(directory.RemoveExpired(firstSeen.AddSeconds(5))).HostName);
        Assert.Empty(directory.RemoveExpired(firstSeen.AddSeconds(9)));
    }

    [Fact]
    public async Task Udp_Discovery_Receives_Room_From_Local_Test_Client()
    {
        int port;
        using (var portProbe = new UdpClient(0))
        {
            port = ((IPEndPoint)portProbe.Client.LocalEndPoint!).Port;
        }
        var discovered = new TaskCompletionSource<LanRoomAnnouncement>(TaskCreationOptions.RunContinuationsAsynchronously);
        using var discovery = new LanDiscovery(port);
        discovery.RoomDiscovered += room => discovered.TrySetResult(room);
        discovery.StartListening();

        var announcement = new LanRoomAnnouncement
        {
            RoomId = "udp-room",
            RoomName = "Local Test Room",
            Game = "TicTacToe",
            HostName = "Test Host",
            HostIp = "127.0.0.1",
            Port = 45456,
            CurrentPlayers = 1,
            MaxPlayers = 2,
            Status = "Waiting"
        };
        using var sender = new UdpClient();
        var payload = Encoding.UTF8.GetBytes(JsonSerializer.Serialize(announcement));
        await sender.SendAsync(payload, new IPEndPoint(IPAddress.Loopback, port));

        var result = await discovered.Task.WaitAsync(TimeSpan.FromSeconds(3));
        Assert.Equal(announcement.RoomId, result.RoomId);
        Assert.Equal("Test Host", result.HostName);
    }

    private static int GetAvailablePort()
    {
        using var listener = new TcpListener(IPAddress.Loopback, 0);
        listener.Start();
        return ((IPEndPoint)listener.LocalEndpoint).Port;
    }

    private static T GetLobbyField<T>(MultiplayerForm lobby, string name)
    {
        var field = typeof(MultiplayerForm).GetField(name, BindingFlags.NonPublic | BindingFlags.Instance);
        Assert.NotNull(field);
        return (T)field!.GetValue(lobby)!;
    }

    private static async Task WaitUntilAsync(Func<bool> condition)
    {
        var timeout = DateTime.UtcNow.AddSeconds(3);
        while (!condition() && DateTime.UtcNow < timeout)
        {
            await Task.Delay(20);
        }
    }
}