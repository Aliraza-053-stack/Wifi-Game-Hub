# WiFi Game Hub Project Report

## Introduction
WiFi Game Hub is a C# .NET 8 Windows Forms desktop application for local board-game play, Windows Wi-Fi inspection, and LAN room discovery and connection. Its dark navy, purple, and blue dashboard presents game shortcuts, room/player status, and a compact project footer. Navigation includes Dashboard, Games, Multiplayer Rooms, Chat, Network Center, Chess, Ludo Arena, Tic Tac Toe, Carrom, settings, and project information.

## Problem Statement
Local players need a simple desktop place to inspect their wireless environment, start a board game, and establish a room connection over a local network. The application brings those tasks into one Windows application. The network lobby connects players and enforces room capacity; an authoritative host validates game actions and broadcasts versioned state snapshots to connected clients.

## Objectives
- Provide consistent navigation and responsive page layouts.
- Display nearby Wi-Fi networks and current connection details from Windows.
- Implement playable local Chess, Ludo, and Tic Tac Toe.
- Provide local two-player Carrom rules, scoring, Queen cover, foul handling, match completion, and host-authoritative LAN play.
- Support LAN room hosting, UDP discovery, manual IP joining, TCP join approval, and host-authoritative game synchronization.
- Validate game rules, Wi-Fi parsing, navigation, and the local network protocol with automated tests.

## Technologies
- C# and .NET 8
- Windows Forms
- TCP sockets with newline-delimited JSON messages
- UDP broadcast for local room discovery
- `System.Text.Json`
- Windows `netsh wlan` commands
- xUnit

## Architecture
The project is separated into `Forms`, `Games`, `Models`, `Networking`, and `Services`. Forms present the interface and call the game or network layer. Game rules are implemented independently from the WinForms controls. Wi-Fi scanning parses Windows command output in a service. TCP and UDP code handles room transport and discovery.

## Main Components
- `MainForm`: themed app shell, active sidebar navigation, and page hosting.
- `DashboardForm`: gradient welcome panel, aligned game cards, local/room entry points, live multiplayer and LAN discovery status, and a compact developer-credit footer. Wi-Fi scanning remains in Network Center to keep the dashboard focused.
- `GameModeForm`: responsive, themed Local Play and Play in Room cards, selected-game branding, and a return path to the dashboard for Chess, Ludo, Tic-Tac-Toe, and Carrom.
- `WifiForm`: connected SSID and nearby SSID, signal, security, and connection status.
- `MultiplayerForm`: themed LAN room creation and discovery, room-code joining/copying, live host/player roster, host-only game launch when at least two connected participants are present, leave/close controls, and a Players/Chat lobby tab. The guest can open a game only after the session reports it started. No Ready/Not Ready flag is shown because the current session model does not provide player-readiness state.
- `ChessForm` and `ChessBoardControl`: themed chessboard with sculpted pieces, selected/legal-move highlights, turn and player panels, move history, check/checkmate/stalemate/draw status, restart and exit controls, local chat, and LAN chat.
- `LudoForm`, `LudoBoard`, and `LudoDiceControl`: themed 15-by-15 board with four player colors, sculpted tokens, engine-derived legal-move highlights, responsive board-aligned hit testing, animated dice with a numeric result, player/token status, move history, and local or LAN match controls.
- `TicTacToeForm` and `TicTacToeCellButton`: responsive, centered 3-by-3 board with the dark purple/blue theme, animated X/O marks, hover and winning-cell states, active-player cards, actual match score, clear win/draw feedback, restart/new-match controls, and return navigation.
- `CarromForm` and `CarromBoardControl`: responsive neon/wood board, live physics rendering, striker placement and pull-back shots, score/foul/Queen panels, match results, reset, and return navigation.
- `CarromPhysicsEngine` and `CarromRulesEngine`: fixed-timestep motion/collisions/pocket detection separated from turn, Queen-cover, foul, board-scoring, and match rules.
- `AppPreferences`: local settings persistence.
- `WifiScanner`: parsing and bounded execution of Windows wireless commands.
- `GameChatPanel`: shared dark-themed local/LAN chat with sender/time labels, distinct local/remote message styling, scrollable history, an empty state, and connection feedback.
- `GameServer`, `GameClient`, `LanDiscovery`, and `NetworkMessage`: TCP, UDP, and validated JSON room communication.

## Ludo Rules
The game supports two to four players with four tokens each. A six is required to enter a token, a six grants another turn, normal movement advances by dice count, overshooting the finish is rejected, and an exact finish is required. Tokens use player-specific track starts, private home lanes, safe-cell protection, and captures on shared non-safe cells. The game advances a turn automatically when a roll has no legal move and detects the winner when all tokens finish.

## Chess Rules
Chess supports local two-player play and host-authoritative two-player LAN rooms. Legal moves are checked against king safety, check, checkmate, stalemate, castling, en passant, and pawn promotion. The game recognizes the fifty-move draw and insufficient material. Chess state is synchronized as a FEN position, and room players can use the existing chat while playing.

## Tic Tac Toe Rules
The two local players alternate X and O. A move is accepted only for the current player and an empty in-range cell. Rows, columns, and diagonals are checked for a winner; a full board without a winner is a draw. Round reset preserves score; the match reset starts a new score.

## Carrom Rules and Scoring
The two-player match assigns White to the host and Black to the joining player; the Queen is shared. A player retains their turn after pocketing an own-colour coin. An opponent coin pocketed by the active player is returned to the board and does not count toward that player's captured coins.

The Queen can be claimed only after the player has pocketed an own-colour coin and must be covered by an own-colour coin on the same shot or the immediately following turn. An uncovered or foul-pocketed Queen returns to the board. A striker pocket is a foul: coins pocketed in that shot are returned, the foul count increases, and the turn passes; no direct point deduction is applied.

A board ends only after a player clears their colour and any pending Queen cover is resolved. The board winner receives one point per opponent coin remaining plus 3 points for a covered Queen. Scores are awarded only after a completed board; having fewer remaining coins during play does not win a match. The default match ends at 25 points or after 8 boards. Values are configurable through `CarromRulesOptions`. This is the project's selected tournament-style rules profile; local and networked matches share the same implementation.

## Carrom Multiplayer
Carrom uses the existing TCP room discovery and `MultiplayerSession` protocol. The host owns the physics and rules engines. A player submits only striker baseline X, pull point, and requested power as a revision-tagged action. The host validates player identity, turn ownership, ranges, and placement, runs physics, applies scoring once, and broadcasts the settled board, turn, Queen, foul, and score snapshot together with the validated shot input. The client animates that shot as a visual prediction, disables interaction during playback, then replaces its board with the authoritative settled snapshot. Clients cannot submit scores, pocket outcomes, or coin positions; client-side prediction never changes the host state.

The final result panel shows winner/forfeit status, final scores, coins pocketed, Queen bonus, fouls, and match duration. Either player may request a rematch after completion; the host resets the authoritative match. Unexpected host or guest disconnects end an active two-player match with a forfeit result. Reconnecting to an interrupted Carrom match is not supported. Physical two-PC testing has not been performed; use `Multiplayer_Two_PC_Test_Guide.md` for manual validation.

## Network Behavior and Limitations
The host can create a room on a selected TCP port. UDP broadcasts validated JSON announcements containing the room ID, game, host address, port, and capacity. A client can select a discovered room or enter an IP and port manually. The host validates join requests, room identity, game type, name uniqueness, and capacity. TCP messages are JSON-framed by newline and limited in size.

`MultiplayerSession` assigns unique player IDs, Tic Tac Toe marks, Chess sides, and Ludo colors. Clients send revision-tagged action requests; the host checks identity, turn, action ID, revision, and game rules before mutating its official engine. It broadcasts board, dice, turn, score, winner, token, and departure snapshots. Clients render those snapshots instead of deciding official results. Both intentional leave messages and TCP disconnects update the room roster and departure notification. In started two-player games, the remaining connected player receives a synchronized forfeit win and further game actions are rejected. In multiplayer Ludo, departed players remain visible as disconnected/LEFT and are skipped for turns; a departure alone does not award a win while multiple players remain. If only one player remains in an unfinished match, that player wins by forfeit. A host that intentionally leaves a running Ludo game keeps its server session alive while the remaining players finish; a sudden host-process loss still disconnects all guests because the host is authoritative.

TCP connection attempts use an eight-second deadline. Sockets also use TCP keep-alive probes (15-second idle time, five-second interval, three retries) to surface idle broken links without changing the message protocol.

Chat supports local-only messages without a connection and a separate two-player Chat Only LAN room, so players can communicate without starting a game. The lobby exposes actual connected/disconnected player states and gates host game launch on the existing connected-player count; the protocol has no Ready/Not Ready state. Automated loopback tests cover game departures, duplicate departure processing, two-player forfeits, multi-player Ludo continuation and final-player forfeits, synchronized state, and visible departure notices in addition to game, chat, and room behavior.

No separate-PC end-to-end gameplay test has been performed. A second physical Windows computer and suitable firewall/network settings are still required to verify cross-PC operation. Follow `Multiplayer_Two_PC_Test_Guide.md` for the manual test.

Network Center uses the Windows Wi-Fi scanner to show nearby SSIDs, signal strength, security type when available, and which network is currently connected. Scanning is separate from UDP multiplayer-room discovery and does not request or display Wi-Fi passwords. The scanner uses Windows `netsh wlan` and requires supported wireless hardware. If the adapter is unavailable, disabled, or unresponsive, the interface reports an error/unavailable or empty state; commands have a finite timeout.

## Automated Testing
The xUnit project tests Chess legal moves, king safety, checkmate, castling, en passant, promotion, stalemate, FEN restoration, and opening move counts. Ludo tests cover dice and movement, home entry, exact finishing, safe cells, cutting, turn handling, winner detection, inactive-player turn skipping, index validation, responsive board rendering/hit testing, legal-move highlighting, player status, and exit navigation. Tic Tac Toe tests cover win, draw, turn switching, invalid input, reset, responsive board layout, cell feedback, winning-line presentation, score, and exit navigation. Carrom tests cover physics, pockets/fouls, turn and score rules, Queen eligibility/cover, duplicate results, UI interactions, board layout, and host-authoritative loopback synchronization. Multiplayer tests cover two-player departures and synchronized forfeits, unexpected host loss in two-player games, multi-player Ludo departures/continuation, duplicate departure handling, Wi-Fi scan results, connected-network identification, and empty/error scan states. Multiplayer UI tests verify host launch gating, live room roster display, guest opening/leave behavior, Chat Only lobby availability, departure notifications, and back navigation. Game chat tests cover local and host messages. Navigation tests click each actual sidebar button with hardware probes disabled. Wi-Fi parser tests use controlled Windows command output. Loopback networking tests verify TCP receipt, capacity enforcement, validation, discovery parsing, multi-client host sessions, action rejection, disconnect handling, and authoritative state synchronization.

## Running and Verification
From the project directory on Windows, run `dotnet restore ".\visual project.csproj"`, `dotnet build ".\visual project.csproj" -c Release`, and `dotnet run --project ".\visual project.csproj"` to restore, build, and start the application. Run `dotnet test ".\WiFiGameHub.Tests\WiFiGameHub.Tests.csproj" -c Release` for the automated suite. The project is Windows-specific because both WinForms and Wi-Fi commands are Windows-specific. See the repository `README.md` for setup and `Multiplayer_Two_PC_Test_Guide.md` for physical LAN testing.

## Conclusion
WiFi Game Hub provides local game interfaces, Windows network scanning, player departure handling, and a host-authoritative LAN gameplay protocol verified with automated loopback integration tests. Separate-PC manual verification remains outstanding, so cross-PC operation should not be claimed as fully verified until that guide has been completed.