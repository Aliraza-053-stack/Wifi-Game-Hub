# Two-PC LAN Test Checklist

This manual test requires two Windows PCs. Automated loopback tests run on one computer and do not replace this checklist.

## Before testing

- [ ] Build and run the same project version on both Windows PCs.
- [ ] Connect both PCs to the same Wi-Fi/LAN.
- [ ] Make sure the network allows devices to communicate with each other; guest networks may isolate clients.
- [ ] On the host PC, allow the selected game TCP port (default `45456`) through Windows Defender Firewall.
- [ ] Allow LAN discovery UDP port `45455` through Windows Defender Firewall on both PCs.
- [ ] Find the host's LAN IPv4 address (for example, with `ipconfig`).

## Create and join a room

1. On PC A, open **Multiplayer Rooms** or choose **Play in Room** from a game.
2. Select the game, enter the host's player name, and confirm the TCP port.
3. Choose **Create Room**. Record the room ID shown at the top and the host's LAN IPv4 address.
4. On PC B, open **Multiplayer Rooms** or choose **Play in Room** for the same game.
5. To join by discovery, select PC A's room from **Available Rooms** and choose **Join Selected Room**.
6. To join manually, enter PC A's address, the same TCP port, the displayed room ID, select the same game, enter a player name, and choose **Join by ID**.
7. Check that the host and guest are both listed as connected in the Players tab and that the room ID matches.

## Game and chat checks

- **Chess / Tic-Tac-Toe:** Once the second player joins, open the game on the host from the lobby. The guest can open it after the room state reports the game started. Make moves on alternating devices and check that turns, moves, wins/draws, and resulting game state match. In Tic-Tac-Toe, also test an occupied cell and confirm it is rejected.
- **Ludo:** The host opens Ludo after the second player joins, then chooses **New Match** to start with the connected roster. The guest can open Ludo once the match has started. Test dice rolls, legal token moves, turn order, and the same displayed dice/token state on both devices. Test with two players first; add devices for three and four-player checks.
- **Carrom:** Create a Carrom room on PC A and join it from PC B by discovery and then by room ID. Confirm the host is assigned White and the guest Black. Open Carrom on both devices from the lobby. Confirm only the active player can position/shoot; take alternating shots and compare piece positions, coin counts, turn, scores, fouls, and Queen status. When the opponent shoots, confirm the client shows a shot-in-progress animation, disables controls, and settles to the host's final board and score. Try an out-of-turn shot and an out-of-range striker position using the test client or automated tests; the host should reject these without advancing state. Pocket an own coin to confirm the same player keeps the turn, pocket an opponent coin to confirm it is returned, and exercise the Queen cover, foul, board-completion, and match-result behavior. Confirm both result panels show identical scores, coin totals, Queen bonuses, fouls, and duration, and try a rematch from either player. Disconnect either player during play and confirm the remaining player sees a forfeit result. Reconnection to the interrupted match is not supported.
- **Chat:** Open the lobby's Chat tab and send messages in both directions. Test in a game room and in a Chat Only room.
- **Two-player departure/forfeit:** In Chess, Ludo, and Tic-Tac-Toe, start a two-player match, then have the guest choose Leave/Exit. Confirm the host receives one player-left notice, displays the remaining player as the winner, and rejects further moves. Repeat by closing the guest application or ending its network connection unexpectedly. Also reverse roles if practical so a guest can observe the host's departure.
- **Four-player Ludo:** Use four PCs on the same LAN. Start a four-player match and have one guest leave or disconnect. Confirm the other three see the departed name as LEFT, no premature winner is announced, turns skip the departed player, and the remaining players can keep playing. Then have another player leave so two remain; confirm those two continue. Have one of the final two leave and confirm the last player receives the win notice and can no longer make moves.
- **Wi-Fi network scan:** Open **Network Center**, scan/refresh, and confirm nearby SSIDs and signal strengths appear, security is shown when Windows provides it, and the connected network is identified. Confirm this list is separate from multiplayer room discovery and that no password is requested or displayed. Repeat with Wi-Fi disabled or no results if possible and verify the UI reports an empty/error state without freezing.
- **Disconnect and room exit:** Confirm the host UI reflects disconnected guest status, then rejoin and verify the app remains responsive. For an intentional host departure during an active Ludo match, verify remaining players can continue while the host application remains running. Abrupt host application/computer loss disconnects all guests; this host-authoritative architecture cannot continue a three- or four-player match without its host.
- **Invalid join:** Try a wrong room ID, wrong game, invalid host address, and unreachable TCP port. Confirm an understandable failure is shown and that the app remains usable.
- **Room exit:** Have a guest leave, then have the host close the room. Confirm the room code and roster are no longer shown as an active session.

## Record results

| Test | Result / notes |
|---|---|
| Devices, Windows versions, and network | |
| Host address, game, and TCP port | |
| UDP discovery | |
| Create room and copy/share room ID | |
| Join by discovery | |
| Join by room ID | |
| Player roles and connection status | |
| Game launch and synchronized play | |
| Carrom roles, turns, host validation, and state snapshots | |
| Carrom Queen cover, foul, score, and match result | |
| Chat both ways | |
| Two-player departures and forfeit results (each game) | |
| Four-player Ludo departure and continuation | |
| Network Center Wi-Fi scanning and connected SSID | |
| Invalid joins and errors | |
| Guest leave / host close | |

## Troubleshooting

- No discovered rooms: verify both computers are on the same local network and UDP `45455` is allowed. Try **Join by ID**.
- Connection refused or timeout: confirm host IPv4, TCP port, room ID, game selection, and Windows Firewall access.
- Devices cannot reach one another: disable client isolation or use a non-guest network.
- The default TCP port is `45456`, but the host may configure another port. The joining computer must use the exact same port.

Do not report cross-PC testing as passed until these checks have been performed on physical computers.
