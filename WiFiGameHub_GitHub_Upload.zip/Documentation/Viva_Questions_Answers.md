# Viva Questions and Answers

## C# and Object-Oriented Programming

1. **What is C#?**  
   C# is a programming language from Microsoft. It is used to build many kinds of applications.

2. **What is .NET 8?**  
   .NET 8 is the platform used to build and run this application.

3. **What is a namespace?**  
   A namespace groups related types and helps prevent naming conflicts.

4. **What is a class?**  
   A class is a blueprint that describes data and behavior.

5. **What is an object?**  
   An object is one instance created from a class.

6. **What is encapsulation?**  
   Encapsulation keeps related data and methods together and controls access to them.

7. **What is inheritance?**  
   Inheritance lets a class reuse or extend behavior from another class.

8. **What is polymorphism?**  
   Polymorphism lets different types respond to the same operation in their own way.

9. **What is abstraction?**  
   Abstraction shows useful operations while hiding unnecessary implementation detail.

10. **What is a property?**  
    A property provides a controlled way to read or change an object's value.

11. **What is a method?**  
    A method is a named block of code that performs an operation.

12. **What is a constructor?**  
    A constructor runs when an object is created and can set its starting values.

13. **What is an enum?**  
    An enum is a named set of constant choices, such as the game's message types.

14. **What is a list?**  
    A list stores a changeable number of items of the same type.

15. **What is exception handling?**  
    Exception handling detects runtime errors and lets the application respond safely.

16. **What does `try-catch` do?**  
    It runs code that may fail and handles a matching error if one occurs.

## Windows Forms and Events

17. **What is Windows Forms?**  
    Windows Forms is a .NET framework for building Windows desktop interfaces.

18. **What is a Form?**  
    A Form is a window or screen that contains controls.

19. **What is a control?**  
    A control is an interface element such as a button, label, or text box.

20. **What is an event?**  
    An event is a notification that something happened, often because of user input.

21. **What is a delegate?**  
    A delegate is a type-safe reference to a method and is often used by events.

22. **What happens in a button click handler?**  
    The handler runs when the user clicks that button.

23. **Why use a layout panel?**  
    A layout panel arranges controls in rows, columns, or a flow.

24. **What is docking?**  
    Docking attaches a control to an edge or fills its parent area.

25. **What is double buffering?**  
    Double buffering draws into a hidden buffer first to reduce flicker.

26. **Why does the sidebar use a dictionary?**  
    It maps a page key to its form so navigation can find the correct page.

## Networking and Wi-Fi

27. **What is an IP address?**  
    An IP address identifies a device on an IP network.

28. **What is a LAN?**  
    A LAN is a local area network, such as devices connected to the same home router.

29. **What is TCP?**  
    TCP is a connection-based protocol that delivers an ordered byte stream.

30. **What is UDP?**  
    UDP sends independent datagrams without guaranteeing delivery or order.

31. **Why use TCP for a room connection?**  
    TCP provides a reliable stream for room requests and replies.

32. **Why use UDP for room discovery?**  
    UDP broadcast can announce a room to nearby devices without connecting to each one first.

33. **What is a port?**  
    A port identifies a network service on a device.

34. **What is JSON?**  
    JSON is a text format for structured data.

35. **What is JSON serialization?**  
    Serialization converts an object into JSON text so it can be sent or stored.

36. **What does Wi-Fi scanning show?**  
    On supported Windows hardware, it shows nearby SSIDs, signal strength, and authentication type.

37. **Which Windows command is used for Wi-Fi scanning?**  
    The scanner uses Windows `netsh wlan` commands.

38. **What happens if the Wi-Fi adapter is unavailable?**  
    The app reports that the status or scan is unavailable instead of inventing networks.

39. **What is a room ID?**  
    A room ID identifies a particular game room.

40. **Does this project synchronize game moves between computers?**  
    Not yet. The lobby can discover rooms and exchange join messages, but board moves are not synchronized.

## Game Rules and Testing

41. **How many cells are on a Tic Tac Toe board?**  
    There are nine cells arranged in three rows and three columns.

42. **How does Tic Tac Toe detect a win?**  
    It checks rows, columns, and both diagonals for three matching marks.

43. **What is a Tic Tac Toe draw?**  
    It is a full board with no winning line.

44. **How many players can play local Ludo?**  
    The game supports two, three, or four players.

45. **Why is a six important in this Ludo implementation?**  
    A six lets a player bring a token out of home and grants another turn after a move.

46. **What is an exact finish?**  
    A token must reach the final home position using the exact dice count; a larger roll is rejected.

47. **What is a safe cell in Ludo?**  
    It is a track cell where an opponent cannot capture a token.

48. **What does cutting a token mean?**  
    A token landing on an opponent at a non-safe cell sends that opponent token home.

49. **Why are automated tests useful?**  
    They check expected behavior repeatedly and catch regressions after code changes.

50. **What network tests have been run?**  
    Local loopback tests verify TCP message receipt, capacity enforcement, message validation, and discovery payload parsing. A separate-PC gameplay test has not been run.