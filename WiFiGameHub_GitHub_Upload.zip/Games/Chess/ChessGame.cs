namespace WiFiGameHub.Games.Chess;

public enum ChessSide
{
    White,
    Black
}

public sealed class ChessGame
{
    public const int BoardSize = 8;
    private static readonly string InitialFen = "rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR w KQkq - 0 1";
    private static readonly (int Row, int Column)[] KnightOffsets =
    {
        (-2, -1), (-2, 1), (-1, -2), (-1, 2), (1, -2), (1, 2), (2, -1), (2, 1)
    };
    private static readonly (int Row, int Column)[] KingOffsets =
    {
        (-1, -1), (-1, 0), (-1, 1), (0, -1), (0, 1), (1, -1), (1, 0), (1, 1)
    };
    private static readonly (int Row, int Column)[] BishopDirections =
    {
        (-1, -1), (-1, 1), (1, -1), (1, 1)
    };
    private static readonly (int Row, int Column)[] RookDirections =
    {
        (-1, 0), (1, 0), (0, -1), (0, 1)
    };

    private char[,] _board = new char[BoardSize, BoardSize];
    private bool _whiteKingSide;
    private bool _whiteQueenSide;
    private bool _blackKingSide;
    private bool _blackQueenSide;
    private (int Row, int Column)? _enPassantTarget;
    private int _halfmoveClock;
    private int _fullmoveNumber = 1;

    public ChessSide CurrentTurn { get; private set; }
    public bool IsGameOver { get; private set; }
    public bool IsDraw { get; private set; }
    public bool IsStalemate { get; private set; }
    public bool IsCheck => IsKingInCheck(CurrentTurn);
    public ChessSide? Winner { get; private set; }
    public List<string> MoveHistory { get; } = new();
    public (int FromRow, int FromColumn, int ToRow, int ToColumn)? LastMove { get; private set; }

    public char[,] Board => (char[,])_board.Clone();

    public ChessGame()
    {
        LoadFen(InitialFen);
    }

    public IReadOnlyList<(int Row, int Column)> GetLegalMoves(int row, int column)
    {
        if (IsGameOver || !IsInside(row, column) || _board[row, column] == '\0'
            || SideOf(_board[row, column]) != CurrentTurn)
        {
            return Array.Empty<(int Row, int Column)>();
        }

        return GetPseudoLegalMoves(row, column)
            .Where(move => !WouldLeaveKingInCheck(row, column, move.Row, move.Column,
                IsPawn(_board[row, column]) && move == _enPassantTarget))
            .ToArray();
    }

    public bool TryMove(int fromRow, int fromColumn, int toRow, int toColumn, char promotion = 'Q')
    {
        if (IsGameOver || !IsInside(fromRow, fromColumn) || !IsInside(toRow, toColumn)
            || !GetLegalMoves(fromRow, fromColumn).Contains((toRow, toColumn)))
        {
            return false;
        }

        var piece = _board[fromRow, fromColumn];
        var promote = IsPawn(piece) && toRow == (SideOf(piece) == ChessSide.White ? 0 : 7);
        promotion = char.ToUpperInvariant(promotion);
        if (promotion is not ('Q' or 'R' or 'B' or 'N'))
        {
            return false;
        }

        var enPassant = IsPawn(piece) && (toRow, toColumn) == _enPassantTarget;
        ApplyMoveUnchecked(fromRow, fromColumn, toRow, toColumn, promote ? promotion : '\0', enPassant);
        LastMove = (fromRow, fromColumn, toRow, toColumn);
        var notation = $"{SquareName(fromRow, fromColumn)}-{SquareName(toRow, toColumn)}";
        if (promote)
        {
            notation += $"={promotion}";
        }

        if (HasInsufficientMaterial())
        {
            IsGameOver = true;
            IsDraw = true;
        }
        else if (_halfmoveClock >= 100)
        {
            IsGameOver = true;
            IsDraw = true;
        }
        else if (!HasAnyLegalMove(CurrentTurn))
        {
            IsGameOver = true;
            if (IsKingInCheck(CurrentTurn))
            {
                Winner = CurrentTurn == ChessSide.White ? ChessSide.Black : ChessSide.White;
                notation += "#";
            }
            else
            {
                IsDraw = true;
                IsStalemate = true;
            }
        }
        else if (IsKingInCheck(CurrentTurn))
        {
            notation += "+";
        }

        MoveHistory.Add(notation);
        return true;
    }

    public string ToFen()
    {
        var rows = new string[BoardSize];
        for (var row = 0; row < BoardSize; row++)
        {
            var empty = 0;
            var text = new System.Text.StringBuilder(BoardSize);
            for (var column = 0; column < BoardSize; column++)
            {
                var piece = _board[row, column];
                if (piece == '\0')
                {
                    empty++;
                }
                else
                {
                    if (empty > 0)
                    {
                        text.Append(empty);
                        empty = 0;
                    }
                    text.Append(piece);
                }
            }
            if (empty > 0)
            {
                text.Append(empty);
            }
            rows[row] = text.ToString();
        }

        var castling = string.Concat(
            _whiteKingSide ? "K" : string.Empty,
            _whiteQueenSide ? "Q" : string.Empty,
            _blackKingSide ? "k" : string.Empty,
            _blackQueenSide ? "q" : string.Empty);
        if (castling.Length == 0)
        {
            castling = "-";
        }
        var enPassant = _enPassantTarget is { } target ? SquareName(target.Row, target.Column) : "-";
        return $"{string.Join("/", rows)} {(CurrentTurn == ChessSide.White ? "w" : "b")} {castling} {enPassant} {_halfmoveClock} {_fullmoveNumber}";
    }

    public void LoadFen(string fen, IReadOnlyList<string>? moveHistory = null)
    {
        ArgumentException.ThrowIfNullOrWhiteSpace(fen);
        var fields = fen.Split(' ', StringSplitOptions.RemoveEmptyEntries);
        if (fields.Length != 6)
        {
            throw new ArgumentException("Chess position must contain all six FEN fields.", nameof(fen));
        }

        var board = new char[BoardSize, BoardSize];
        var rows = fields[0].Split('/');
        if (rows.Length != BoardSize)
        {
            throw new ArgumentException("Chess position must have eight ranks.", nameof(fen));
        }
        for (var row = 0; row < BoardSize; row++)
        {
            var column = 0;
            foreach (var symbol in rows[row])
            {
                if (symbol is >= '1' and <= '8')
                {
                    column += symbol - '0';
                }
                else if (IsPiece(symbol) && column < BoardSize)
                {
                    board[row, column++] = symbol;
                }
                else
                {
                    throw new ArgumentException("Chess position contains an invalid rank.", nameof(fen));
                }
            }
            if (column != BoardSize)
            {
                throw new ArgumentException("Each chess rank must contain eight squares.", nameof(fen));
            }
        }

        if (board.Cast<char>().Count(piece => piece == 'K') != 1
            || board.Cast<char>().Count(piece => piece == 'k') != 1)
        {
            throw new ArgumentException("Chess position must contain exactly one king per side.", nameof(fen));
        }
        if (fields[1] is not ("w" or "b"))
        {
            throw new ArgumentException("Chess position has an invalid side to move.", nameof(fen));
        }
        if (fields[2] != "-" && (fields[2].Any(character => !"KQkq".Contains(character))
            || fields[2].Distinct().Count() != fields[2].Length))
        {
            throw new ArgumentException("Chess position has invalid castling rights.", nameof(fen));
        }
        if (fields[3] != "-" && !TryParseSquare(fields[3], out _))
        {
            throw new ArgumentException("Chess position has an invalid en-passant square.", nameof(fen));
        }
        if (!int.TryParse(fields[4], out var halfmove) || halfmove < 0
            || !int.TryParse(fields[5], out var fullmove) || fullmove < 1)
        {
            throw new ArgumentException("Chess position has invalid move counters.", nameof(fen));
        }

        _board = board;
        CurrentTurn = fields[1] == "w" ? ChessSide.White : ChessSide.Black;
        _whiteKingSide = fields[2].Contains('K');
        _whiteQueenSide = fields[2].Contains('Q');
        _blackKingSide = fields[2].Contains('k');
        _blackQueenSide = fields[2].Contains('q');
        _enPassantTarget = fields[3] == "-" ? null : ParseSquare(fields[3]);
        _halfmoveClock = halfmove;
        _fullmoveNumber = fullmove;
        IsGameOver = false;
        IsDraw = false;
        IsStalemate = false;
        Winner = null;
        LastMove = null;
        MoveHistory.Clear();
        if (moveHistory is not null)
        {
            MoveHistory.AddRange(moveHistory);
        }
        if (_halfmoveClock >= 100 || HasInsufficientMaterial())
        {
            IsGameOver = true;
            IsDraw = true;
        }
        else if (!HasAnyLegalMove(CurrentTurn))
        {
            IsGameOver = true;
            IsDraw = !IsKingInCheck(CurrentTurn);
            if (IsDraw)
            {
                IsStalemate = true;
            }
            else
            {
                Winner = CurrentTurn == ChessSide.White ? ChessSide.Black : ChessSide.White;
            }
        }
    }

    private bool WouldLeaveKingInCheck(int fromRow, int fromColumn, int toRow, int toColumn, bool enPassant)
    {
        var board = (char[,])_board.Clone();
        var state = (_whiteKingSide, _whiteQueenSide, _blackKingSide, _blackQueenSide, _enPassantTarget, _halfmoveClock, _fullmoveNumber, CurrentTurn);
        ApplyMoveUnchecked(fromRow, fromColumn, toRow, toColumn, '\0', enPassant);
        var inCheck = IsKingInCheck(state.CurrentTurn);
        _board = board;
        (_whiteKingSide, _whiteQueenSide, _blackKingSide, _blackQueenSide, _enPassantTarget, _halfmoveClock, _fullmoveNumber, CurrentTurn) = state;
        return inCheck;
    }

    private void ApplyMoveUnchecked(int fromRow, int fromColumn, int toRow, int toColumn, char promotion, bool enPassant = false)
    {
        var piece = _board[fromRow, fromColumn];
        var captured = enPassant ? _board[fromRow, toColumn] : _board[toRow, toColumn];
        var movingSide = SideOf(piece);
        _board[fromRow, fromColumn] = '\0';
        if (enPassant)
        {
            _board[fromRow, toColumn] = '\0';
        }

        _board[toRow, toColumn] = promotion == '\0' ? piece : movingSide == ChessSide.White ? promotion : char.ToLowerInvariant(promotion);
        if (char.ToUpperInvariant(piece) == 'K' && Math.Abs(toColumn - fromColumn) == 2)
        {
            var rookFrom = toColumn > fromColumn ? 7 : 0;
            var rookTo = toColumn > fromColumn ? toColumn - 1 : toColumn + 1;
            _board[fromRow, rookTo] = _board[fromRow, rookFrom];
            _board[fromRow, rookFrom] = '\0';
        }

        UpdateCastlingRights(piece, fromRow, fromColumn, captured, toRow, toColumn);
        _enPassantTarget = IsPawn(piece) && Math.Abs(toRow - fromRow) == 2
            ? ((toRow + fromRow) / 2, fromColumn)
            : null;
        _halfmoveClock = IsPawn(piece) || captured != '\0' ? 0 : _halfmoveClock + 1;
        if (movingSide == ChessSide.Black)
        {
            _fullmoveNumber++;
        }
        CurrentTurn = movingSide == ChessSide.White ? ChessSide.Black : ChessSide.White;
    }

    private void UpdateCastlingRights(char piece, int fromRow, int fromColumn, char captured, int toRow, int toColumn)
    {
        if (piece == 'K') { _whiteKingSide = false; _whiteQueenSide = false; }
        if (piece == 'k') { _blackKingSide = false; _blackQueenSide = false; }
        if (piece == 'R' && fromRow == 7 && fromColumn == 0) _whiteQueenSide = false;
        if (piece == 'R' && fromRow == 7 && fromColumn == 7) _whiteKingSide = false;
        if (piece == 'r' && fromRow == 0 && fromColumn == 0) _blackQueenSide = false;
        if (piece == 'r' && fromRow == 0 && fromColumn == 7) _blackKingSide = false;
        if (captured == 'R' && toRow == 7 && toColumn == 0) _whiteQueenSide = false;
        if (captured == 'R' && toRow == 7 && toColumn == 7) _whiteKingSide = false;
        if (captured == 'r' && toRow == 0 && toColumn == 0) _blackQueenSide = false;
        if (captured == 'r' && toRow == 0 && toColumn == 7) _blackKingSide = false;
    }

    private IReadOnlyList<(int Row, int Column)> GetPseudoLegalMoves(int row, int column)
    {
        var piece = _board[row, column];
        var side = SideOf(piece);
        var moves = new List<(int Row, int Column)>();
        switch (char.ToUpperInvariant(piece))
        {
            case 'P':
                var direction = side == ChessSide.White ? -1 : 1;
                var startRow = side == ChessSide.White ? 6 : 1;
                AddPawnMove(row + direction, column, side, moves);
                if (row == startRow && IsInside(row + direction, column) && _board[row + direction, column] == '\0')
                {
                    AddPawnMove(row + direction * 2, column, side, moves);
                }
                foreach (var offset in new[] { -1, 1 })
                {
                    var targetRow = row + direction;
                    var targetColumn = column + offset;
                    if (IsInside(targetRow, targetColumn)
                        && ((_board[targetRow, targetColumn] != '\0' && SideOf(_board[targetRow, targetColumn]) != side)
                            || _enPassantTarget == (targetRow, targetColumn)))
                    {
                        moves.Add((targetRow, targetColumn));
                    }
                }
                break;
            case 'N':
                foreach (var offset in KnightOffsets) AddStep(row, column, offset.Row, offset.Column, side, moves);
                break;
            case 'B':
                AddSlidingMoves(row, column, side, BishopDirections, moves);
                break;
            case 'R':
                AddSlidingMoves(row, column, side, RookDirections, moves);
                break;
            case 'Q':
                AddSlidingMoves(row, column, side, BishopDirections.Concat(RookDirections), moves);
                break;
            case 'K':
                foreach (var offset in KingOffsets) AddStep(row, column, offset.Row, offset.Column, side, moves);
                AddCastlingMoves(row, column, side, moves);
                break;
        }
        return moves;
    }

    private void AddPawnMove(int row, int column, ChessSide side, ICollection<(int Row, int Column)> moves)
    {
        if (IsInside(row, column) && _board[row, column] == '\0')
        {
            moves.Add((row, column));
        }
    }

    private void AddStep(int row, int column, int rowOffset, int columnOffset, ChessSide side, ICollection<(int Row, int Column)> moves)
    {
        var targetRow = row + rowOffset;
        var targetColumn = column + columnOffset;
        if (IsInside(targetRow, targetColumn)
            && (_board[targetRow, targetColumn] == '\0'
                || SideOf(_board[targetRow, targetColumn]) != side && char.ToUpperInvariant(_board[targetRow, targetColumn]) != 'K'))
        {
            moves.Add((targetRow, targetColumn));
        }
    }

    private void AddSlidingMoves(int row, int column, ChessSide side, IEnumerable<(int Row, int Column)> directions, ICollection<(int Row, int Column)> moves)
    {
        foreach (var direction in directions)
        {
            var targetRow = row + direction.Row;
            var targetColumn = column + direction.Column;
            while (IsInside(targetRow, targetColumn))
            {
                var target = _board[targetRow, targetColumn];
                if (target == '\0')
                {
                    moves.Add((targetRow, targetColumn));
                }
                else
                {
                    if (SideOf(target) != side && char.ToUpperInvariant(target) != 'K')
                    {
                        moves.Add((targetRow, targetColumn));
                    }
                    break;
                }
                targetRow += direction.Row;
                targetColumn += direction.Column;
            }
        }
    }

    private void AddCastlingMoves(int row, int column, ChessSide side, ICollection<(int Row, int Column)> moves)
    {
        var homeRow = side == ChessSide.White ? 7 : 0;
        if (row != homeRow || column != 4 || IsSquareAttacked(row, column, side == ChessSide.White ? ChessSide.Black : ChessSide.White))
        {
            return;
        }

        var kingSide = side == ChessSide.White ? _whiteKingSide : _blackKingSide;
        if (kingSide && _board[homeRow, 5] == '\0' && _board[homeRow, 6] == '\0'
            && _board[homeRow, 7] == (side == ChessSide.White ? 'R' : 'r')
            && !IsSquareAttacked(homeRow, 5, side == ChessSide.White ? ChessSide.Black : ChessSide.White)
            && !IsSquareAttacked(homeRow, 6, side == ChessSide.White ? ChessSide.Black : ChessSide.White))
        {
            moves.Add((homeRow, 6));
        }

        var queenSide = side == ChessSide.White ? _whiteQueenSide : _blackQueenSide;
        if (queenSide && _board[homeRow, 1] == '\0' && _board[homeRow, 2] == '\0' && _board[homeRow, 3] == '\0'
            && _board[homeRow, 0] == (side == ChessSide.White ? 'R' : 'r')
            && !IsSquareAttacked(homeRow, 3, side == ChessSide.White ? ChessSide.Black : ChessSide.White)
            && !IsSquareAttacked(homeRow, 2, side == ChessSide.White ? ChessSide.Black : ChessSide.White))
        {
            moves.Add((homeRow, 2));
        }
    }

    private bool HasAnyLegalMove(ChessSide side)
    {
        for (var row = 0; row < BoardSize; row++)
        {
            for (var column = 0; column < BoardSize; column++)
            {
                if (_board[row, column] == '\0' || SideOf(_board[row, column]) != side)
                {
                    continue;
                }
                foreach (var move in GetPseudoLegalMoves(row, column))
                {
                    var enPassant = IsPawn(_board[row, column]) && move == _enPassantTarget;
                    if (!WouldLeaveKingInCheck(row, column, move.Row, move.Column, enPassant))
                    {
                        return true;
                    }
                }
            }
        }
        return false;
    }

    private bool IsKingInCheck(ChessSide side)
    {
        var king = side == ChessSide.White ? 'K' : 'k';
        for (var row = 0; row < BoardSize; row++)
        {
            for (var column = 0; column < BoardSize; column++)
            {
                if (_board[row, column] == king)
                {
                    return IsSquareAttacked(row, column, side == ChessSide.White ? ChessSide.Black : ChessSide.White);
                }
            }
        }
        return true;
    }

    private bool IsSquareAttacked(int row, int column, ChessSide attacker)
    {
        var pawnRow = row + (attacker == ChessSide.White ? 1 : -1);
        var pawn = attacker == ChessSide.White ? 'P' : 'p';
        foreach (var pawnColumn in new[] { column - 1, column + 1 })
        {
            if (IsInside(pawnRow, pawnColumn) && _board[pawnRow, pawnColumn] == pawn) return true;
        }
        var knight = attacker == ChessSide.White ? 'N' : 'n';
        foreach (var offset in KnightOffsets)
        {
            var sourceRow = row + offset.Row;
            var sourceColumn = column + offset.Column;
            if (IsInside(sourceRow, sourceColumn) && _board[sourceRow, sourceColumn] == knight) return true;
        }
        var king = attacker == ChessSide.White ? 'K' : 'k';
        foreach (var offset in KingOffsets)
        {
            var sourceRow = row + offset.Row;
            var sourceColumn = column + offset.Column;
            if (IsInside(sourceRow, sourceColumn) && _board[sourceRow, sourceColumn] == king) return true;
        }
        return IsAttackedAlong(row, column, attacker, BishopDirections, 'B', 'Q')
            || IsAttackedAlong(row, column, attacker, RookDirections, 'R', 'Q');
    }

    private bool IsAttackedAlong(int row, int column, ChessSide attacker, IEnumerable<(int Row, int Column)> directions, char firstPiece, char secondPiece)
    {
        var first = attacker == ChessSide.White ? firstPiece : char.ToLowerInvariant(firstPiece);
        var second = attacker == ChessSide.White ? secondPiece : char.ToLowerInvariant(secondPiece);
        foreach (var direction in directions)
        {
            var targetRow = row + direction.Row;
            var targetColumn = column + direction.Column;
            while (IsInside(targetRow, targetColumn))
            {
                var piece = _board[targetRow, targetColumn];
                if (piece != '\0')
                {
                    if (piece == first || piece == second) return true;
                    break;
                }
                targetRow += direction.Row;
                targetColumn += direction.Column;
            }
        }
        return false;
    }

    private bool HasInsufficientMaterial()
    {
        var pieces = _board.Cast<char>().Where(piece => piece != '\0' && char.ToUpperInvariant(piece) != 'K').ToArray();
        if (pieces.Length == 0) return true;
        if (pieces.Length == 1 && char.ToUpperInvariant(pieces[0]) is 'B' or 'N') return true;
        if (pieces.All(piece => char.ToUpperInvariant(piece) == 'B'))
        {
            var colors = new HashSet<int>();
            for (var row = 0; row < BoardSize; row++)
            {
                for (var column = 0; column < BoardSize; column++)
                {
                    if (char.ToUpperInvariant(_board[row, column]) == 'B') colors.Add((row + column) % 2);
                }
            }
            return colors.Count <= 1;
        }
        return false;
    }

    private static bool IsInside(int row, int column) => row is >= 0 and < BoardSize && column is >= 0 and < BoardSize;
    private static bool IsPiece(char piece) => "KQRBNPkqrbnp".Contains(piece);
    private static bool IsPawn(char piece) => char.ToUpperInvariant(piece) == 'P';
    private static ChessSide SideOf(char piece) => char.IsUpper(piece) ? ChessSide.White : ChessSide.Black;
    private static string SquareName(int row, int column) => $"{(char)('a' + column)}{8 - row}";

    private static bool TryParseSquare(string square, out (int Row, int Column) result)
    {
        result = default;
        if (square.Length != 2 || square[0] is < 'a' or > 'h' || square[1] is < '1' or > '8')
        {
            return false;
        }
        result = ParseSquare(square);
        return true;
    }

    private static (int Row, int Column) ParseSquare(string square) => (8 - (square[1] - '0'), square[0] - 'a');
}
