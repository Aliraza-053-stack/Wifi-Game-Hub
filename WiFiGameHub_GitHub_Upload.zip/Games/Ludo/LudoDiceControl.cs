using System.Drawing.Drawing2D;

namespace WiFiGameHub.Games.Ludo;

public sealed class LudoDiceControl : Control
{
    private static readonly PointF[] PipPositions =
    {
        new(0.25f, 0.25f), new(0.5f, 0.25f), new(0.75f, 0.25f),
        new(0.25f, 0.5f), new(0.5f, 0.5f), new(0.75f, 0.5f),
        new(0.25f, 0.75f), new(0.5f, 0.75f), new(0.75f, 0.75f)
    };
    private static readonly int[][] Faces =
    {
        Array.Empty<int>(),
        new[] { 4 },
        new[] { 0, 8 },
        new[] { 0, 4, 8 },
        new[] { 0, 2, 6, 8 },
        new[] { 0, 2, 4, 6, 8 },
        new[] { 0, 2, 3, 5, 6, 8 }
    };

    private readonly System.Windows.Forms.Timer _animationTimer = new() { Interval = 65 };
    private int _displayValue;
    private int _finalValue;
    private int _elapsed;
    private bool _isRolling;

    public int Value => _displayValue;
    public bool IsRolling => _isRolling;

    public LudoDiceControl()
    {
        DoubleBuffered = true;
        ResizeRedraw = true;
        BackColor = Color.FromArgb(21, 22, 38);
        MinimumSize = new Size(92, 72);
        AccessibleRole = AccessibleRole.Indicator;
        AccessibleName = "Dice result";
        _animationTimer.Tick += AnimationTimer_Tick;
    }

    public void ShowRoll(int result)
    {
        if (result is < 1 or > 6)
        {
            throw new ArgumentOutOfRangeException(nameof(result), "Dice results must be between 1 and 6.");
        }

        _finalValue = result;
        _elapsed = 0;
        _isRolling = true;
        AccessibleDescription = "Dice rolling";
        _displayValue = Random.Shared.Next(1, 7);
        _animationTimer.Start();
        Invalidate();
    }

    public void Clear()
    {
        _animationTimer.Stop();
        _isRolling = false;
        _displayValue = 0;
        _finalValue = 0;
        _elapsed = 0;
        AccessibleDescription = "No dice result";
        Invalidate();
    }

    protected override void OnPaint(PaintEventArgs e)
    {
        base.OnPaint(e);
        e.Graphics.SmoothingMode = SmoothingMode.AntiAlias;

        var faceSize = Math.Min(ClientSize.Height - 12, Math.Min(ClientSize.Width * 0.42f, 104));
        if (faceSize <= 0)
        {
            return;
        }

        var face = new RectangleF(4, (ClientSize.Height - faceSize) / 2f, faceSize, faceSize);
        var corner = Math.Max(7f, faceSize * 0.16f);
        var shadow = new RectangleF(face.X + faceSize * 0.035f, face.Y + faceSize * 0.055f, face.Width, face.Height);
        using var shadowBrush = new SolidBrush(Color.FromArgb(75, 4, 9, 20));
        using var faceBrush = new SolidBrush(_isRolling ? Color.FromArgb(235, 241, 252) : Color.White);
        using var borderPen = new Pen(Color.FromArgb(205, 217, 236), Math.Max(1f, faceSize * 0.025f));
        using var shadowPath = RoundedRectangle(shadow, corner);
        using var facePath = RoundedRectangle(face, corner);
        e.Graphics.FillPath(shadowBrush, shadowPath);
        e.Graphics.FillPath(faceBrush, facePath);
        e.Graphics.DrawPath(borderPen, facePath);

        if (_displayValue is >= 1 and <= 6)
        {
            var pipSize = faceSize * 0.13f;
            using var pipBrush = new SolidBrush(Color.FromArgb(33, 45, 66));
            foreach (var pipIndex in Faces[_displayValue])
            {
                var position = PipPositions[pipIndex];
                var centerX = face.Left + position.X * faceSize;
                var centerY = face.Top + position.Y * faceSize;
                e.Graphics.FillEllipse(pipBrush, centerX - pipSize / 2f, centerY - pipSize / 2f, pipSize, pipSize);
            }
        }

        var resultArea = new RectangleF(face.Right + 12, 4, Math.Max(0, ClientSize.Width - face.Right - 16), ClientSize.Height - 8);
        using var resultBrush = new SolidBrush(Color.White);
        using var resultFont = new Font("Segoe UI", Math.Min(30F, Math.Max(20F, faceSize * 0.42F)), FontStyle.Bold);
        using var captionBrush = new SolidBrush(Color.FromArgb(158, 165, 190));
        using var captionFont = new Font("Segoe UI", 7.5F, FontStyle.Bold);
        using var resultFormat = new StringFormat { Alignment = StringAlignment.Near, LineAlignment = StringAlignment.Center };
        using var captionFormat = new StringFormat { Alignment = StringAlignment.Near, LineAlignment = StringAlignment.Center };
        e.Graphics.DrawString(_displayValue == 0 ? "–" : _displayValue.ToString(), resultFont, resultBrush,
            new RectangleF(resultArea.X, resultArea.Y + 7, resultArea.Width, resultArea.Height * 0.68f),
            resultFormat);
        e.Graphics.DrawString(_isRolling ? "ROLLING" : "LAST ROLL", captionFont, captionBrush,
            new RectangleF(resultArea.X + 2, resultArea.Bottom - 20, resultArea.Width - 2, 15),
            captionFormat);
    }

    protected override void Dispose(bool disposing)
    {
        if (disposing)
        {
            _animationTimer.Stop();
            _animationTimer.Dispose();
        }
        base.Dispose(disposing);
    }

    private void AnimationTimer_Tick(object? sender, EventArgs e)
    {
        _elapsed += _animationTimer.Interval;
        if (_elapsed >= 520)
        {
            _animationTimer.Stop();
            _displayValue = _finalValue;
            _isRolling = false;
            AccessibleDescription = $"Dice result {_finalValue}";
        }
        else
        {
            var nextValue = Random.Shared.Next(1, 7);
            if (nextValue == _displayValue)
            {
                nextValue = nextValue % 6 + 1;
            }
            _displayValue = nextValue;
        }
        Invalidate();
    }

    private static GraphicsPath RoundedRectangle(RectangleF rectangle, float radius)
    {
        var path = new GraphicsPath();
        var diameter = radius * 2;
        path.AddArc(rectangle.X, rectangle.Y, diameter, diameter, 180, 90);
        path.AddArc(rectangle.Right - diameter, rectangle.Y, diameter, diameter, 270, 90);
        path.AddArc(rectangle.Right - diameter, rectangle.Bottom - diameter, diameter, diameter, 0, 90);
        path.AddArc(rectangle.X, rectangle.Bottom - diameter, diameter, diameter, 90, 90);
        path.CloseFigure();
        return path;
    }
}