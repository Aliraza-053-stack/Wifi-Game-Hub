using System.Drawing.Drawing2D;

namespace WiFiGameHub.Games.Ludo;

public sealed class LudoBoard : Control
{
    private static readonly Point[] Track =
    {
        new(6, 1), new(6, 2), new(6, 3), new(6, 4), new(6, 5), new(5, 6), new(4, 6), new(3, 6), new(2, 6), new(1, 6), new(0, 6), new(0, 7), new(0, 8),
        new(1, 8), new(2, 8), new(3, 8), new(4, 8), new(5, 8), new(6, 9), new(6, 10), new(6, 11), new(6, 12), new(6, 13), new(6, 14), new(7, 14), new(8, 14),
        new(8, 13), new(8, 12), new(8, 11), new(8, 10), new(8, 9), new(9, 8), new(10, 8), new(11, 8), new(12, 8), new(13, 8), new(14, 8), new(14, 7), new(14, 6),
        new(13, 6), new(12, 6), new(11, 6), new(10, 6), new(9, 6), new(8, 5), new(8, 4), new(8, 3), new(8, 2), new(8, 1), new(8, 0), new(7, 0), new(6, 0)
    };

    private static readonly Point[][] HomeLanes =
    {
        new[] { new Point(7, 1), new Point(7, 2), new Point(7, 3), new Point(7, 4), new Point(7, 5) },
        new[] { new Point(1, 7), new Point(2, 7), new Point(3, 7), new Point(4, 7), new Point(5, 7) },
        new[] { new Point(7, 13), new Point(7, 12), new Point(7, 11), new Point(7, 10), new Point(7, 9) },
        new[] { new Point(13, 7), new Point(12, 7), new Point(11, 7), new Point(10, 7), new Point(9, 7) }
    };

    private static readonly int[] StartCells = { 0, 13, 26, 39 };
    private static readonly Point[] BaseOrigins = { new(0, 0), new(0, 9), new(9, 9), new(9, 0) };
    private static readonly Color[] PlayerColors =
    {
        Color.FromArgb(239, 76, 91),
        Color.FromArgb(63, 139, 255),
        Color.FromArgb(61, 190, 130),
        Color.FromArgb(244, 190, 62)
    };
    private static readonly HashSet<int> SafeCells = new() { 0, 8, 13, 21, 26, 34, 39, 47 };

    public LudoGame Game { get; set; } = new();
    public IReadOnlyCollection<int> HighlightedTokens { get; set; } = Array.Empty<int>();
    public event Action<int, int>? TokenSelected;

    public LudoBoard()
    {
        DoubleBuffered = true;
        ResizeRedraw = true;
        BackColor = Color.FromArgb(18, 22, 34);
        MinimumSize = new Size(280, 280);
    }

    protected override void OnPaint(PaintEventArgs e)
    {
        base.OnPaint(e);
        e.Graphics.SmoothingMode = SmoothingMode.AntiAlias;

        if (!TryGetBoardBounds(out var board))
        {
            return;
        }

        var boardSize = board.Width;
        var cell = boardSize / 15f;
        var frame = RectangleF.Inflate(board, cell * 0.36f, cell * 0.36f);
        using (var shadow = new SolidBrush(Color.FromArgb(95, 0, 0, 0)))
        {
            e.Graphics.FillEllipse(shadow, frame.X + cell * 0.3f, frame.Bottom - cell * 0.12f, frame.Width - cell * 0.3f, cell * 0.5f);
        }
        using (var framePath = CreateRoundedRectangle(frame, cell * 0.42f))
        using (var frameBrush = new LinearGradientBrush(frame, Color.FromArgb(54, 46, 82), Color.FromArgb(24, 26, 43), 38f))
        using (var framePen = new Pen(Color.FromArgb(115, 91, 174), Math.Max(1.5f, cell * 0.07f)))
        {
            e.Graphics.FillPath(frameBrush, framePath);
            e.Graphics.DrawPath(framePen, framePath);
        }
        using var boardPath = CreateRoundedRectangle(board, cell * 0.15f);
        using (var boardBrush = new LinearGradientBrush(board, Color.FromArgb(38, 40, 60), Color.FromArgb(26, 28, 44), 35f))
        {
            e.Graphics.FillPath(boardBrush, boardPath);
        }
        var boardState = e.Graphics.Save();
        e.Graphics.SetClip(boardPath);
        using var gridPen = new Pen(Color.FromArgb(98, 119, 144, 178), Math.Max(0.7f, cell * 0.028f));

        for (var playerIndex = 0; playerIndex < 4; playerIndex++)
        {
            DrawBase(e.Graphics, board, cell, playerIndex);
        }

        for (var trackIndex = 0; trackIndex < Track.Length; trackIndex++)
        {
            var position = Track[trackIndex];
            var color = GetPlayerColorForStart(trackIndex);
            DrawCell(e.Graphics, board, cell, position, Color.FromArgb(229, 230, 242));
            if (StartCells.Contains(trackIndex))
            {
                DrawCell(e.Graphics, board, cell, position, color);
            }
            else if (SafeCells.Contains(trackIndex))
            {
                DrawSafeMarker(e.Graphics, board, cell, position);
            }
        }

        for (var playerIndex = 0; playerIndex < 4; playerIndex++)
        {
            foreach (var position in HomeLanes[playerIndex])
            {
                DrawCell(e.Graphics, board, cell, position, Color.FromArgb(217, PlayerColors[playerIndex].R, PlayerColors[playerIndex].G, PlayerColors[playerIndex].B));
            }
        }

        DrawCenter(e.Graphics, board, cell);

        for (var row = 0; row <= 15; row++)
        {
            e.Graphics.DrawLine(gridPen, board.Left, board.Top + row * cell, board.Right, board.Top + row * cell);
            e.Graphics.DrawLine(gridPen, board.Left + row * cell, board.Top, board.Left + row * cell, board.Bottom);
        }

        DrawPlayerBoxes(e.Graphics, board, cell);
        DrawTokens(e.Graphics, board, cell);
        e.Graphics.Restore(boardState);
    }

    protected override void OnMouseClick(MouseEventArgs e)
    {
        base.OnMouseClick(e);
        if (e.Button != MouseButtons.Left)
        {
            return;
        }

        if (!TryGetBoardBounds(out var board))
        {
            return;
        }

        var boardSize = board.Width;
        var cell = boardSize / 15f;
        var activePlayer = Game.CurrentPlayerIndex;
        if (activePlayer < 0 || activePlayer >= Game.Players.Count)
        {
            return;
        }

        for (var tokenIndex = 0; tokenIndex < Game.Players[activePlayer].Tokens.Count; tokenIndex++)
        {
            var center = GetTokenCenter(board, cell, activePlayer, tokenIndex);
            var dx = e.X - center.X;
            var dy = e.Y - center.Y;
            if (dx * dx + dy * dy <= cell * cell * 0.2f)
            {
                TokenSelected?.Invoke(activePlayer, tokenIndex);
                return;
            }
        }
    }

    private bool TryGetBoardBounds(out RectangleF board)
    {
        var boardSize = Math.Min(ClientSize.Width, ClientSize.Height) - 16;
        if (boardSize <= 0)
        {
            board = RectangleF.Empty;
            return false;
        }

        board = new RectangleF(
            (ClientSize.Width - boardSize) / 2f,
            (ClientSize.Height - boardSize) / 2f,
            boardSize,
            boardSize);
        return true;
    }

    private void DrawBase(Graphics graphics, RectangleF board, float cell, int playerIndex)
    {
        var origin = BaseOrigins[playerIndex];
        var area = new RectangleF(board.Left + origin.X * cell, board.Top + origin.Y * cell, cell * 6, cell * 6);
        var corner = cell * 0.42f;
        using var basePath = CreateRoundedRectangle(area, corner);
        using var baseBrush = new LinearGradientBrush(area, ControlPaint.Light(PlayerColors[playerIndex], 0.04f), ControlPaint.Dark(PlayerColors[playerIndex], 0.12f), 40f);
        using var baseOutline = new Pen(Color.FromArgb(170, 255, 255, 255), Math.Max(1f, cell * 0.045f));
        var inner = RectangleF.Inflate(area, -cell * 0.72f, -cell * 0.72f);
        using var innerPath = CreateRoundedRectangle(inner, cell * 0.3f);
        using var innerBrush = new SolidBrush(Color.FromArgb(239, 240, 250));
        graphics.FillPath(baseBrush, basePath);
        graphics.DrawPath(baseOutline, basePath);
        graphics.FillPath(innerBrush, innerPath);
        using var outline = new Pen(Color.FromArgb(210, 255, 255, 255), Math.Max(1.5f, cell * 0.065f));
        foreach (var slot in GetHomeSlots(playerIndex))
        {
            var rect = new RectangleF(board.Left + slot.X * cell + cell * 0.12f, board.Top + slot.Y * cell + cell * 0.12f, cell * 0.76f, cell * 0.76f);
            using var slotFill = new SolidBrush(Color.FromArgb(245, 255, 255, 255));
            using var slotShadow = new Pen(Color.FromArgb(50, 25, 30, 45), Math.Max(1f, cell * 0.03f));
            graphics.FillEllipse(slotFill, rect);
            graphics.DrawEllipse(slotShadow, rect);
            graphics.DrawEllipse(outline, rect);
        }
    }

    private void DrawPlayerBoxes(Graphics graphics, RectangleF board, float cell)
    {
        for (var playerIndex = 0; playerIndex < BaseOrigins.Length; playerIndex++)
        {
            var origin = BaseOrigins[playerIndex];
            var area = new RectangleF(board.Left + origin.X * cell, board.Top + origin.Y * cell, cell * 6, cell * 6);
            var player = Game.Players.ElementAtOrDefault(playerIndex);
            var active = player is not null && !Game.IsGameOver && Game.CurrentPlayerIndex == playerIndex;
            var name = player?.Name ?? "Open seat";

            var badge = new RectangleF(
                area.Left + cell * 0.82f,
                area.Top + cell * 2.58f,
                cell * 4.36f,
                cell * 0.84f);
            using var badgeShadow = new SolidBrush(Color.FromArgb(55, 11, 14, 28));
            using var badgeBrush = new LinearGradientBrush(badge, ControlPaint.Light(PlayerColors[playerIndex], 0.08f), ControlPaint.Dark(PlayerColors[playerIndex], 0.12f), 90f);
            using var badgeOutline = new Pen(active ? Color.White : Color.FromArgb(115, 255, 255, 255), Math.Max(1f, cell * (active ? 0.07f : 0.04f)));
            using var shadowPath = CreateRoundedRectangle(new RectangleF(badge.X, badge.Y + cell * 0.08f, badge.Width, badge.Height), cell * 0.18f);
            using var badgePath = CreateRoundedRectangle(badge, cell * 0.18f);
            graphics.FillPath(badgeShadow, shadowPath);
            graphics.FillPath(badgeBrush, badgePath);
            graphics.DrawPath(badgeOutline, badgePath);

            using var nameFont = CreateFittingFont(graphics, name, badge.Width - cell * 0.55f, Math.Max(7f, cell * 0.27f));
            using var nameBrush = new SolidBrush(Color.White);
            using var nameFormat = new StringFormat
            {
                Alignment = StringAlignment.Center,
                LineAlignment = StringAlignment.Center,
                Trimming = StringTrimming.EllipsisCharacter,
                FormatFlags = StringFormatFlags.NoWrap
            };
            var nameArea = new RectangleF(badge.Left + cell * 0.24f, badge.Top, badge.Width - cell * 0.35f, badge.Height);
            graphics.DrawString(active ? $"{name}  ·  TURN" : name, nameFont, nameBrush, nameArea, nameFormat);

            if (active)
            {
                using var activePen = new Pen(Color.FromArgb(255, 255, 255), Math.Max(2f, cell * 0.12f));
                var highlightArea = RectangleF.Inflate(area, -cell * 0.11f, -cell * 0.11f);
                graphics.DrawRectangle(activePen, highlightArea.X, highlightArea.Y, highlightArea.Width, highlightArea.Height);
            }
        }
    }

    private static GraphicsPath CreateRoundedRectangle(RectangleF rectangle, float radius)
    {
        var path = new GraphicsPath();
        var diameter = radius * 2;
        path.AddArc(rectangle.X, rectangle.Y, diameter, diameter, 180, 90);
        path.AddArc(rectangle.Right - diameter, rectangle.Y, diameter, diameter, 270, 90);
        path.AddArc(rectangle.Right - diameter, rectangle.Bottom - diameter, diameter, diameter, 0, 90);
        path.AddArc(rectangle.X, rectangle.Bottom - diameter, diameter, diameter, 90, 90);
        path.CloseFigure();
        return path;
    }

    private static Font CreateFittingFont(Graphics graphics, string text, float maxWidth, float preferredSize)
    {
        var size = preferredSize;
        var font = new Font("Segoe UI", size, FontStyle.Bold);
        while (size > 7f && graphics.MeasureString(text, font).Width > maxWidth)
        {
            font.Dispose();
            size -= 0.5f;
            font = new Font("Segoe UI", size, FontStyle.Bold);
        }

        return font;
    }

    private void DrawCenter(Graphics graphics, RectangleF board, float cell)
    {
        var center = new PointF(board.Left + 7.5f * cell, board.Top + 7.5f * cell);
        PointF[] points =
        {
            new(board.Left + 6 * cell, board.Top + 6 * cell),
            new(board.Left + 9 * cell, board.Top + 6 * cell),
            new(board.Left + 9 * cell, board.Top + 9 * cell),
            new(board.Left + 6 * cell, board.Top + 9 * cell)
        };
        var topLeft = new PointF(board.Left + 6 * cell, board.Top + 6 * cell);
        var topRight = new PointF(board.Left + 9 * cell, board.Top + 6 * cell);
        var bottomRight = new PointF(board.Left + 9 * cell, board.Top + 9 * cell);
        var bottomLeft = new PointF(board.Left + 6 * cell, board.Top + 9 * cell);
        PointF[] wedges = { topLeft, topRight, center };
        using (var redBrush = new SolidBrush(PlayerColors[0]))
        {
            graphics.FillPolygon(redBrush, wedges);
        }
        wedges = new[] { topRight, bottomRight, center };
        using (var yellowBrush = new SolidBrush(PlayerColors[3]))
        {
            graphics.FillPolygon(yellowBrush, wedges);
        }
        wedges = new[] { bottomRight, bottomLeft, center };
        using (var greenBrush = new SolidBrush(PlayerColors[2]))
        {
            graphics.FillPolygon(greenBrush, wedges);
        }
        wedges = new[] { bottomLeft, topLeft, center };
        using (var blueBrush = new SolidBrush(PlayerColors[1]))
        {
            graphics.FillPolygon(blueBrush, wedges);
        }
        using var centerPen = new Pen(Color.White, Math.Max(1f, cell * 0.045f));
        graphics.DrawPolygon(centerPen, points);
        graphics.DrawLine(centerPen, topLeft, bottomRight);
        graphics.DrawLine(centerPen, topRight, bottomLeft);
    }

    private void DrawTokens(Graphics graphics, RectangleF board, float cell)
    {
        for (var playerIndex = 0; playerIndex < Game.Players.Count; playerIndex++)
        {
            for (var tokenIndex = 0; tokenIndex < Game.Players[playerIndex].Tokens.Count; tokenIndex++)
            {
                var center = GetTokenCenter(board, cell, playerIndex, tokenIndex);
                var radius = cell * 0.29f;
                var bounds = new RectangleF(center.X - radius, center.Y - radius, radius * 2, radius * 2);
                var isHighlighted = playerIndex == Game.CurrentPlayerIndex && HighlightedTokens.Contains(tokenIndex);
                if (isHighlighted)
                {
                    using var halo = new Pen(Color.FromArgb(225, 180, 139, 255), Math.Max(2f, cell * 0.075f));
                    graphics.DrawEllipse(halo, RectangleF.Inflate(bounds, cell * 0.12f, cell * 0.12f));
                }
                using var shadow = new SolidBrush(Color.FromArgb(90, 6, 9, 20));
                using var tokenBrush = new LinearGradientBrush(bounds, ControlPaint.Light(PlayerColors[playerIndex], 0.22f), ControlPaint.Dark(PlayerColors[playerIndex], 0.2f), 40f);
                using var outline = new Pen(Color.FromArgb(235, 250, 250, 255), Math.Max(1.2f, cell * 0.08f));
                using var innerHighlight = new Pen(Color.FromArgb(135, 255, 255, 255), Math.Max(0.8f, cell * 0.035f));
                graphics.FillEllipse(shadow, bounds.X + cell * 0.055f, bounds.Y + cell * 0.095f, bounds.Width, bounds.Height);
                graphics.FillEllipse(tokenBrush, bounds);
                graphics.DrawEllipse(outline, bounds);
                graphics.DrawArc(innerHighlight, bounds.X + radius * 0.18f, bounds.Y + radius * 0.18f, bounds.Width * 0.64f, bounds.Height * 0.64f, 200, 125);
            }
        }
    }

    private static void DrawCell(Graphics graphics, RectangleF board, float cell, Point position, Color color)
    {
        using var brush = new SolidBrush(color);
        graphics.FillRectangle(brush, board.Left + position.X * cell, board.Top + position.Y * cell, cell, cell);
    }

    private static void DrawSafeMarker(Graphics graphics, RectangleF board, float cell, Point position)
    {
        using var marker = new SolidBrush(Color.FromArgb(172, 190, 211));
        var size = cell * 0.22f;
        var centerX = board.Left + (position.X + 0.5f) * cell;
        var centerY = board.Top + (position.Y + 0.5f) * cell;
        graphics.FillEllipse(marker, centerX - size / 2f, centerY - size / 2f, size, size);
    }

    private PointF GetTokenCenter(RectangleF board, float cell, int playerIndex, int tokenIndex)
    {
        var token = Game.Players[playerIndex].Tokens[tokenIndex];
        Point position;
        if (token.Position < 0)
        {
            var slot = GetHomeSlots(playerIndex)[tokenIndex];
            position = slot;
        }
        else if (token.Position < LudoGame.TrackCellCount)
        {
            var trackIndex = (StartCells[playerIndex] + token.Position) % LudoGame.TrackCellCount;
            position = Track[trackIndex];
        }
        else if (token.Position < LudoGame.FinishPosition)
        {
            position = HomeLanes[playerIndex][token.Position - LudoGame.TrackCellCount];
        }
        else
        {
            position = new Point(7, 7);
        }

        var spread = token.Position is < 0 or >= LudoGame.FinishPosition ? 0f : ((tokenIndex % 4) - 1.5f) * cell * 0.08f;
        return new PointF(board.Left + (position.X + 0.5f) * cell + spread, board.Top + (position.Y + 0.5f) * cell + spread);
    }

    private static Point[] GetHomeSlots(int playerIndex)
    {
        var origin = BaseOrigins[playerIndex];
        return new[]
        {
            new Point(origin.X + 1, origin.Y + 1), new Point(origin.X + 4, origin.Y + 1),
            new Point(origin.X + 1, origin.Y + 4), new Point(origin.X + 4, origin.Y + 4)
        };
    }

    private static Color GetPlayerColorForStart(int trackIndex)
    {
        for (var playerIndex = 0; playerIndex < StartCells.Length; playerIndex++)
        {
            if (StartCells[playerIndex] == trackIndex)
            {
                return PlayerColors[playerIndex];
            }
        }

        return Color.White;
    }
}