namespace WiFiGameHub.Games.Ludo;

public class LudoToken
{
    public int TokenIndex { get; set; }
    public int Position { get; set; } = -1;
    public bool IsAtHome => Position < 0;

    public void Reset()
    {
        Position = -1;
    }
}

public class LudoPlayer
{
    public string Color { get; set; } = "Red";
    public string Name { get; set; } = "Player";
    public bool IsActive { get; set; } = true;
    public List<LudoToken> Tokens { get; } = Enumerable.Range(0, 4).Select(i => new LudoToken { TokenIndex = i }).ToList();
    public bool HasWon => Tokens.All(token => token.Position == LudoGame.FinishPosition);
}

public class LudoGame
{
    public const int TrackCellCount = 52;
    public const int FinishPosition = 57;
    public const int BoardLength = FinishPosition + 1;
    public const int SafeCellCount = 8;

    private static readonly HashSet<int> SafeCells = new()
    {
        0, 8, 13, 21, 26, 34, 39, 47
    };
    private static readonly string[] PlayerColors = { "Red", "Blue", "Green", "Yellow" };
    private static readonly int[] StartCells = { 0, 13, 26, 39 };
    private readonly Func<int> _diceRoller;

    public List<LudoPlayer> Players { get; } = new();
    public int CurrentPlayerIndex { get; private set; }
    public int LastDiceValue { get; private set; }
    public int LastDiceResult { get; private set; }
    public bool IsGameOver { get; private set; }
    public string Winner { get; private set; } = string.Empty;
    public List<string> MoveHistory { get; } = new();

    public LudoGame(
        int playerCount = 4,
        Func<int>? diceRoller = null,
        IReadOnlyList<string>? playerNames = null,
        IReadOnlyList<string>? playerColors = null)
    {
        if (playerCount is < 2 or > 4)
        {
            throw new ArgumentOutOfRangeException(nameof(playerCount), "Ludo supports two to four players.");
        }

        if (playerNames is not null && playerNames.Count != playerCount)
        {
            throw new ArgumentException("Provide one name for each player.", nameof(playerNames));
        }
        if (playerColors is not null
            && (playerColors.Count != playerCount
                || playerColors.Any(color => !PlayerColors.Contains(color, StringComparer.Ordinal))
                || playerColors.Distinct(StringComparer.Ordinal).Count() != playerCount))
        {
            throw new ArgumentException("Provide one unique supported color for each player.", nameof(playerColors));
        }

        _diceRoller = diceRoller ?? (() => Random.Shared.Next(1, 7));
        for (var index = 0; index < playerCount; index++)
        {
            Players.Add(new LudoPlayer
            {
                Color = playerColors?[index] ?? PlayerColors[index],
                Name = string.IsNullOrWhiteSpace(playerNames?[index]) ? playerColors?[index] ?? PlayerColors[index] : playerNames[index]
            });
        }
    }

    public int RollDice()
    {
        if (IsGameOver || LastDiceValue > 0)
        {
            return LastDiceValue;
        }

        var value = _diceRoller();
        if (value is < 1 or > 6)
        {
            throw new InvalidOperationException("The dice roller must return a value from 1 to 6.");
        }

        LastDiceValue = value;
        LastDiceResult = value;
        if (!Players[CurrentPlayerIndex].Tokens.Any(token => CanMoveToken(CurrentPlayerIndex, token.TokenIndex)))
        {
            MoveHistory.Add($"{Players[CurrentPlayerIndex].Name} rolled {value} and had no legal move.");
            AdvanceTurn();
        }

        return value;
    }

    public bool CanMoveToken(int playerIndex, int tokenIndex)
    {
        if (playerIndex < 0 || playerIndex >= Players.Count)
        {
            return false;
        }

        if (tokenIndex < 0 || tokenIndex >= Players[playerIndex].Tokens.Count)
        {
            return false;
        }

        if (playerIndex != CurrentPlayerIndex || IsGameOver || LastDiceValue <= 0)
        {
            return false;
        }

        var token = Players[playerIndex].Tokens[tokenIndex];
        if (token.IsAtHome)
        {
            return LastDiceValue == 6;
        }

        if (token.Position >= FinishPosition)
        {
            return false;
        }

        return token.Position + LastDiceValue <= FinishPosition;
    }

    public bool MoveToken(int playerIndex, int tokenIndex)
    {
        if (!CanMoveToken(playerIndex, tokenIndex))
        {
            return false;
        }

        var player = Players[playerIndex];
        var token = player.Tokens[tokenIndex];

        if (token.IsAtHome)
        {
            token.Position = 0;
            MoveHistory.Add($"{player.Color} token {tokenIndex + 1} entered board.");
            CompleteMove();
            return true;
        }

        token.Position += LastDiceValue;

        MoveHistory.Add($"{player.Name} moved {player.Color} token {tokenIndex + 1} to {token.Position}.");

        var cutResult = TryCutOpponent(playerIndex, token);
        if (cutResult)
        {
            MoveHistory.Add($"{player.Color} cut an opponent on a non-safe cell.");
        }

        if (player.HasWon)
        {
            IsGameOver = true;
            Winner = player.Name;
            LastDiceValue = 0;
            MoveHistory.Add($"{Winner} won the game.");
            return true;
        }

        CompleteMove();
        return true;
    }

    public bool HasLegalMove(int playerIndex)
    {
        return playerIndex >= 0
            && playerIndex < Players.Count
            && Players[playerIndex].IsActive
            && playerIndex == CurrentPlayerIndex
            && LastDiceValue > 0
            && Players[playerIndex].Tokens.Any(token => CanMoveToken(playerIndex, token.TokenIndex));
    }

    public int? GetTrackCell(int playerIndex, int tokenIndex)
    {
        if (playerIndex < 0 || playerIndex >= Players.Count || tokenIndex < 0 || tokenIndex >= Players[playerIndex].Tokens.Count)
        {
            return null;
        }

        var position = Players[playerIndex].Tokens[tokenIndex].Position;
        var colorIndex = Array.IndexOf(PlayerColors, Players[playerIndex].Color);
        if (colorIndex < 0)
        {
            return null;
        }
        return position is >= 0 and < TrackCellCount
            ? (StartCells[colorIndex] + position) % TrackCellCount
            : null;
    }

    public void RestoreState(
        IReadOnlyList<int> tokenPositions,
        int currentPlayerIndex,
        int diceValue,
        int lastDiceResult,
        bool isGameOver,
        string winner,
        IReadOnlyList<string> moveHistory,
        IReadOnlyList<bool>? activePlayers = null)
    {
        if (tokenPositions.Count != Players.Count * 4
            || currentPlayerIndex < 0
            || currentPlayerIndex >= Players.Count
            || diceValue is < 0 or > 6
            || lastDiceResult is < 0 or > 6
            || (activePlayers is not null && activePlayers.Count != Players.Count)
            || tokenPositions.Any(position => position < -1 || position > FinishPosition))
        {
            throw new ArgumentException("The Ludo snapshot is invalid.", nameof(tokenPositions));
        }

        for (var index = 0; index < tokenPositions.Count; index++)
        {
            Players[index / 4].Tokens[index % 4].Position = tokenPositions[index];
        }
        if (activePlayers is not null)
        {
            for (var index = 0; index < Players.Count; index++)
            {
                Players[index].IsActive = activePlayers[index];
            }
        }

        CurrentPlayerIndex = currentPlayerIndex;
        LastDiceValue = diceValue;
        LastDiceResult = lastDiceResult;
        IsGameOver = isGameOver;
        Winner = winner;
        MoveHistory.Clear();
        MoveHistory.AddRange(moveHistory);
    }

    public void SetPlayerActive(int playerIndex, bool isActive)
    {
        if (playerIndex < 0 || playerIndex >= Players.Count)
        {
            throw new ArgumentOutOfRangeException(nameof(playerIndex));
        }

        Players[playerIndex].IsActive = isActive;
        if (!isActive && playerIndex == CurrentPlayerIndex)
        {
            LastDiceValue = 0;
            AdvanceTurn();
        }
    }

    public void EndByForfeit(string winnerName)
    {
        if (string.IsNullOrWhiteSpace(winnerName))
        {
            throw new ArgumentException("A winner name is required.", nameof(winnerName));
        }

        if (IsGameOver)
        {
            return;
        }

        IsGameOver = true;
        Winner = winnerName;
        LastDiceValue = 0;
        MoveHistory.Add($"{Winner} won by forfeit.");
    }

    public void ResetGame()
    {
        foreach (var player in Players)
        {
            foreach (var token in player.Tokens)
            {
                token.Reset();
            }
        }

        CurrentPlayerIndex = 0;
        LastDiceValue = 0;
        LastDiceResult = 0;
        IsGameOver = false;
        Winner = string.Empty;
        MoveHistory.Clear();
    }

    private void AdvanceTurn()
    {
        for (var attempts = 0; attempts < Players.Count; attempts++)
        {
            CurrentPlayerIndex = (CurrentPlayerIndex + 1) % Players.Count;
            if (Players[CurrentPlayerIndex].IsActive)
            {
                break;
            }
        }
        LastDiceValue = 0;
    }

    private void CompleteMove()
    {
        var rolledSix = LastDiceValue == 6;
        LastDiceValue = 0;
        if (!rolledSix)
        {
            AdvanceTurn();
        }
    }

    private bool TryCutOpponent(int currentPlayerIndex, LudoToken token)
    {
        var trackCell = GetTrackCell(currentPlayerIndex, token.TokenIndex);
        if (trackCell is null || SafeCells.Contains(trackCell.Value))
        {
            return false;
        }

        foreach (var opponent in Players.Where((player, index) => index != currentPlayerIndex && player.IsActive))
        {
            foreach (var opponentToken in opponent.Tokens)
            {
                var opponentIndex = opponent.Tokens.IndexOf(opponentToken);
                if (GetTrackCell(Players.IndexOf(opponent), opponentIndex) == trackCell)
                {
                    opponentToken.Position = -1;
                    return true;
                }
            }
        }

        return false;
    }
}
