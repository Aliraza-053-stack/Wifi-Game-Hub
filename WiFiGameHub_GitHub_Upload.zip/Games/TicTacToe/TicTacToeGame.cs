namespace WiFiGameHub.Games.TicTacToe;

public enum TicTacToeMark
{
    Empty,
    X,
    O
}

public class TicTacToeGame
{
    public const int BoardSize = 3;

    public TicTacToeMark[,] Board { get; private set; } = new TicTacToeMark[BoardSize, BoardSize];
    public string CurrentPlayer { get; private set; } = "X";
    public bool IsGameOver { get; private set; }
    public string Winner { get; private set; } = string.Empty;
    public bool IsDraw { get; private set; }
    public List<(int Row, int Col)> WinningLine { get; private set; } = new();
    public List<string> MoveHistory { get; } = new();
    public int XScore { get; private set; }
    public int OScore { get; private set; }

    public TicTacToeGame()
    {
        ResetBoard();
    }

    public void ResetBoard()
    {
        for (var row = 0; row < BoardSize; row++)
        {
            for (var col = 0; col < BoardSize; col++)
            {
                Board[row, col] = TicTacToeMark.Empty;
            }
        }

        CurrentPlayer = "X";
        IsGameOver = false;
        Winner = string.Empty;
        IsDraw = false;
        WinningLine.Clear();
        MoveHistory.Clear();
    }

    public bool MakeMove(int row, int col, string playerName)
    {
        if (IsGameOver)
        {
            return false;
        }

        if (row < 0 || row >= BoardSize || col < 0 || col >= BoardSize)
        {
            return false;
        }

        if (!string.Equals(playerName, CurrentPlayer, StringComparison.OrdinalIgnoreCase))
        {
            return false;
        }

        if (Board[row, col] != TicTacToeMark.Empty)
        {
            return false;
        }

        Board[row, col] = playerName.Equals("X", StringComparison.OrdinalIgnoreCase) ? TicTacToeMark.X : TicTacToeMark.O;
        MoveHistory.Add($"{playerName} -> ({row},{col})");

        var winningCells = GetWinningLine(row, col, Board[row, col]);
        if (winningCells.Count > 0)
        {
            Winner = playerName;
            IsGameOver = true;
            WinningLine = winningCells;
            if (Winner == "X")
            {
                XScore++;
            }
            else if (Winner == "O")
            {
                OScore++;
            }

            return true;
        }

        if (IsBoardFull())
        {
            IsDraw = true;
            IsGameOver = true;
            WinningLine.Clear();
            return true;
        }

        CurrentPlayer = CurrentPlayer == "X" ? "O" : "X";
        return true;
    }

    public void NewMatch()
    {
        ResetBoard();
        XScore = 0;
        OScore = 0;
    }

    public void RestoreState(
        IReadOnlyList<TicTacToeMark> board,
        string currentPlayer,
        bool isGameOver,
        string winner,
        bool isDraw,
        int xScore,
        int oScore,
        IReadOnlyList<(int Row, int Col)> winningLine)
    {
        if (board.Count != BoardSize * BoardSize
            || (currentPlayer != "X" && currentPlayer != "O")
            || xScore < 0
            || oScore < 0
            || board.Any(mark => !Enum.IsDefined(mark)))
        {
            throw new ArgumentException("The Tic Tac Toe snapshot is invalid.", nameof(board));
        }

        for (var index = 0; index < board.Count; index++)
        {
            Board[index / BoardSize, index % BoardSize] = board[index];
        }

        CurrentPlayer = currentPlayer;
        IsGameOver = isGameOver;
        Winner = winner;
        IsDraw = isDraw;
        XScore = xScore;
        OScore = oScore;
        WinningLine = winningLine.ToList();
        MoveHistory.Clear();
    }

    private bool HasWinner(int row, int col, TicTacToeMark mark)
    {
        return GetWinningLine(row, col, mark).Count > 0;
    }

    private List<(int Row, int Col)> GetWinningLine(int row, int col, TicTacToeMark mark)
    {
        var winningLine = new List<(int Row, int Col)>();

        var rowMatches = true;
        for (var i = 0; i < BoardSize; i++)
        {
            if (Board[row, i] != mark)
            {
                rowMatches = false;
                break;
            }
        }
        if (rowMatches)
        {
            for (var i = 0; i < BoardSize; i++)
            winningLine.Add((row, i));
            return winningLine;
        }

        var colMatches = true;
        for (var i = 0; i < BoardSize; i++)
        {
            if (Board[i, col] != mark)
            {
                colMatches = false;
                break;
            }
        }
        if (colMatches)
        {
            for (var i = 0; i < BoardSize; i++)
                winningLine.Add((i, col));
            return winningLine;
        }

        if (row == col)
        {
            var primaryDiagonalMatches = true;
            for (var i = 0; i < BoardSize; i++)
            {
                if (Board[i, i] != mark)
                {
                    primaryDiagonalMatches = false;
                    break;
                }
            }

            if (primaryDiagonalMatches)
            {
                for (var i = 0; i < BoardSize; i++)
                    winningLine.Add((i, i));
                return winningLine;
            }
        }

        if (row + col == BoardSize - 1)
        {
            var secondaryDiagonalMatches = true;
            for (var i = 0; i < BoardSize; i++)
            {
                if (Board[i, BoardSize - 1 - i] != mark)
                {
                    secondaryDiagonalMatches = false;
                    break;
                }
            }

            if (secondaryDiagonalMatches)
            {
                for (var i = 0; i < BoardSize; i++)
                    winningLine.Add((i, BoardSize - 1 - i));
                return winningLine;
            }
        }

        return winningLine;
    }

    private bool IsBoardFull()
    {
        for (var row = 0; row < BoardSize; row++)
        {
            for (var col = 0; col < BoardSize; col++)
            {
                if (Board[row, col] == TicTacToeMark.Empty)
                {
                    return false;
                }
            }
        }

        return true;
    }
}
