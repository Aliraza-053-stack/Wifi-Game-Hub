namespace WiFiGameHub.Games.Carrom;

public sealed record CarromRulesOptions(
    int CoinPointValue = 1,
    int QueenBonus = 3,
    int MatchTargetScore = 25,
    int MaximumBoards = 8);

public sealed record CarromRuleResult(
    bool IsFoul,
    string? FoulReason,
    bool OwnCoinPocketed,
    bool QueenClaimed,
    bool QueenReturned,
    bool BoardCompleted,
    bool MatchCompleted,
    int? BoardWinnerIndex,
    int? MatchWinnerIndex,
    int WhiteScore,
    int BlackScore);

public sealed class CarromRulesEngine
{
    private readonly CarromRulesOptions _options;
    private readonly HashSet<int> _processedShots = new();
    private readonly int[] _scores = new int[2];
    private readonly int[] _fouls = new int[2];
    private readonly int[] _pocketedCoins = new int[2];
    private readonly int[] _totalPocketedCoins = new int[2];
    private readonly int[] _queenBonuses = new int[2];

    public int CurrentPlayerIndex { get; private set; }
    public int CompletedBoards { get; private set; }
    public int? QueenPendingCoverByPlayer { get; private set; }
    public int? QueenClaimedByPlayer { get; private set; }
    public bool QueenClaimed { get; private set; }
    public bool IsBoardComplete { get; private set; }
    public bool IsMatchComplete { get; private set; }
    public int? MatchWinnerIndex { get; private set; }
    public int LastProcessedShotNumber { get; private set; }
    public IReadOnlyList<int> Scores => _scores;
    public IReadOnlyList<int> Fouls => _fouls;
    public IReadOnlyList<int> PocketedCoins => _pocketedCoins;
    public IReadOnlyList<int> TotalPocketedCoins => _totalPocketedCoins;
    public IReadOnlyList<int> QueenBonuses => _queenBonuses;
    public CarromRulesOptions Options => _options;

    public CarromRulesEngine(CarromRulesOptions? options = null)
    {
        _options = options ?? new CarromRulesOptions();
        if (_options.CoinPointValue <= 0 || _options.QueenBonus < 0
            || _options.MatchTargetScore <= 0 || _options.MaximumBoards <= 0)
        {
            throw new ArgumentOutOfRangeException(nameof(options), "Carrom scoring values and match limits must be positive.");
        }
    }

    public bool TryProcessShot(CarromPhysicsEngine board, CarromShotResult result, out CarromRuleResult? ruleResult)
    {
        ArgumentNullException.ThrowIfNull(board);
        ArgumentNullException.ThrowIfNull(result);
        ruleResult = null;
        if (result.ShotNumber != LastProcessedShotNumber + 1 || !_processedShots.Add(result.ShotNumber))
        {
            return false;
        }
        if (IsBoardComplete || IsMatchComplete)
        {
            _processedShots.Remove(result.ShotNumber);
            return false;
        }

        LastProcessedShotNumber = result.ShotNumber;
        var player = CurrentPlayerIndex;
        var ownType = player == 0 ? CarromPieceType.White : CarromPieceType.Black;
        var opponentType = player == 0 ? CarromPieceType.Black : CarromPieceType.White;
        var ownPocketed = result.PocketedPieces.Where(piece => piece.Type == ownType).ToArray();
        var queenPocketed = result.PocketedPieces.Any(piece => piece.Type == CarromPieceType.Queen);
        var foul = result.StrikerFoul;
        var queenReturned = false;
        var queenClaimedThisShot = false;
        string? foulReason = foul ? "The striker was pocketed." : null;

        if (foul)
        {
            _fouls[player]++;
            foreach (var piece in result.PocketedPieces)
            {
                board.ReturnPieceToBoard(piece.Id);
            }
            if (QueenPendingCoverByPlayer == player || queenPocketed)
            {
                if (QueenPendingCoverByPlayer == player && !queenPocketed)
                {
                    board.ReturnPocketedPiece(CarromPieceType.Queen);
                }
                QueenPendingCoverByPlayer = null;
                QueenClaimed = false;
                QueenClaimedByPlayer = null;
                queenReturned = true;
            }
        }
        else
        {
            foreach (var piece in result.PocketedPieces.Where(piece => piece.Type == opponentType))
            {
                board.ReturnPieceToBoard(piece.Id);
            }

            var eligibleBeforeShot = _pocketedCoins[player] > 0;
            _pocketedCoins[player] += ownPocketed.Length;
            _totalPocketedCoins[player] += ownPocketed.Length;
            var ownCoinPocketed = ownPocketed.Length > 0;

            if (QueenPendingCoverByPlayer is int pendingPlayer)
            {
                if (pendingPlayer == player && ownCoinPocketed)
                {
                    QueenClaimed = true;
                    QueenClaimedByPlayer = player;
                    QueenPendingCoverByPlayer = null;
                    queenClaimedThisShot = true;
                }
                else
                {
                    board.ReturnPocketedPiece(CarromPieceType.Queen);
                    QueenPendingCoverByPlayer = null;
                    queenReturned = true;
                }
            }

            if (queenPocketed && !queenClaimedThisShot)
            {
                if (!eligibleBeforeShot)
                {
                    board.ReturnPocketedPiece(CarromPieceType.Queen);
                    queenReturned = true;
                }
                else if (ownCoinPocketed)
                {
                    QueenClaimed = true;
                    QueenClaimedByPlayer = player;
                    queenClaimedThisShot = true;
                }
                else
                {
                    QueenPendingCoverByPlayer = player;
                }
            }

            if (ownCoinPocketed || QueenPendingCoverByPlayer == player)
            {
                ruleResult = CompleteBoardIfNeeded(board, player, foul, foulReason, ownCoinPocketed,
                    queenClaimedThisShot, queenReturned);
                return true;
            }
        }

        CurrentPlayerIndex = (CurrentPlayerIndex + 1) % 2;
        ruleResult = CompleteBoardIfNeeded(board, player, foul, foulReason, false,
            queenClaimedThisShot, queenReturned);
        return true;
    }

    public void RestoreState(
        int currentPlayerIndex,
        int completedBoards,
        int whiteScore,
        int blackScore,
        int whiteFouls,
        int blackFouls,
        int whitePocketedCoins,
        int blackPocketedCoins,
        int whiteTotalPocketedCoins,
        int blackTotalPocketedCoins,
        int whiteQueenBonuses,
        int blackQueenBonuses,
        int? queenPendingCoverByPlayer,
        bool queenClaimed,
        int? queenClaimedByPlayer,
        bool isBoardComplete,
        bool isMatchComplete,
        int? matchWinnerIndex,
        int lastProcessedShotNumber)
    {
        if (currentPlayerIndex is < 0 or > 1 || completedBoards < 0
            || whiteScore < 0 || blackScore < 0 || whiteFouls < 0 || blackFouls < 0
            || whitePocketedCoins is < 0 or > 9 || blackPocketedCoins is < 0 or > 9
            || whiteTotalPocketedCoins < whitePocketedCoins || blackTotalPocketedCoins < blackPocketedCoins
            || whiteQueenBonuses < 0 || blackQueenBonuses < 0
            || queenPendingCoverByPlayer is < 0 or > 1
            || queenClaimedByPlayer is < 0 or > 1
            || matchWinnerIndex is < 0 or > 1
            || lastProcessedShotNumber < 0
            || (queenClaimed && queenPendingCoverByPlayer.HasValue)
            || (queenClaimed && !queenClaimedByPlayer.HasValue)
            || (!queenClaimed && queenClaimedByPlayer.HasValue)
            || (isMatchComplete && !matchWinnerIndex.HasValue && whiteScore != blackScore))
        {
            throw new ArgumentOutOfRangeException(nameof(currentPlayerIndex), "Carrom rules snapshot is invalid.");
        }

        CurrentPlayerIndex = currentPlayerIndex;
        CompletedBoards = completedBoards;
        _scores[0] = whiteScore;
        _scores[1] = blackScore;
        _fouls[0] = whiteFouls;
        _fouls[1] = blackFouls;
        _pocketedCoins[0] = whitePocketedCoins;
        _pocketedCoins[1] = blackPocketedCoins;
        _totalPocketedCoins[0] = whiteTotalPocketedCoins;
        _totalPocketedCoins[1] = blackTotalPocketedCoins;
        _queenBonuses[0] = whiteQueenBonuses;
        _queenBonuses[1] = blackQueenBonuses;
        QueenPendingCoverByPlayer = queenPendingCoverByPlayer;
        QueenClaimed = queenClaimed;
        QueenClaimedByPlayer = queenClaimedByPlayer;
        IsBoardComplete = isBoardComplete;
        IsMatchComplete = isMatchComplete;
        MatchWinnerIndex = matchWinnerIndex;
        LastProcessedShotNumber = lastProcessedShotNumber;
    }

    public void BeginNextBoard(int openingPlayerIndex)
    {
        if (!IsBoardComplete || IsMatchComplete || openingPlayerIndex is < 0 or > 1)
        {
            throw new InvalidOperationException("The next board cannot be started in the current match state.");
        }

        CurrentPlayerIndex = openingPlayerIndex;
        QueenPendingCoverByPlayer = null;
        QueenClaimedByPlayer = null;
        QueenClaimed = false;
        IsBoardComplete = false;
        Array.Clear(_pocketedCoins);
        _processedShots.Clear();
        LastProcessedShotNumber = 0;
    }

    public void Reset()
    {
        CurrentPlayerIndex = 0;
        CompletedBoards = 0;
        QueenPendingCoverByPlayer = null;
        QueenClaimedByPlayer = null;
        QueenClaimed = false;
        IsBoardComplete = false;
        IsMatchComplete = false;
        MatchWinnerIndex = null;
        LastProcessedShotNumber = 0;
        Array.Clear(_scores);
        Array.Clear(_fouls);
        Array.Clear(_pocketedCoins);
        Array.Clear(_totalPocketedCoins);
        Array.Clear(_queenBonuses);
        _processedShots.Clear();
    }

    private CarromRuleResult CompleteBoardIfNeeded(
        CarromPhysicsEngine board,
        int shooter,
        bool foul,
        string? foulReason,
        bool ownCoinPocketed,
        bool queenClaimedThisShot,
        bool queenReturned)
    {
        var ownType = shooter == 0 ? CarromPieceType.White : CarromPieceType.Black;
        var ownCoinsRemain = board.Pieces.Any(piece => piece.IsActive && piece.Type == ownType);
        if (!foul && !ownCoinsRemain && !QueenPendingCoverByPlayer.HasValue)
        {
            IsBoardComplete = true;
            CompletedBoards++;
            var opponentType = shooter == 0 ? CarromPieceType.Black : CarromPieceType.White;
            var opponentCoinsRemain = board.Pieces.Count(piece => piece.IsActive && piece.Type == opponentType);
            _scores[shooter] += opponentCoinsRemain * _options.CoinPointValue;
            if (QueenClaimed && QueenClaimedByPlayer == shooter)
            {
                _scores[shooter] += _options.QueenBonus;
                _queenBonuses[shooter] += _options.QueenBonus;
            }

            QueenPendingCoverByPlayer = null;
            if (_scores[shooter] >= _options.MatchTargetScore || CompletedBoards >= _options.MaximumBoards)
            {
                IsMatchComplete = true;
                MatchWinnerIndex = _scores[0] == _scores[1] ? null : _scores[0] > _scores[1] ? 0 : 1;
            }
        }

        return new CarromRuleResult(foul, foulReason, ownCoinPocketed, queenClaimedThisShot,
            queenReturned, IsBoardComplete, IsMatchComplete, IsBoardComplete ? shooter : null,
            MatchWinnerIndex, _scores[0], _scores[1]);
    }
}
