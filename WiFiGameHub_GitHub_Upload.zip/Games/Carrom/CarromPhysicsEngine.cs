using System.Numerics;

namespace WiFiGameHub.Games.Carrom;

public enum CarromPieceType
{
    Striker,
    Black,
    White,
    Queen
}

public sealed record CarromPieceDefinition(
    int Id,
    CarromPieceType Type,
    Vector2 Position,
    float Radius,
    float Mass,
    Vector2 InitialVelocity = default);

public sealed class CarromPiece
{
    internal CarromPiece(CarromPieceDefinition definition)
    {
        Id = definition.Id;
        Type = definition.Type;
        Position = definition.Position;
        Velocity = definition.InitialVelocity;
        Radius = definition.Radius;
        Mass = definition.Mass;
    }

    public int Id { get; }
    public CarromPieceType Type { get; }
    public Vector2 Position { get; internal set; }
    public Vector2 Velocity { get; internal set; }
    public float Radius { get; }
    public float Mass { get; }
    public bool IsActive { get; internal set; } = true;
}

public sealed record CarromShotResult(
    int ShotNumber,
    IReadOnlyList<CarromPocketedPiece> PocketedPieces,
    bool StrikerFoul);

public sealed record CarromPocketedPiece(int Id, CarromPieceType Type, Vector2 Position);
public sealed record CarromPieceSnapshot(int Id, CarromPieceType Type, float X, float Y, bool IsActive);

public sealed class CarromGameState
{
    private readonly List<CarromPieceType> _pocketedHistory = new();

    public int CurrentPlayerIndex { get; private set; }
    public int ShotsTaken { get; private set; }
    public bool IsShotInProgress { get; private set; }
    public bool LastShotWasFoul { get; private set; }
    public IReadOnlyList<CarromPieceType> PocketedHistory => _pocketedHistory;

    public void BeginShot()
    {
        if (IsShotInProgress)
        {
            throw new InvalidOperationException("A Carrom shot is already in progress.");
        }

        IsShotInProgress = true;
        LastShotWasFoul = false;
    }

    public void CompleteShot(CarromShotResult result)
    {
        ArgumentNullException.ThrowIfNull(result);
        if (!IsShotInProgress)
        {
            throw new InvalidOperationException("There is no Carrom shot to complete.");
        }

        _pocketedHistory.AddRange(result.PocketedPieces.Select(piece => piece.Type));
        ShotsTaken = result.ShotNumber;
        LastShotWasFoul = result.StrikerFoul;
        CurrentPlayerIndex = (CurrentPlayerIndex + 1) % 2;
        IsShotInProgress = false;
    }

    public void Reset()
    {
        CurrentPlayerIndex = 0;
        ShotsTaken = 0;
        IsShotInProgress = false;
        LastShotWasFoul = false;
        _pocketedHistory.Clear();
    }
}

public sealed class CarromPhysicsEngine
{
    public const float BoardMinimum = 126F;
    public const float BoardMaximum = 874F;
    public const float StrikerBaselineY = 812F;
    public const float MinimumStrikerX = 240F;
    public const float MaximumStrikerX = 760F;
    public const float MaximumShotSpeed = 1450F;
    public const float FixedStepSeconds = 1F / 120F;

    private const float FrictionDeceleration = 520F;
    private const float StopSpeed = 3.2F;
    private const float PieceRestitution = 0.88F;
    private const float WallRestitution = 0.82F;
    private const float PositionCorrectionPercent = 0.82F;
    private const float PositionSlop = 0.05F;
    private const float MaximumPullDistance = 220F;
    private const float MinimumPullDistance = 12F;
    private const float StrikerRadius = 36F;
    private readonly CarromPieceDefinition[] _initialPieces;
    private readonly List<CarromPiece> _pieces = new();
    private readonly List<CarromPocketedPiece> _pocketedThisShot = new();
    private double _accumulator;
    private bool _strikerPocketedThisShot;
    private int _shotNumber;

    public IReadOnlyList<CarromPiece> Pieces => _pieces;
    public CarromPiece Striker => _pieces.Single(piece => piece.Type == CarromPieceType.Striker);
    public int ShotNumber => _shotNumber;
    public bool IsShotInProgress { get; private set; }
    public bool IsMoving => _pieces.Any(piece => piece.IsActive && piece.Velocity.LengthSquared() > StopSpeed * StopSpeed);
    public event Action<CarromPiece>? PiecePocketed;

    public CarromPhysicsEngine(IEnumerable<CarromPieceDefinition>? initialPieces = null)
    {
        _initialPieces = (initialPieces ?? CreateDefaultLayout()).ToArray();
        ValidateDefinitions(_initialPieces);
        Reset();
    }

    public void Reset()
    {
        _pieces.Clear();
        _pieces.AddRange(_initialPieces.Select(definition => new CarromPiece(definition)));
        _pocketedThisShot.Clear();
        _accumulator = 0;
        _strikerPocketedThisShot = false;
        _shotNumber = 0;
        IsShotInProgress = false;
    }

    public CarromPieceSnapshot[] CreateSnapshot() =>
        _pieces.Select(piece => new CarromPieceSnapshot(
            piece.Id, piece.Type, piece.Position.X, piece.Position.Y, piece.IsActive)).ToArray();

    public void RestoreSnapshot(IEnumerable<CarromPieceSnapshot> snapshots, int shotNumber)
    {
        ArgumentNullException.ThrowIfNull(snapshots);
        var snapshotArray = snapshots.ToArray();
        if (shotNumber < 0 || snapshotArray.Length != _pieces.Count
            || snapshotArray.Select(piece => piece.Id).Distinct().Count() != snapshotArray.Length)
        {
            throw new ArgumentException("Carrom board snapshot has an invalid shape or shot number.", nameof(snapshots));
        }

        foreach (var snapshot in snapshotArray)
        {
            var piece = _pieces.SingleOrDefault(candidate => candidate.Id == snapshot.Id);
            if (piece is null || piece.Type != snapshot.Type
                || !float.IsFinite(snapshot.X) || !float.IsFinite(snapshot.Y)
                || snapshot.X < BoardMinimum || snapshot.X > BoardMaximum
                || snapshot.Y < BoardMinimum || snapshot.Y > BoardMaximum)
            {
                throw new ArgumentException("Carrom board snapshot contains an invalid piece.", nameof(snapshots));
            }
        }

        if (!snapshotArray.Any(piece => piece.Type == CarromPieceType.Striker && piece.IsActive))
        {
            throw new ArgumentException("Carrom board snapshot must contain an active striker.", nameof(snapshots));
        }

        foreach (var snapshot in snapshotArray)
        {
            var piece = _pieces.Single(candidate => candidate.Id == snapshot.Id);
            piece.Position = new Vector2(snapshot.X, snapshot.Y);
            piece.Velocity = Vector2.Zero;
            piece.IsActive = snapshot.IsActive;
        }

        _shotNumber = shotNumber;
        _accumulator = 0;
        _pocketedThisShot.Clear();
        _strikerPocketedThisShot = false;
        IsShotInProgress = false;
    }

    public bool ReturnPieceToBoard(int pieceId)
    {
        var piece = _pieces.SingleOrDefault(candidate => candidate.Id == pieceId);
        if (piece is null || piece.IsActive)
        {
            return false;
        }

        piece.Position = FindRespotPosition(piece);
        piece.Velocity = Vector2.Zero;
        piece.IsActive = true;
        return true;
    }

    public bool ReturnPocketedPiece(CarromPieceType type)
    {
        var piece = _pieces.FirstOrDefault(candidate => candidate.Type == type && !candidate.IsActive);
        return piece is not null && ReturnPieceToBoard(piece.Id);
    }

    public bool TryPlaceStriker(float x)
    {
        if (!float.IsFinite(x))
        {
            throw new ArgumentOutOfRangeException(nameof(x), "Striker position must be finite.");
        }
        if (IsShotInProgress || !Striker.IsActive)
        {
            return false;
        }

        var target = new Vector2(Math.Clamp(x, MinimumStrikerX, MaximumStrikerX), StrikerBaselineY);
        if (_pieces.Any(piece => piece.IsActive && piece.Type != CarromPieceType.Striker
            && Vector2.DistanceSquared(piece.Position, target) < Square(piece.Radius + Striker.Radius)))
        {
            return false;
        }

        Striker.Position = target;
        Striker.Velocity = Vector2.Zero;
        return true;
    }

    public static float GetShotPower(float pullDistance, float selectedPower)
    {
        if (!float.IsFinite(pullDistance) || !float.IsFinite(selectedPower))
        {
            throw new ArgumentOutOfRangeException(nameof(pullDistance), "Shot inputs must be finite.");
        }

        var pullFactor = Math.Clamp((pullDistance - MinimumPullDistance) / MaximumPullDistance, 0F, 1F);
        return Math.Clamp(selectedPower, 0F, 100F) / 100F * pullFactor;
    }

    public bool Shoot(Vector2 direction, float powerPercent)
    {
        if (IsShotInProgress || IsMoving || !Striker.IsActive || !IsFinite(direction) || !float.IsFinite(powerPercent))
        {
            return false;
        }

        var lengthSquared = direction.LengthSquared();
        var power = Math.Clamp(powerPercent, 0F, 100F) / 100F;
        if (lengthSquared < 0.0001F || power <= 0F)
        {
            return false;
        }

        _pocketedThisShot.Clear();
        _strikerPocketedThisShot = false;
        _accumulator = 0;
        Striker.Velocity = Vector2.Normalize(direction) * (MaximumShotSpeed * power);
        IsShotInProgress = true;
        return true;
    }

    public CarromShotResult? Advance(TimeSpan elapsed)
    {
        if (elapsed < TimeSpan.Zero)
        {
            throw new ArgumentOutOfRangeException(nameof(elapsed));
        }
        if (!IsShotInProgress || elapsed == TimeSpan.Zero)
        {
            return null;
        }

        _accumulator += elapsed.TotalSeconds;
        while (_accumulator + 1e-12 >= FixedStepSeconds)
        {
            StepFixed(FixedStepSeconds);
            _accumulator -= FixedStepSeconds;
        }

        if (IsMoving)
        {
            return null;
        }

        foreach (var piece in _pieces.Where(piece => piece.IsActive))
        {
            piece.Velocity = Vector2.Zero;
        }
        IsShotInProgress = false;
        _shotNumber++;
        if (_strikerPocketedThisShot)
        {
            var striker = Striker;
            striker.IsActive = true;
            striker.Position = new Vector2(Math.Clamp(striker.Position.X, MinimumStrikerX, MaximumStrikerX), StrikerBaselineY);
            striker.Velocity = Vector2.Zero;
        }

        var result = new CarromShotResult(_shotNumber, _pocketedThisShot.ToArray(), _strikerPocketedThisShot);
        _pocketedThisShot.Clear();
        _strikerPocketedThisShot = false;
        return result;
    }

    private void StepFixed(float dt)
    {
        foreach (var piece in _pieces)
        {
            if (!piece.IsActive)
            {
                continue;
            }

            var speed = piece.Velocity.Length();
            if (speed <= StopSpeed)
            {
                piece.Velocity = Vector2.Zero;
                continue;
            }

            piece.Position += piece.Velocity * dt;
            var reducedSpeed = Math.Max(0F, speed - FrictionDeceleration * dt);
            piece.Velocity *= reducedSpeed / speed;
        }

        foreach (var piece in _pieces)
        {
            if (piece.IsActive && TryPocket(piece))
            {
                continue;
            }
            if (piece.IsActive)
            {
                ResolveWallCollision(piece);
            }
        }

        for (var pass = 0; pass < 3; pass++)
        {
            for (var first = 0; first < _pieces.Count - 1; first++)
            for (var second = first + 1; second < _pieces.Count; second++)
            {
                ResolvePieceCollision(_pieces[first], _pieces[second]);
            }
        }
    }

    private bool TryPocket(CarromPiece piece)
    {
        var pocketRadius = 42F + piece.Radius * 1.25F;
        ReadOnlySpan<Vector2> pockets =
        [
            new Vector2(107F, 107F),
            new Vector2(893F, 107F),
            new Vector2(107F, 893F),
            new Vector2(893F, 893F)
        ];
        foreach (var pocket in pockets)
        {
            if (Vector2.DistanceSquared(piece.Position, pocket) > Square(pocketRadius))
            {
                continue;
            }

            piece.IsActive = false;
            piece.Velocity = Vector2.Zero;
            PiecePocketed?.Invoke(piece);
            if (piece.Type == CarromPieceType.Striker)
            {
                _strikerPocketedThisShot = true;
            }
            else
            {
                _pocketedThisShot.Add(new CarromPocketedPiece(piece.Id, piece.Type, piece.Position));
            }
            return true;
        }

        return false;
    }

    private static void ResolveWallCollision(CarromPiece piece)
    {
        var min = BoardMinimum + piece.Radius;
        var max = BoardMaximum - piece.Radius;
        if (piece.Position.X < min)
        {
            piece.Position = new Vector2(min, piece.Position.Y);
            if (piece.Velocity.X < 0)
            {
                piece.Velocity = new Vector2(-piece.Velocity.X * WallRestitution, piece.Velocity.Y);
            }
        }
        else if (piece.Position.X > max)
        {
            piece.Position = new Vector2(max, piece.Position.Y);
            if (piece.Velocity.X > 0)
            {
                piece.Velocity = new Vector2(-piece.Velocity.X * WallRestitution, piece.Velocity.Y);
            }
        }

        if (piece.Position.Y < min)
        {
            piece.Position = new Vector2(piece.Position.X, min);
            if (piece.Velocity.Y < 0)
            {
                piece.Velocity = new Vector2(piece.Velocity.X, -piece.Velocity.Y * WallRestitution);
            }
        }
        else if (piece.Position.Y > max)
        {
            piece.Position = new Vector2(piece.Position.X, max);
            if (piece.Velocity.Y > 0)
            {
                piece.Velocity = new Vector2(piece.Velocity.X, -piece.Velocity.Y * WallRestitution);
            }
        }
    }

    private static void ResolvePieceCollision(CarromPiece first, CarromPiece second)
    {
        if (!first.IsActive || !second.IsActive)
        {
            return;
        }

        var delta = second.Position - first.Position;
        var minimumDistance = first.Radius + second.Radius;
        var distanceSquared = delta.LengthSquared();
        if (distanceSquared >= Square(minimumDistance))
        {
            return;
        }

        var distance = MathF.Sqrt(distanceSquared);
        var normal = distance > 0.0001F ? delta / distance : Vector2.UnitX;
        var inverseFirstMass = 1F / first.Mass;
        var inverseSecondMass = 1F / second.Mass;
        var inverseMassSum = inverseFirstMass + inverseSecondMass;
        var relativeVelocity = second.Velocity - first.Velocity;
        var velocityAlongNormal = Vector2.Dot(relativeVelocity, normal);
        if (velocityAlongNormal < 0)
        {
            var impulseMagnitude = -(1F + PieceRestitution) * velocityAlongNormal / inverseMassSum;
            var impulse = impulseMagnitude * normal;
            first.Velocity -= impulse * inverseFirstMass;
            second.Velocity += impulse * inverseSecondMass;
        }

        var penetration = minimumDistance - distance;
        if (penetration > PositionSlop)
        {
            var correction = normal * ((penetration - PositionSlop) * PositionCorrectionPercent / inverseMassSum);
            first.Position -= correction * inverseFirstMass;
            second.Position += correction * inverseSecondMass;
        }
    }

    private Vector2 FindRespotPosition(CarromPiece returningPiece)
    {
        const float spacing = 46F;
        for (var radius = 0F; radius <= 340F; radius += spacing)
        {
            var segments = radius == 0 ? 1 : Math.Max(8, (int)MathF.Ceiling(2F * MathF.PI * radius / spacing));
            for (var segment = 0; segment < segments; segment++)
            {
                var angle = 2F * MathF.PI * segment / segments;
                var candidate = new Vector2(500F + MathF.Cos(angle) * radius, 500F + MathF.Sin(angle) * radius);
                if (candidate.X - returningPiece.Radius < BoardMinimum || candidate.X + returningPiece.Radius > BoardMaximum
                    || candidate.Y - returningPiece.Radius < BoardMinimum || candidate.Y + returningPiece.Radius > BoardMaximum)
                {
                    continue;
                }

                if (_pieces.Where(piece => piece.IsActive && piece.Id != returningPiece.Id)
                    .All(piece => Vector2.DistanceSquared(piece.Position, candidate)
                        >= Square(piece.Radius + returningPiece.Radius + 1F)))
                {
                    return candidate;
                }
            }
        }

        throw new InvalidOperationException("No valid respot position is available for the Carrom piece.");
    }

    private static IEnumerable<CarromPieceDefinition> CreateDefaultLayout()
    {
        var id = 0;
        yield return new CarromPieceDefinition(id++, CarromPieceType.Striker, new Vector2(500F, StrikerBaselineY), StrikerRadius, 1.65F);
        for (var index = 0; index < 9; index++)
        {
            var angle = (-90F + 40F * index) * MathF.PI / 180F;
            yield return new CarromPieceDefinition(id++, CarromPieceType.Black,
                new Vector2(500F + MathF.Cos(angle) * 74F, 500F + MathF.Sin(angle) * 74F), 21F, 1F);
        }
        for (var index = 0; index < 9; index++)
        {
            var angle = (-70F + 40F * index) * MathF.PI / 180F;
            yield return new CarromPieceDefinition(id++, CarromPieceType.White,
                new Vector2(500F + MathF.Cos(angle) * 133F, 500F + MathF.Sin(angle) * 133F), 21F, 1F);
        }
        yield return new CarromPieceDefinition(id, CarromPieceType.Queen, new Vector2(500F, 500F), 24F, 1.05F);
    }

    private static void ValidateDefinitions(IReadOnlyList<CarromPieceDefinition> definitions)
    {
        if (definitions.Count == 0 || definitions.Count(piece => piece.Type == CarromPieceType.Striker) != 1)
        {
            throw new ArgumentException("A Carrom board must contain exactly one striker.", nameof(definitions));
        }
        if (definitions.Select(piece => piece.Id).Distinct().Count() != definitions.Count
            || definitions.Any(piece => !Enum.IsDefined(piece.Type)
                || !IsFinite(piece.Position)
                || !IsFinite(piece.InitialVelocity)
                || !float.IsFinite(piece.Radius) || piece.Radius <= 0
                || !float.IsFinite(piece.Mass) || piece.Mass <= 0))
        {
            throw new ArgumentException("Carrom pieces require unique IDs, finite positions and velocities, and positive radii and masses.", nameof(definitions));
        }
        if (definitions.Any(piece => piece.Position.X < BoardMinimum || piece.Position.X > BoardMaximum
            || piece.Position.Y < BoardMinimum || piece.Position.Y > BoardMaximum))
        {
            throw new ArgumentOutOfRangeException(nameof(definitions), "Carrom pieces must start inside the board boundaries.");
        }
    }

    private static float Square(float value) => value * value;
    private static bool IsFinite(Vector2 value) => float.IsFinite(value.X) && float.IsFinite(value.Y);
}
