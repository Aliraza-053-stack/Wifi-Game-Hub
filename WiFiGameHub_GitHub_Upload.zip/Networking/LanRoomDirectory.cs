namespace WiFiGameHub.Networking;

public sealed class LanRoomDirectory
{
    private readonly object _gate = new();
    private readonly Dictionary<string, (LanRoomAnnouncement Room, DateTime LastSeenUtc)> _rooms = new(StringComparer.OrdinalIgnoreCase);

    public int Count
    {
        get
        {
            lock (_gate)
            {
                return _rooms.Count;
            }
        }
    }

    public void Upsert(LanRoomAnnouncement room, DateTime? seenAtUtc = null)
    {
        ArgumentNullException.ThrowIfNull(room);
        if (!room.IsValid())
        {
            throw new ArgumentException("Room announcement is invalid.", nameof(room));
        }

        lock (_gate)
        {
            _rooms[room.RoomId] = (room, seenAtUtc ?? DateTime.UtcNow);
        }
    }

    public IReadOnlyList<LanRoomAnnouncement> RemoveExpired(DateTime? nowUtc = null, TimeSpan? lifetime = null)
    {
        var now = nowUtc ?? DateTime.UtcNow;
        var expiration = lifetime ?? TimeSpan.FromSeconds(6);
        lock (_gate)
        {
            foreach (var roomId in _rooms.Where(entry => now - entry.Value.LastSeenUtc > expiration).Select(entry => entry.Key).ToArray())
            {
                _rooms.Remove(roomId);
            }
            return _rooms.Values.Select(entry => entry.Room).ToArray();
        }
    }
}
