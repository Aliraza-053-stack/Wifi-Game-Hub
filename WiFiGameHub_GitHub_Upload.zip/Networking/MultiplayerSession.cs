using System.Net.Sockets;
using System.Text.Json;
using System.Numerics;
using WiFiGameHub.Games.Carrom;
using WiFiGameHub.Games.Chess;
using WiFiGameHub.Games.Ludo;
using WiFiGameHub.Games.TicTacToe;

namespace WiFiGameHub.Networking;

public sealed class SessionJoinPayload
{
    public string PlayerId { get; set; } = string.Empty;
    public GameSessionState State { get; set; } = new();
}

public sealed class MultiplayerSession : IDisposable
{
    private readonly object _stateLock = new();
    private readonly SemaphoreSlim _actionGate = new(1, 1);
    private readonly Dictionary<string, GameSessionPlayer> _players = new(StringComparer.Ordinal);
    private readonly Dictionary<TcpClient, string> _connectionPlayers = new();
    private readonly HashSet<string> _processedActions = new(StringComparer.Ordinal);
    private readonly Queue<string> _processedOrder = new();
    private readonly GameImageAssembler _imageAssembler = new();
    private GameServer? _server;
    private readonly Func<int>? _ludoDiceRoller;
    private GameClient? _client;
    private TicTacToeGame? _ticTacToe;
    private LudoGame? _ludo;
    private ChessGame? _chess;
    private CarromPhysicsEngine? _carrom;
    private CarromRulesEngine? _carromRules;
    private string _carromLastResult = string.Empty;
    private string _carromLastShotActionId = string.Empty;
    private string _carromLastShotPlayerId = string.Empty;
    private float _carromLastShotStrikerX;
    private float _carromLastShotAimX;
    private float _carromLastShotAimY;
    private float _carromLastShotPower;
    private DateTime? _carromMatchStartedAtUtc;
    private string _hostPlayerId = string.Empty;
    private long _departureSequence;
    private string _lastDepartedPlayerId = string.Empty;
    private string _lastDepartedPlayerName = string.Empty;
    private string _forfeitWinnerId = string.Empty;
    private bool _isForfeit;
    private bool _intentionalDisconnect;
    private long _revision;

    public MultiplayerSession(Func<int>? ludoDiceRoller = null)
    {
        _ludoDiceRoller = ludoDiceRoller;
    }
    private bool _disposed;

    public event Action<GameSessionState>? StateChanged;
    public event Action<string>? StatusChanged;
    public event Action<bool>? ConnectionChanged;
    public event Action<GameChatEntry>? ChatReceived;
    public event Action<SharedGameImage>? ImageReceived;

    public string RoomId { get; private set; } = string.Empty;
    public string Game { get; private set; } = string.Empty;
    public string LocalPlayerId { get; private set; } = string.Empty;
    public string LocalPlayerName { get; private set; } = string.Empty;
    public bool IsHost { get; private set; }
    public bool IsConnected { get; private set; }
    public bool IsActive => IsConnected && !string.IsNullOrEmpty(RoomId);
    public GameSessionState? CurrentState { get; private set; }
    public int Port => _server?.Port ?? 0;

    public void StartHost(string game, int port, string playerName)
    {
        ThrowIfDisposed();
        ValidateGameAndName(game, playerName);
        if (IsActive)
        {
            throw new InvalidOperationException("A multiplayer session is already active.");
        }

        RoomId = Guid.NewGuid().ToString("N")[..12];
        Game = game;
        LocalPlayerId = Guid.NewGuid().ToString("N");
        _hostPlayerId = LocalPlayerId;
        LocalPlayerName = playerName.Trim();
        IsHost = true;
        _players.Clear();
        _connectionPlayers.Clear();
        _processedActions.Clear();
        _processedOrder.Clear();
        _departureSequence = 0;
        _lastDepartedPlayerId = string.Empty;
        _lastDepartedPlayerName = string.Empty;
        _forfeitWinnerId = string.Empty;
        _isForfeit = false;
        _intentionalDisconnect = false;
        _revision = 0;
        _ticTacToe = game == "TicTacToe" ? new TicTacToeGame() : null;
        _ludo = null;
        _chess = game == "Chess" ? new ChessGame() : null;
        _carrom = game == "Carrom" ? new CarromPhysicsEngine() : null;
        _carromRules = game == "Carrom" ? new CarromRulesEngine() : null;
        _carromLastResult = string.Empty;
        ResetCarromPresentationState();
        _carromMatchStartedAtUtc = null;
        _players.Add(LocalPlayerId, new GameSessionPlayer
        {
            PlayerId = LocalPlayerId,
            Name = LocalPlayerName,
            Mark = game == "TicTacToe" ? "X" : game is "Chess" or "Carrom" ? "White" : string.Empty,
            Color = game == "Ludo" ? "Red" : string.Empty,
            Connected = true
        });
        _server = new GameServer(port, game == "Ludo" ? 3 : 1);
        _server.MessageReceived += HandleServerMessage;
        _server.ClientDisconnected += HandleServerDisconnect;
        _server.Start();
        IsConnected = true;
        CurrentState = CreateState(started: false);
        ConnectionChanged?.Invoke(true);
        StateChanged?.Invoke(CurrentState);
        StatusChanged?.Invoke($"Hosting {game} room {RoomId} on TCP port {port}.");
    }

    public async Task JoinAsync(string host, int port, string roomId, string game, string playerName, CancellationToken cancellationToken = default)
    {
        ThrowIfDisposed();
        ValidateGameAndName(game, playerName);
        if (roomId.Length > 64)
        {
            throw new ArgumentException("Room ID is invalid.", nameof(roomId));
        }
        if (IsActive)
        {
            throw new InvalidOperationException("A multiplayer session is already active.");
        }

        RoomId = roomId;
        Game = game;
        LocalPlayerName = playerName.Trim();
        LocalPlayerId = string.Empty;
        CurrentState = null;
        IsHost = false;
        _carrom = game == "Carrom" ? new CarromPhysicsEngine() : null;
        _carromRules = game == "Carrom" ? new CarromRulesEngine() : null;
        _carromLastResult = string.Empty;
        ResetCarromPresentationState();
        _carromMatchStartedAtUtc = null;
        _intentionalDisconnect = false;
        _departureSequence = 0;
        _lastDepartedPlayerId = string.Empty;
        _lastDepartedPlayerName = string.Empty;
        _forfeitWinnerId = string.Empty;
        _isForfeit = false;
        StatusChanged?.Invoke("Joining room...");
        _client = new GameClient();
        _client.MessageReceived += HandleClientMessage;
        _client.ConnectionClosed += HandleClientClosed;
        await _client.ConnectAsync(host, port, cancellationToken);
        IsConnected = true;
        ConnectionChanged?.Invoke(true);
        await _client.SendMessageAsync(new NetworkMessage
        {
            SenderId = Guid.NewGuid().ToString("N"),
            RoomId = roomId,
            PlayerName = LocalPlayerName,
            Type = NetworkMessageType.JoinRequest,
            Payload = game
        }, cancellationToken);
    }

    public async Task<bool> SendActionAsync(GameActionRequest action, CancellationToken cancellationToken = default)
    {
        ThrowIfDisposed();
        if (!IsActive || string.IsNullOrEmpty(LocalPlayerId))
        {
            StatusChanged?.Invoke("Join a room before sending a game action.");
            return false;
        }

        if (CurrentState?.Players.FirstOrDefault(player => player.PlayerId == LocalPlayerId)?.Connected != true)
        {
            StatusChanged?.Invoke("You have left this match and cannot send further actions.");
            return false;
        }

        action.ExpectedRevision = CurrentState?.Revision ?? 0;
        if (!IsHost)
        {
            if (_client is null)
            {
                return false;
            }
            await _client.SendMessageAsync(new NetworkMessage
            {
                SenderId = LocalPlayerId,
                RoomId = RoomId,
                PlayerName = LocalPlayerName,
                Type = NetworkMessageType.Move,
                Payload = JsonSerializer.Serialize(action)
            }, cancellationToken);
            return true;
        }

        await _actionGate.WaitAsync(cancellationToken);
        try
        {
            return await ApplyActionAsync(null, LocalPlayerId, action, cancellationToken);
        }
        finally
        {
            _actionGate.Release();
        }
    }

    public async Task LeaveGameAsync(CancellationToken cancellationToken = default)
    {
        if (!IsActive || string.IsNullOrWhiteSpace(LocalPlayerId))
        {
            return;
        }

        if (IsHost)
        {
            if (MarkPlayerDeparted(LocalPlayerId))
            {
                PublishStateAndBroadcast();
            }
            return;
        }

        var client = _client;
        if (client is null)
        {
            return;
        }

        _intentionalDisconnect = true;
        try
        {
            await client.SendMessageAsync(new NetworkMessage
            {
                SenderId = LocalPlayerId,
                RoomId = RoomId,
                PlayerName = LocalPlayerName,
                Type = NetworkMessageType.Disconnect
            }, cancellationToken);
        }
        finally
        {
            _intentionalDisconnect = true;
            client.Dispose();
            _client = null;
            IsConnected = false;
            ConnectionChanged?.Invoke(false);
        }
    }

    public async Task<bool> SendChatAsync(string text, CancellationToken cancellationToken = default)
    {
        if (!IsActive || string.IsNullOrWhiteSpace(LocalPlayerId))
        {
            StatusChanged?.Invoke("Join a room before chatting.");
            return false;
        }
        var cleanText = text.Trim();
        if (cleanText.Length is < 1 or > 1000)
        {
            StatusChanged?.Invoke("Chat messages must be 1 to 1000 characters.");
            return false;
        }

        var entry = new GameChatEntry
        {
            RoomId = RoomId,
            SenderId = LocalPlayerId,
            SenderName = LocalPlayerName,
            Text = cleanText
        };
        if (IsHost)
        {
            ChatReceived?.Invoke(entry);
            await BroadcastRoomMessageAsync(NetworkMessageType.Chat, JsonSerializer.Serialize(entry), LocalPlayerId, LocalPlayerName, cancellationToken);
            return true;
        }
        if (_client is null)
        {
            return false;
        }
        await _client.SendMessageAsync(new NetworkMessage
        {
            SenderId = LocalPlayerId,
            RoomId = RoomId,
            PlayerName = LocalPlayerName,
            Type = NetworkMessageType.Chat,
            Payload = JsonSerializer.Serialize(entry)
        }, cancellationToken);
        return true;
    }

    public async Task<bool> SendImageAsync(string fileName, string contentType, ReadOnlyMemory<byte> bytes, CancellationToken cancellationToken = default)
    {
        if (!IsActive || string.IsNullOrWhiteSpace(LocalPlayerId))
        {
            StatusChanged?.Invoke("Join a room before sharing an image.");
            return false;
        }

        List<GameImageChunk> chunks;
        try
        {
            chunks = GameImageAssembler.CreateChunks(fileName, contentType, bytes).ToList();
        }
        catch (ArgumentException exception)
        {
            StatusChanged?.Invoke(exception.Message);
            return false;
        }

        if (IsHost)
        {
            foreach (var chunk in chunks)
            {
                var payload = JsonSerializer.Serialize(chunk);
                await BroadcastRoomMessageAsync(NetworkMessageType.ImageChunk, payload, LocalPlayerId, LocalPlayerName, cancellationToken);
                if (_imageAssembler.TryAddChunk(chunk, LocalPlayerName, out var image) && image is not null)
                {
                    ImageReceived?.Invoke(image);
                }
            }
            return true;
        }
        if (_client is null)
        {
            return false;
        }
        foreach (var chunk in chunks)
        {
            await _client.SendMessageAsync(new NetworkMessage
            {
                SenderId = LocalPlayerId,
                RoomId = RoomId,
                PlayerName = LocalPlayerName,
                Type = NetworkMessageType.ImageChunk,
                Payload = JsonSerializer.Serialize(chunk)
            }, cancellationToken);
        }
        return true;
    }

    private void HandleServerMessage(TcpClient client, NetworkMessage message)
    {
        _ = HandleServerMessageAsync(client, message);
    }

    private async Task HandleServerMessageAsync(TcpClient client, NetworkMessage message)
    {
        var closeClient = false;
        await _actionGate.WaitAsync();
        try
        {
            if (message.Type == NetworkMessageType.JoinRequest)
            {
                await AcceptJoinAsync(client, message);
                return;
            }

            if (!_connectionPlayers.TryGetValue(client, out var playerId)
                || playerId != message.SenderId
                || message.RoomId != RoomId
                || !_players.TryGetValue(playerId, out var player)
                || !player.Connected)
            {
                await RejectAsync(client, "Player is not authorized for this room.");
                return;
            }

            if (message.Type == NetworkMessageType.Disconnect)
            {
                closeClient = true;
                return;
            }

            if (message.Type == NetworkMessageType.Chat)
            {
                await RelayChatAsync(player, message.Payload, cancellationToken: CancellationToken.None);
                return;
            }
            if (message.Type == NetworkMessageType.ImageChunk)
            {
                await RelayImageChunkAsync(player, message.Payload, CancellationToken.None);
                return;
            }
            if (message.Type != NetworkMessageType.Move)
            {
                await RejectAsync(client, "Unsupported game action message.");
                return;
            }

            GameActionRequest? action;
            try
            {
                action = JsonSerializer.Deserialize<GameActionRequest>(message.Payload);
            }
            catch (JsonException)
            {
                await RejectAsync(client, "Malformed game action JSON.");
                return;
            }

            if (action is null)
            {
                await RejectAsync(client, "Game action is empty.");
                return;
            }

            await ApplyActionAsync(client, playerId, action, CancellationToken.None);
        }
        finally
        {
            _actionGate.Release();
            if (closeClient)
            {
                _server?.CloseClient(client);
            }
        }
    }

    private async Task AcceptJoinAsync(TcpClient client, NetworkMessage message)
    {
        if ((!string.IsNullOrEmpty(message.RoomId) && message.RoomId != RoomId)
            || message.Payload != Game
            || string.IsNullOrWhiteSpace(message.PlayerName)
            || message.PlayerName.Trim().Length > 32)
        {
            await SendJoinRejectedAsync(client, "Room, game, or player name is invalid.");
            return;
        }

        if (CurrentState?.Started == true)
        {
            await SendJoinRejectedAsync(client, "A match is already in progress.");
            return;
        }

        GameSessionPlayer assigned;
        lock (_stateLock)
        {
            var connected = _players.Values.Where(player => player.Connected).ToList();
            var capacity = Game == "Ludo" ? 4 : 2;
            if (connected.Count >= capacity || connected.Any(player => player.Name.Equals(message.PlayerName.Trim(), StringComparison.OrdinalIgnoreCase)))
            {
                _ = SendJoinRejectedAsync(client, "Room is full or the player name is already in use.");
                return;
            }

            var slot = Enumerable.Range(0, capacity).First(index => connected.All(player => Game switch
            {
                "TicTacToe" => player.Mark != (index == 0 ? "X" : "O"),
                "Chess" or "Carrom" => player.Mark != (index == 0 ? "White" : "Black"),
                _ => player.Color != new[] { "Red", "Blue", "Green", "Yellow" }[index]
            }));
            assigned = new GameSessionPlayer
            {
                PlayerId = Guid.NewGuid().ToString("N"),
                Name = message.PlayerName.Trim(),
                Mark = Game == "TicTacToe" ? (slot == 0 ? "X" : "O") : Game is "Chess" or "Carrom" ? (slot == 0 ? "White" : "Black") : string.Empty,
                Color = Game == "Ludo" ? new[] { "Red", "Blue", "Green", "Yellow" }[slot] : string.Empty,
                Connected = true
            };
            _players.Add(assigned.PlayerId, assigned);
            _connectionPlayers[client] = assigned.PlayerId;
            _revision++;
        }

        var started = Game is "TicTacToe" or "Chess" or "Carrom"
            ? _players.Values.Count(player => player.Connected) == 2
            : false;
        if (Game == "Carrom" && started && !_carromMatchStartedAtUtc.HasValue)
        {
            _carromMatchStartedAtUtc = DateTime.UtcNow;
        }
        var state = CreateState(started);
        CurrentState = state;
        await _server!.SendToClientAsync(client, CreateHostMessage(NetworkMessageType.JoinAccepted,
            JsonSerializer.Serialize(new SessionJoinPayload { PlayerId = assigned.PlayerId, State = state })));
        StateChanged?.Invoke(state);
        StatusChanged?.Invoke($"{assigned.Name} joined as {assigned.Mark}{assigned.Color}.");
        await BroadcastStateAsync();
    }

    private async Task<bool> ApplyActionAsync(TcpClient? client, string playerId, GameActionRequest action, CancellationToken cancellationToken)
    {
        if (CurrentState?.IsForfeit == true)
        {
            await RejectAsync(client, "The match ended because a player left.");
            return false;
        }

        if (string.IsNullOrWhiteSpace(action.ActionId) || action.ActionId.Length > 64 || string.IsNullOrWhiteSpace(action.Action) || action.Action.Length > 32)
        {
            await RejectAsync(client, "Action id or action is invalid.");
            return false;
        }
        if (_processedActions.Contains(action.ActionId))
        {
            await RejectAsync(client, "Duplicate action rejected.");
            return false;
        }
        if (action.ExpectedRevision != _revision)
        {
            await RejectAsync(client, "Action is outdated; current state was resent.");
            await SendStateAsync(client);
            return false;
        }
        if (!_players.TryGetValue(playerId, out var player) || !player.Connected)
        {
            await RejectAsync(client, "Player is disconnected or unauthorized.");
            return false;
        }

        bool applied;
        lock (_stateLock)
        {
            applied = Game switch
            {
                "TicTacToe" => ApplyTicTacToeAction(player, action),
                "Chess" => ApplyChessAction(player, action),
                "Ludo" => ApplyLudoAction(player, action),
                "Carrom" => ApplyCarromAction(player, action),
                _ => false
            };
            if (applied)
            {
                _processedActions.Add(action.ActionId);
                _processedOrder.Enqueue(action.ActionId);
                if (_processedOrder.Count > 2048)
                {
                    _processedActions.Remove(_processedOrder.Dequeue());
                }
                _revision++;
                CurrentState = CreateState();
            }
        }

        if (!applied)
        {
            await RejectAsync(client, "Illegal action for the current game state.");
            return false;
        }

        StateChanged?.Invoke(CurrentState!);
        await BroadcastStateAsync(cancellationToken);
        return true;
    }

    private bool ApplyTicTacToeAction(GameSessionPlayer player, GameActionRequest action)
    {
        if (action.Action is "restart" or "new-match")
        {
            if (action.Action == "new-match")
            {
                _ticTacToe!.NewMatch();
            }
            else
            {
                _ticTacToe!.ResetBoard();
            }
            return true;
        }

        if (!CurrentState!.Started || action.Action != "tic-move" || _ticTacToe is null)
        {
            return false;
        }

        var current = _players.Values.FirstOrDefault(candidate => candidate.Connected && candidate.Mark == _ticTacToe.CurrentPlayer);
        return current?.PlayerId == player.PlayerId && _ticTacToe.MakeMove(action.Row, action.Column, player.Mark);
    }

    private bool ApplyLudoAction(GameSessionPlayer player, GameActionRequest action)
    {
        if (action.Action == "restart" && player.PlayerId == _hostPlayerId)
        {
            _ludo = null;
            CurrentState = CreateState(started: false);
            return true;
        }

        if (action.Action == "start")
        {
            if (player.PlayerId != _hostPlayerId || _ludo is not null)
            {
                return false;
            }
            var roster = _players.Values.Where(candidate => candidate.Connected).OrderBy(candidate => ColorIndex(candidate.Color)).ToList();
            if (roster.Count is < 2 or > 4)
            {
                return false;
            }
            _ludo = new LudoGame(
                roster.Count,
                _ludoDiceRoller,
                roster.Select(candidate => candidate.Name).ToArray(),
                roster.Select(candidate => candidate.Color).ToArray());
            CurrentState = CreateState(started: true);
            return true;
        }

        if (_ludo is null || CurrentState?.Started != true)
        {
            return false;
        }
        var index = _ludo.Players.FindIndex(candidate => candidate.Color == player.Color);
        if (index < 0 || index != _ludo.CurrentPlayerIndex)
        {
            return false;
        }
        if (action.Action == "ludo-roll" && _ludo.LastDiceValue == 0)
        {
            _ludo.RollDice();
            return true;
        }
        return action.Action == "ludo-move" && _ludo.MoveToken(index, action.TokenIndex);
    }

    private bool ApplyChessAction(GameSessionPlayer player, GameActionRequest action)
    {
        if (action.Action == "restart" && player.PlayerId == _hostPlayerId)
        {
            _chess = new ChessGame();
            CurrentState = CreateState(started: _players.Values.Count(candidate => candidate.Connected) == 2);
            return true;
        }

        if (action.Action != "chess-move" || _chess is null || CurrentState?.Started != true
            || _chess.IsGameOver || player.Mark != _chess.CurrentTurn.ToString())
        {
            return false;
        }
        return _chess.TryMove(action.FromRow, action.FromColumn, action.Row, action.Column, action.Promotion);
    }

    private bool ApplyCarromAction(GameSessionPlayer player, GameActionRequest action)
    {
        if (_carrom is null || _carromRules is null)
        {
            return false;
        }

        if (action.Action == "carrom-reset")
        {
            var bothPlayersConnected = _players.Values.Count(candidate => candidate.Connected) == 2;
            var validRematchRequest = CurrentState is { IsGameOver: true, IsForfeit: false };
            if (!bothPlayersConnected
                || player.PlayerId != _hostPlayerId && !validRematchRequest)
            {
                return false;
            }

            _carrom.Reset();
            _carromRules.Reset();
            _carromLastResult = $"Match restarted by {player.Name}.";
            ResetCarromPresentationState();
            _carromMatchStartedAtUtc = DateTime.UtcNow;
            return true;
        }

        if (action.Action != "carrom-shot" || CurrentState?.Started != true
            || CurrentState.IsGameOver
            || player.Mark != (_carromRules.CurrentPlayerIndex == 0 ? "White" : "Black")
            || !float.IsFinite(action.CarromStrikerX)
            || !float.IsFinite(action.CarromAimX)
            || !float.IsFinite(action.CarromAimY)
            || !float.IsFinite(action.CarromPower)
            || action.CarromStrikerX < CarromPhysicsEngine.MinimumStrikerX
            || action.CarromStrikerX > CarromPhysicsEngine.MaximumStrikerX
            || action.CarromAimX is < 0F or > 1000F
            || action.CarromAimY is < 0F or > 1000F
            || action.CarromPower is < 0F or > 100F)
        {
            return false;
        }

        var pullPoint = new Vector2(action.CarromAimX, action.CarromAimY);
        var strikerPosition = new Vector2(action.CarromStrikerX, CarromPhysicsEngine.StrikerBaselineY);
        var direction = strikerPosition - pullPoint;
        var power = CarromPhysicsEngine.GetShotPower(Vector2.Distance(strikerPosition, pullPoint), action.CarromPower) * 100F;
        if (!_carrom.TryPlaceStriker(action.CarromStrikerX) || !_carrom.Shoot(direction, power))
        {
            return false;
        }

        _carromLastShotActionId = action.ActionId;
        _carromLastShotPlayerId = player.PlayerId;
        _carromLastShotStrikerX = action.CarromStrikerX;
        _carromLastShotAimX = action.CarromAimX;
        _carromLastShotAimY = action.CarromAimY;
        _carromLastShotPower = action.CarromPower;
        CarromShotResult? shotResult = null;
        for (var step = 0; step < 1_200 && shotResult is null; step++)
        {
            shotResult = _carrom.Advance(TimeSpan.FromSeconds(CarromPhysicsEngine.FixedStepSeconds));
        }
        if (shotResult is null || !_carromRules.TryProcessShot(_carrom, shotResult, out var ruleResult) || ruleResult is null)
        {
            _carrom.RestoreSnapshot(CurrentState!.CarromPieces, CurrentState.CarromShotNumber);
            return false;
        }

        var playerLabel = _carromRules.CurrentPlayerIndex == 0 ? "White" : "Black";
        _carromLastResult = ruleResult.IsFoul
            ? $"{player.Name} fouled: {ruleResult.FoulReason} Turn passes to the other player."
            : ruleResult.QueenClaimed
                ? $"{player.Name} covered the Queen."
                : ruleResult.QueenReturned
                    ? "The Queen was returned to the center because it was not covered."
                    : ruleResult.BoardCompleted
                        ? ruleResult.MatchCompleted
                            ? ruleResult.MatchWinnerIndex is int winnerIndex
                                ? $"{(winnerIndex == 0 ? "White" : "Black")} wins the match."
                                : "The Carrom match is tied."
                            : $"Board complete. {playerLabel} won the board; scores {ruleResult.WhiteScore}–{ruleResult.BlackScore}."
                        : ruleResult.OwnCoinPocketed
                            ? $"{player.Name} pocketed an own-colour coin and keeps the turn."
                            : $"Turn passes to {playerLabel}.";

        if (ruleResult.BoardCompleted && !ruleResult.MatchCompleted)
        {
            _carrom.Reset();
            _carromRules.BeginNextBoard(_carromRules.CurrentPlayerIndex);
        }

        return true;
    }

    private void HandleClientMessage(NetworkMessage message)
    {
        if (message.RoomId != RoomId && !(string.IsNullOrEmpty(RoomId) && message.Type == NetworkMessageType.JoinAccepted))
        {
            return;
        }
        if (message.Type == NetworkMessageType.JoinAccepted)
        {
            try
            {
                var join = JsonSerializer.Deserialize<SessionJoinPayload>(message.Payload)
                    ?? throw new JsonException("Join response is empty.");
                if (!string.IsNullOrEmpty(join.State.RoomId))
                {
                    RoomId = join.State.RoomId;
                }
                LocalPlayerId = join.PlayerId;
                _hostPlayerId = message.SenderId;
                ApplyClientState(join.State);
                StatusChanged?.Invoke("Successfully connected.");
            }
            catch (JsonException exception)
            {
                StatusChanged?.Invoke($"Invalid join state: {exception.Message}");
            }
            return;
        }
        if (message.Type == NetworkMessageType.GameState)
        {
            try
            {
                var state = JsonSerializer.Deserialize<GameSessionState>(message.Payload)
                    ?? throw new JsonException("Game state is empty.");
                if (message.SenderId != _hostPlayerId || state.RoomId != RoomId || state.Game != Game
                    || state.Revision <= (CurrentState?.Revision ?? -1))
                {
                    return;
                }
                ApplyClientState(state);
            }
            catch (JsonException exception)
            {
                StatusChanged?.Invoke($"Invalid game state: {exception.Message}");
            }
            return;
        }
        if (message.Type == NetworkMessageType.Chat)
        {
            try
            {
                var entry = JsonSerializer.Deserialize<GameChatEntry>(message.Payload);
                if (entry is not null && entry.RoomId == RoomId && entry.Text.Length is > 0 and <= 1000)
                {
                    ChatReceived?.Invoke(entry);
                }
            }
            catch (JsonException exception)
            {
                StatusChanged?.Invoke($"Invalid chat message: {exception.Message}");
            }
            return;
        }
        if (message.Type == NetworkMessageType.ImageChunk)
        {
            try
            {
                var chunk = JsonSerializer.Deserialize<GameImageChunk>(message.Payload);
                if (chunk is not null && _imageAssembler.TryAddChunk(chunk, message.PlayerName, out var image) && image is not null)
                {
                    ImageReceived?.Invoke(image);
                }
            }
            catch (JsonException exception)
            {
                StatusChanged?.Invoke($"Invalid shared image: {exception.Message}");
            }
            return;
        }
        if (message.Type is NetworkMessageType.Error or NetworkMessageType.JoinRejected)
        {
            StatusChanged?.Invoke(message.Type == NetworkMessageType.JoinRejected
                ? $"Connection failed: {message.Payload}"
                : message.Payload);
            if (message.Type == NetworkMessageType.JoinRejected)
            {
                _client?.Dispose();
                _client = null;
                IsConnected = false;
                ConnectionChanged?.Invoke(false);
            }
        }
    }

    private void ApplyClientState(GameSessionState state)
    {
        if (state.RoomId != RoomId || state.Game != Game || state.Revision < 0)
        {
            StatusChanged?.Invoke("Rejected state for another room or game.");
            return;
        }
        if (Game == "TicTacToe")
        {
            if (state.TicTacToeBoard.Length != 9 || state.WinningCells.Any(cell => cell is < 0 or >= 9))
            {
                StatusChanged?.Invoke("Host sent an invalid Tic Tac Toe board.");
                return;
            }
            _ticTacToe ??= new TicTacToeGame();
            _ticTacToe.RestoreState(state.TicTacToeBoard, state.CurrentPlayerMark, state.IsGameOver, state.WinnerMark, state.IsDraw,
                state.XScore, state.OScore, state.WinningCells.Select(cell => (cell / 3, cell % 3)).ToArray());
        }
        else if (Game == "Ludo" && state.Players.Count is >= 2 and <= 4
            && state.LudoTokenPositions.Length == state.Players.Count * 4)
        {
            _ludo = new LudoGame(
                state.Players.Count,
                playerNames: state.Players.Select(player => player.Name).ToArray(),
                playerColors: state.Players.Select(player => player.Color).ToArray());
            _ludo.RestoreState(state.LudoTokenPositions, state.CurrentLudoPlayerIndex, state.PendingDiceValue,
                state.DiceValue, state.IsGameOver, state.WinnerName, state.MoveHistory,
                state.Players.Select(player => player.Connected).ToArray());
        }
        else if (Game == "Chess")
        {
            if (state.ChessFen is null || state.ChessFen.Length is < 1 or > 128
                || state.MoveHistory is null || state.MoveHistory.Length > 512
                || state.MoveHistory.Any(move => move is null || move.Length > 32))
            {
                StatusChanged?.Invoke("Host sent an invalid Chess position.");
                return;
            }
            try
            {
                _chess ??= new ChessGame();
                _chess.LoadFen(state.ChessFen, state.MoveHistory);
            }
            catch (ArgumentException exception)
            {
                StatusChanged?.Invoke($"Host sent an invalid Chess position: {exception.Message}");
                return;
            }
        }
        else if (Game == "Carrom")
        {
            if (state.Players is null || state.Players.Count != 2 || state.CarromPieces is null
                || state.CarromPieces.Length != 20
                || state.CarromCurrentPlayerIndex is < 0 or > 1
                || state.CarromMatchWinnerIndex is < -1 or > 1
                || state.CarromQueenPendingCoverByPlayer is < -1 or > 1
                || state.CarromLastResult is null || state.CarromLastResult.Length > 256
                || state.CarromLastShotActionId is null || state.CarromLastShotActionId.Length > 64
                || state.CarromLastShotPlayerId is null || state.CarromLastShotPlayerId.Length > 128
                || state.CarromMatchDurationSeconds < 0
                || state.CarromLastShotActionId.Length > 0
                    && (!state.Players.Any(player => player.PlayerId == state.CarromLastShotPlayerId)
                        || !float.IsFinite(state.CarromLastShotStrikerX)
                        || !float.IsFinite(state.CarromLastShotAimX)
                        || !float.IsFinite(state.CarromLastShotAimY)
                        || !float.IsFinite(state.CarromLastShotPower)
                        || state.CarromLastShotStrikerX is < CarromPhysicsEngine.MinimumStrikerX or > CarromPhysicsEngine.MaximumStrikerX
                        || state.CarromLastShotAimX is < 0F or > 1000F
                        || state.CarromLastShotAimY is < 0F or > 1000F
                        || state.CarromLastShotPower is < 0F or > 100F))
            {
                StatusChanged?.Invoke("Host sent an invalid Carrom match state.");
                return;
            }

            try
            {
                _carrom ??= new CarromPhysicsEngine();
                _carrom.RestoreSnapshot(state.CarromPieces, state.CarromShotNumber);
                _carromRules ??= new CarromRulesEngine();
                _carromRules.RestoreState(
                    state.CarromCurrentPlayerIndex,
                    state.CarromCompletedBoards,
                    state.CarromWhiteScore,
                    state.CarromBlackScore,
                    state.CarromWhiteFouls,
                    state.CarromBlackFouls,
                    state.CarromWhitePocketedCoins,
                    state.CarromBlackPocketedCoins,
                    state.CarromWhiteTotalPocketedCoins,
                    state.CarromBlackTotalPocketedCoins,
                    state.CarromWhiteQueenBonus,
                    state.CarromBlackQueenBonus,
                    state.CarromQueenPendingCoverByPlayer < 0 ? null : state.CarromQueenPendingCoverByPlayer,
                    state.CarromQueenClaimed,
                    state.CarromQueenClaimedByPlayer < 0 ? null : state.CarromQueenClaimedByPlayer,
                    state.CarromBoardComplete,
                    state.IsGameOver,
                    state.CarromMatchWinnerIndex < 0 ? null : state.CarromMatchWinnerIndex,
                    state.CarromShotNumber);
                _carromLastResult = state.CarromLastResult;
            }
            catch (ArgumentException exception)
            {
                StatusChanged?.Invoke($"Host sent an invalid Carrom snapshot: {exception.Message}");
                return;
            }
        }
        CurrentState = state;
        StateChanged?.Invoke(state);
    }

    private GameSessionState CreateState(bool? started = null)
    {
        var connectedPlayers = _players.Values.Where(player => player.Connected).ToList();
        var roster = Game == "Ludo" && _ludo is null ? connectedPlayers : _players.Values.ToList();
        var state = new GameSessionState
        {
            RoomId = RoomId,
            Game = Game,
            Revision = _revision,
            Started = started ?? (Game is "TicTacToe" or "Chess" or "Carrom" ? connectedPlayers.Count == 2 : _ludo is not null),
            Players = roster.Select(ClonePlayer).ToList(),
            XScore = _ticTacToe?.XScore ?? 0,
            OScore = _ticTacToe?.OScore ?? 0,
            IsForfeit = _isForfeit,
            DepartureSequence = _departureSequence,
            LastDepartedPlayerId = _lastDepartedPlayerId,
            LastDepartedPlayerName = _lastDepartedPlayerName
        };
        if (_ticTacToe is not null)
        {
            state.TicTacToeBoard = Enumerable.Range(0, 9)
                .Select(index => _ticTacToe.Board[index / 3, index % 3]).ToArray();
            state.WinningCells = _ticTacToe.WinningLine.Select(cell => cell.Row * 3 + cell.Col).ToArray();
            state.WinnerMark = _ticTacToe.Winner;
            state.WinnerId = connectedPlayers.FirstOrDefault(player => player.Mark == _ticTacToe.Winner)?.PlayerId ?? string.Empty;
            state.IsGameOver = _ticTacToe.IsGameOver;
            state.IsDraw = _ticTacToe.IsDraw;
            state.CurrentPlayerId = connectedPlayers.FirstOrDefault(player => player.Mark == _ticTacToe.CurrentPlayer)?.PlayerId ?? string.Empty;
            state.CurrentPlayerMark = _ticTacToe.CurrentPlayer;
            state.MoveHistory = _ticTacToe.MoveHistory.ToArray();
        }
        if (_ludo is not null)
        {
            state.Players = _ludo.Players.Select(ludoPlayer =>
            {
                var player = _players.Values.LastOrDefault(candidate => candidate.Connected && candidate.Color == ludoPlayer.Color)
                    ?? _players.Values.LastOrDefault(candidate => candidate.Color == ludoPlayer.Color);
                return player is null
                    ? new GameSessionPlayer { Name = ludoPlayer.Name, Color = ludoPlayer.Color, Connected = false }
                    : ClonePlayer(player);
            }).ToList();
            for (var index = 0; index < _ludo.Players.Count; index++)
            {
                state.Players[index].Connected &= _ludo.Players[index].IsActive;
            }
            state.LudoTokenPositions = _ludo.Players.SelectMany(player => player.Tokens).Select(token => token.Position).ToArray();
            state.CurrentLudoPlayerIndex = _ludo.CurrentPlayerIndex;
            state.CurrentPlayerId = state.Players.ElementAtOrDefault(_ludo.CurrentPlayerIndex)?.PlayerId ?? string.Empty;
            state.DiceValue = _ludo.LastDiceResult;
            state.PendingDiceValue = _ludo.LastDiceValue;
            state.IsGameOver = _ludo.IsGameOver;
            state.WinnerName = _ludo.Winner;
            state.WinnerId = state.Players.FirstOrDefault(player => player.Name == _ludo.Winner)?.PlayerId ?? string.Empty;
            state.MoveHistory = _ludo.MoveHistory.ToArray();
        }
        if (_chess is not null)
        {
            state.ChessFen = _chess.ToFen();
            state.CurrentPlayerMark = _chess.CurrentTurn.ToString();
            state.CurrentPlayerId = connectedPlayers.FirstOrDefault(player => player.Mark == state.CurrentPlayerMark)?.PlayerId ?? string.Empty;
            state.IsGameOver = _chess.IsGameOver;
            state.IsDraw = _chess.IsDraw;
            state.WinnerMark = _chess.Winner?.ToString() ?? string.Empty;
            state.WinnerId = connectedPlayers.FirstOrDefault(player => player.Mark == state.WinnerMark)?.PlayerId ?? string.Empty;
            state.WinnerName = roster.FirstOrDefault(player => player.PlayerId == state.WinnerId)?.Name ?? string.Empty;
            state.MoveHistory = _chess.MoveHistory.ToArray();
        }
        if (_carrom is not null && _carromRules is not null)
        {
            state.CarromPieces = _carrom.CreateSnapshot();
            state.CarromShotNumber = _carrom.ShotNumber;
            state.CarromCurrentPlayerIndex = _carromRules.CurrentPlayerIndex;
            state.CarromWhiteScore = _carromRules.Scores[0];
            state.CarromBlackScore = _carromRules.Scores[1];
            state.CarromWhiteFouls = _carromRules.Fouls[0];
            state.CarromBlackFouls = _carromRules.Fouls[1];
            state.CarromWhitePocketedCoins = _carromRules.PocketedCoins[0];
            state.CarromBlackPocketedCoins = _carromRules.PocketedCoins[1];
            state.CarromCompletedBoards = _carromRules.CompletedBoards;
            state.CarromWhiteTotalPocketedCoins = _carromRules.TotalPocketedCoins[0];
            state.CarromBlackTotalPocketedCoins = _carromRules.TotalPocketedCoins[1];
            state.CarromWhiteQueenBonus = _carromRules.QueenBonuses[0];
            state.CarromBlackQueenBonus = _carromRules.QueenBonuses[1];
            state.CarromQueenPendingCoverByPlayer = _carromRules.QueenPendingCoverByPlayer ?? -1;
            state.CarromQueenClaimed = _carromRules.QueenClaimed;
            state.CarromQueenClaimedByPlayer = _carromRules.QueenClaimedByPlayer ?? -1;
            state.CarromBoardComplete = _carromRules.IsBoardComplete;
            state.CarromMatchWinnerIndex = _carromRules.MatchWinnerIndex ?? -1;
            state.CarromLastResult = _carromLastResult;
            state.CarromLastShotActionId = _carromLastShotActionId;
            state.CarromLastShotPlayerId = _carromLastShotPlayerId;
            state.CarromLastShotStrikerX = _carromLastShotStrikerX;
            state.CarromLastShotAimX = _carromLastShotAimX;
            state.CarromLastShotAimY = _carromLastShotAimY;
            state.CarromLastShotPower = _carromLastShotPower;
            state.CarromMatchDurationSeconds = _carromMatchStartedAtUtc is DateTime startedAt
                ? Math.Max(0, (long)(DateTime.UtcNow - startedAt).TotalSeconds)
                : 0;
            state.CurrentPlayerMark = _carromRules.CurrentPlayerIndex == 0 ? "White" : "Black";
            state.CurrentPlayerId = connectedPlayers.FirstOrDefault(player => player.Mark == state.CurrentPlayerMark)?.PlayerId ?? string.Empty;
            state.IsGameOver = _carromRules.IsMatchComplete;
            state.IsDraw = _carromRules.IsMatchComplete && !_carromRules.MatchWinnerIndex.HasValue;
            state.WinnerMark = _carromRules.MatchWinnerIndex is int winnerIndex
                ? winnerIndex == 0 ? "White" : "Black"
                : string.Empty;
            state.WinnerId = connectedPlayers.FirstOrDefault(player => player.Mark == state.WinnerMark)?.PlayerId ?? string.Empty;
            state.WinnerName = roster.FirstOrDefault(player => player.PlayerId == state.WinnerId)?.Name ?? string.Empty;
        }
        else if (Game == "Ludo" && _ludo is null)
        {
            state.Players = roster.Select(ClonePlayer).ToList();
            state.LudoTokenPositions = Enumerable.Repeat(-1, roster.Count * 4).ToArray();
            state.CurrentLudoPlayerIndex = 0;
            state.CurrentPlayerId = connectedPlayers.FirstOrDefault(player => player.Color == "Red")?.PlayerId ?? string.Empty;
        }

        if (_isForfeit)
        {
            var winner = state.Players.FirstOrDefault(player => player.PlayerId == _forfeitWinnerId)
                ?? _players.Values.FirstOrDefault(player => player.PlayerId == _forfeitWinnerId);
            if (winner is not null)
            {
                state.IsGameOver = true;
                state.IsDraw = false;
                state.WinnerId = winner.PlayerId;
                state.WinnerName = winner.Name;
                state.WinnerMark = winner.Mark;
            }
        }
        return state;
    }

    private static GameSessionPlayer ClonePlayer(GameSessionPlayer player) => new()
    {
        PlayerId = player.PlayerId,
        Name = player.Name,
        Mark = player.Mark,
        Color = player.Color,
        Connected = player.Connected
    };

    private void HandleServerDisconnect(TcpClient client)
    {
        string? playerId;
        lock (_stateLock)
        {
            _connectionPlayers.Remove(client, out playerId);
        }

        if (playerId is not null && MarkPlayerDeparted(playerId))
        {
            PublishStateAndBroadcast();
        }
    }

    private bool MarkPlayerDeparted(string playerId)
    {
        GameSessionPlayer player;
        lock (_stateLock)
        {
            if (!_players.TryGetValue(playerId, out var found) || !found.Connected)
            {
                return false;
            }
            player = found;

            var wasStarted = CurrentState?.Started == true;
            var wasGameOver = CurrentState?.IsGameOver == true;
            player.Connected = false;
            _departureSequence++;
            _lastDepartedPlayerId = player.PlayerId;
            _lastDepartedPlayerName = player.Name;

            if (_ludo is not null)
            {
                var ludoIndex = _ludo.Players.FindIndex(candidate => candidate.Color == player.Color);
                if (ludoIndex >= 0)
                {
                    _ludo.SetPlayerActive(ludoIndex, false);
                }
            }

            var remainingPlayers = _players.Values.Where(candidate => candidate.Connected).ToList();
            if (wasStarted && !wasGameOver && remainingPlayers.Count == 1)
            {
                var winner = remainingPlayers[0];
                _forfeitWinnerId = winner.PlayerId;
                _isForfeit = true;
                _ludo?.EndByForfeit(winner.Name);
            }

            _revision++;
            CurrentState = CreateState(started: wasStarted);
        }

        StatusChanged?.Invoke($"Player {player.Name} has left the game.");
        return true;
    }

    private async void PublishStateAndBroadcast()
    {
        if (CurrentState is null)
        {
            return;
        }
        StateChanged?.Invoke(CurrentState);
        await BroadcastStateAsync();
    }

    private async Task BroadcastStateAsync(CancellationToken cancellationToken = default)
    {
        if (_server is null || CurrentState is null)
        {
            return;
        }
        await _server.BroadcastAsync(CreateHostMessage(NetworkMessageType.GameState, JsonSerializer.Serialize(CurrentState)), cancellationToken);
    }

    private async Task RelayChatAsync(GameSessionPlayer player, string payload, CancellationToken cancellationToken)
    {
        try
        {
            var incoming = JsonSerializer.Deserialize<GameChatEntry>(payload);
            if (incoming is null || incoming.RoomId != RoomId || incoming.Text.Trim().Length is < 1 or > 1000)
            {
                StatusChanged?.Invoke("Invalid chat message rejected.");
                return;
            }
            var entry = new GameChatEntry
            {
                MessageId = incoming.MessageId,
                RoomId = RoomId,
                SenderId = player.PlayerId,
                SenderName = player.Name,
                Text = incoming.Text.Trim(),
                SentAtUtc = DateTime.UtcNow
            };
            ChatReceived?.Invoke(entry);
            await BroadcastRoomMessageAsync(NetworkMessageType.Chat, JsonSerializer.Serialize(entry), player.PlayerId, player.Name, cancellationToken);
        }
        catch (JsonException)
        {
            StatusChanged?.Invoke("Invalid chat payload rejected.");
        }
    }

    private async Task RelayImageChunkAsync(GameSessionPlayer player, string payload, CancellationToken cancellationToken)
    {
        try
        {
            var chunk = JsonSerializer.Deserialize<GameImageChunk>(payload);
            if (chunk is null || !_imageAssembler.TryAddChunk(chunk, player.Name, out var image))
            {
                StatusChanged?.Invoke("Invalid or oversized image chunk rejected.");
                return;
            }

            await BroadcastRoomMessageAsync(NetworkMessageType.ImageChunk, JsonSerializer.Serialize(chunk), player.PlayerId, player.Name, cancellationToken);
            if (image is not null)
            {
                ImageReceived?.Invoke(image);
            }
        }
        catch (JsonException)
        {
            StatusChanged?.Invoke("Invalid image payload rejected.");
        }
    }

    private async Task BroadcastRoomMessageAsync(NetworkMessageType type, string payload, string senderId, string senderName, CancellationToken cancellationToken)
    {
        if (_server is null)
        {
            return;
        }
        await _server.BroadcastAsync(new NetworkMessage
        {
            SenderId = senderId,
            RoomId = RoomId,
            PlayerName = senderName,
            Type = type,
            Payload = payload
        }, cancellationToken);
    }

    private Task SendStateAsync(TcpClient? client)
    {
        if (client is null || _server is null || CurrentState is null)
        {
            return Task.CompletedTask;
        }
        return _server.SendToClientAsync(client, CreateHostMessage(NetworkMessageType.GameState, JsonSerializer.Serialize(CurrentState)));
    }

    private async Task RejectAsync(TcpClient? client, string reason)
    {
        StatusChanged?.Invoke(reason);
        if (client is not null && _server is not null)
        {
            try
            {
                await _server.SendToClientAsync(client, CreateHostMessage(NetworkMessageType.Error, reason));
            }
            catch (Exception exception) when (exception is IOException or InvalidOperationException or ObjectDisposedException)
            {
                StatusChanged?.Invoke($"Unable to send rejection: {exception.Message}");
            }
        }
    }

    private Task SendJoinRejectedAsync(TcpClient client, string reason) =>
        _server!.SendToClientAsync(client, CreateHostMessage(NetworkMessageType.JoinRejected, reason));

    private NetworkMessage CreateHostMessage(NetworkMessageType type, string payload) => new()
    {
        SenderId = _hostPlayerId,
        RoomId = RoomId,
        PlayerName = LocalPlayerName,
        Type = type,
        Payload = payload
    };

    private void ResetCarromPresentationState()
    {
        _carromLastShotActionId = string.Empty;
        _carromLastShotPlayerId = string.Empty;
        _carromLastShotStrikerX = 0F;
        _carromLastShotAimX = 0F;
        _carromLastShotAimY = 0F;
        _carromLastShotPower = 0F;
    }

    private static int ColorIndex(string color) => color switch
    {
        "Red" => 0,
        "Blue" => 1,
        "Green" => 2,
        "Yellow" => 3,
        _ => int.MaxValue
    };

    private void HandleClientClosed(string reason)
    {
        if (!_intentionalDisconnect)
        {
            ApplyUnexpectedHostDisconnect();
        }
        IsConnected = false;
        ConnectionChanged?.Invoke(false);
        StatusChanged?.Invoke(reason);
    }

    private void ApplyUnexpectedHostDisconnect()
    {
        if (CurrentState is not { Started: true } state || state.Game == "Chat")
        {
            return;
        }

        var host = state.Players.FirstOrDefault(player => player.PlayerId == _hostPlayerId);
        if (host is null || !host.Connected)
        {
            return;
        }

        var connectedBeforeLoss = state.Players.Count(player => player.Connected);
        host.Connected = false;
        _departureSequence = Math.Max(_departureSequence, state.DepartureSequence) + 1;
        _lastDepartedPlayerId = host.PlayerId;
        _lastDepartedPlayerName = host.Name;
        state.DepartureSequence = _departureSequence;
        state.LastDepartedPlayerId = _lastDepartedPlayerId;
        state.LastDepartedPlayerName = _lastDepartedPlayerName;
        state.Revision++;

        if (state.Game == "Ludo")
        {
            foreach (var player in state.Players.Where(player => player.PlayerId != LocalPlayerId))
            {
                player.Connected = false;
            }
        }

        var remaining = state.Players.Where(player => player.Connected).ToList();
        if (connectedBeforeLoss == 2 && remaining.Count == 1 && !state.IsGameOver)
        {
            var winner = remaining[0];
            state.IsGameOver = true;
            state.IsDraw = false;
            state.IsForfeit = true;
            state.WinnerId = winner.PlayerId;
            state.WinnerName = winner.Name;
            state.WinnerMark = winner.Mark;
        }

        CurrentState = state;
        StateChanged?.Invoke(state);
        StatusChanged?.Invoke(remaining.Count == 1 && state.IsForfeit
            ? $"Player {host.Name} has left the game. You won!"
            : $"Player {host.Name} has left. The host connection ended; this room cannot continue.");
    }

    private static void ValidateGameAndName(string game, string playerName)
    {
        if (game is not ("TicTacToe" or "Ludo" or "Chess" or "Chat" or "Carrom"))
        {
            throw new ArgumentException("Game must be TicTacToe, Ludo, Chess, Chat, or Carrom.", nameof(game));
        }
        if (string.IsNullOrWhiteSpace(playerName) || playerName.Trim().Length > 32)
        {
            throw new ArgumentException("Player name must contain 1 to 32 characters.", nameof(playerName));
        }
    }

    private void ThrowIfDisposed() => ObjectDisposedException.ThrowIf(_disposed, this);

    public void Disconnect()
    {
        _intentionalDisconnect = true;
        _client?.Dispose();
        _client = null;
        _server?.Dispose();
        _server = null;
        IsConnected = false;
        IsHost = false;
        ConnectionChanged?.Invoke(false);
    }

    public void Dispose()
    {
        if (_disposed)
        {
            return;
        }
        Disconnect();
        _disposed = true;
        _actionGate.Dispose();
    }
}