using System.Collections.Concurrent;
using System.Net;
using System.Net.Sockets;
using System.Text;

namespace WiFiGameHub.Networking;

public sealed class GameServer : IDisposable
{
    private readonly TcpListener _listener;
    private readonly ConcurrentDictionary<TcpClient, StreamWriter> _clients = new();
    private readonly ConcurrentDictionary<StreamWriter, SemaphoreSlim> _writeLocks = new();
    private readonly CancellationTokenSource _shutdown = new();
    private Task? _acceptLoop;
    private int _started;
    private readonly int _maximumClients;

    public event Action<string>? MessageLogged;
    public event Action<TcpClient, NetworkMessage>? MessageReceived;
    public event Action<TcpClient>? ClientConnected;
    public event Action<TcpClient>? ClientDisconnected;
    public int Port { get; }
    public int ConnectedClientCount => _clients.Count;

    public GameServer(int port, int maximumClients = 3)
    {
        if (port is < IPEndPoint.MinPort or > IPEndPoint.MaxPort)
        {
            throw new ArgumentOutOfRangeException(nameof(port));
        }

        if (maximumClients is < 1 or > 3)
        {
            throw new ArgumentOutOfRangeException(nameof(maximumClients), "A host supports one to three remote clients.");
        }

        Port = port;
        _maximumClients = maximumClients;
        _listener = new TcpListener(IPAddress.Any, port);
    }

    public void Start()
    {
        if (Interlocked.Exchange(ref _started, 1) != 0)
        {
            throw new InvalidOperationException("The server is already running.");
        }

        _listener.Start();
        _acceptLoop = AcceptLoopAsync(_shutdown.Token);
        MessageLogged?.Invoke($"Server listening on port {Port}.");
    }

    public async Task BroadcastAsync(NetworkMessage message, CancellationToken cancellationToken = default)
    {
        var jsonLine = message.ToJson();
        var failedClients = new List<TcpClient>();
        foreach (var (client, writer) in _clients.ToArray())
        {
            try
            {
                await WriteLineAsync(writer, jsonLine, cancellationToken);
            }
            catch (IOException)
            {
                failedClients.Add(client);
            }
            catch (ObjectDisposedException)
            {
                failedClients.Add(client);
            }
        }

        foreach (var client in failedClients)
        {
            RemoveClient(client);
        }
    }

    public async Task SendToClientAsync(TcpClient client, NetworkMessage message, CancellationToken cancellationToken = default)
    {
        if (!_clients.TryGetValue(client, out var writer))
        {
            throw new InvalidOperationException("The client is not connected to this server.");
        }

        await WriteLineAsync(writer, message.ToJson(), cancellationToken);
    }

    public void CloseClient(TcpClient client)
    {
        RemoveClient(client);
    }

    private async Task AcceptLoopAsync(CancellationToken cancellationToken)
    {
        while (!cancellationToken.IsCancellationRequested)
        {
            TcpClient client;
            try
            {
                client = await _listener.AcceptTcpClientAsync(cancellationToken);
            }
            catch (OperationCanceledException)
            {
                break;
            }
            catch (SocketException) when (cancellationToken.IsCancellationRequested)
            {
                break;
            }

            if (_clients.Count >= _maximumClients)
            {
                client.Dispose();
                MessageLogged?.Invoke("Connection rejected: room capacity reached.");
                continue;
            }

            client.NoDelay = true;
            try
            {
                TcpKeepAlive.Configure(client);
            }
            catch (Exception exception) when (exception is SocketException or ArgumentException)
            {
                client.Dispose();
                MessageLogged?.Invoke($"Client connection rejected because TCP keep-alive could not be configured: {exception.Message}");
                continue;
            }
            var writer = new StreamWriter(client.GetStream(), new UTF8Encoding(false), leaveOpen: true) { AutoFlush = true };
            _clients[client] = writer;
            _writeLocks[writer] = new SemaphoreSlim(1, 1);
            ClientConnected?.Invoke(client);
            MessageLogged?.Invoke($"Client connected: {client.Client.RemoteEndPoint}");
            _ = HandleClientAsync(client, cancellationToken);
        }
    }

    private async Task HandleClientAsync(TcpClient client, CancellationToken cancellationToken)
    {
        try
        {
            using var reader = new StreamReader(client.GetStream(), Encoding.UTF8, false, 4096, leaveOpen: true);
            while (!cancellationToken.IsCancellationRequested)
            {
                var line = await reader.ReadLineAsync(cancellationToken);
                if (line is null)
                {
                    break;
                }

                var message = NetworkMessage.FromJson(line);
                MessageReceived?.Invoke(client, message);
            }
        }
        catch (OperationCanceledException)
        {
        }
        catch (IOException exception)
        {
            MessageLogged?.Invoke($"Client connection ended: {exception.Message}");
        }
        catch (System.Text.Json.JsonException exception)
        {
            MessageLogged?.Invoke($"Invalid client message rejected: {exception.Message}");
        }
        finally
        {
            RemoveClient(client);
        }
    }

    private async Task WriteLineAsync(StreamWriter writer, string line, CancellationToken cancellationToken)
    {
        if (!_writeLocks.TryGetValue(writer, out var writeLock))
        {
            throw new IOException("Client connection is no longer available.");
        }

        await writeLock.WaitAsync(cancellationToken);
        try
        {
            await writer.WriteLineAsync(line.AsMemory(), cancellationToken);
        }
        finally
        {
            writeLock.Release();
        }
    }

    private void RemoveClient(TcpClient client)
    {
        if (_clients.TryRemove(client, out var writer))
        {
            _writeLocks.TryRemove(writer, out var writeLock);
            writeLock?.Dispose();
            writer.Dispose();
            client.Dispose();
            ClientDisconnected?.Invoke(client);
        }
    }

    public void Dispose()
    {
        if (_shutdown.IsCancellationRequested)
        {
            return;
        }

        _shutdown.Cancel();
        _listener.Stop();
        foreach (var client in _clients.Keys)
        {
            RemoveClient(client);
        }
        _shutdown.Dispose();
    }
}