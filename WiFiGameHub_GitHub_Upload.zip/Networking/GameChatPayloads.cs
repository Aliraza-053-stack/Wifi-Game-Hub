using System.Collections.Concurrent;

namespace WiFiGameHub.Networking;

public sealed class GameChatEntry
{
    public string MessageId { get; set; } = Guid.NewGuid().ToString("N");
    public string RoomId { get; set; } = string.Empty;
    public string SenderId { get; set; } = string.Empty;
    public string SenderName { get; set; } = string.Empty;
    public string Text { get; set; } = string.Empty;
    public DateTime SentAtUtc { get; set; } = DateTime.UtcNow;
}

public sealed class GameImageChunk
{
    public string TransferId { get; set; } = string.Empty;
    public string FileName { get; set; } = string.Empty;
    public string ContentType { get; set; } = string.Empty;
    public int Index { get; set; }
    public int TotalChunks { get; set; }
    public string Data { get; set; } = string.Empty;
}

public sealed class SharedGameImage
{
    public string TransferId { get; init; } = string.Empty;
    public string FileName { get; init; } = string.Empty;
    public string ContentType { get; init; } = string.Empty;
    public byte[] Bytes { get; init; } = Array.Empty<byte>();
    public string SenderName { get; init; } = string.Empty;
}

public sealed class GameImageAssembler
{
    public const int ChunkByteLimit = 24_000;
    public const int ImageByteLimit = 2 * 1024 * 1024;
    public const int ChunkCountLimit = (ImageByteLimit + ChunkByteLimit - 1) / ChunkByteLimit;

    private sealed class Transfer
    {
        public required string FileName { get; init; }
        public required string ContentType { get; init; }
        public required string SenderName { get; init; }
        public required string[] Chunks { get; init; }
        public DateTime LastUpdatedUtc { get; set; }
        public int ReceivedChunks { get; set; }
        public int TotalBytes { get; set; }
    }

    private readonly ConcurrentDictionary<string, Transfer> _transfers = new(StringComparer.Ordinal);

    public static IEnumerable<GameImageChunk> CreateChunks(string fileName, string contentType, ReadOnlyMemory<byte> imageBytes)
    {
        if (imageBytes.Length is < 1 or > ImageByteLimit)
        {
            throw new ArgumentOutOfRangeException(nameof(imageBytes), $"Images must be at most {ImageByteLimit / 1024} KiB.");
        }
        if (contentType is not ("image/png" or "image/jpeg" or "image/bmp" or "image/gif"))
        {
            throw new ArgumentException("Supported images are PNG, JPEG, BMP, and GIF.", nameof(contentType));
        }

        var transferId = Guid.NewGuid().ToString("N");
        var total = (imageBytes.Length + ChunkByteLimit - 1) / ChunkByteLimit;
        for (var index = 0; index < total; index++)
        {
            var offset = index * ChunkByteLimit;
            var count = Math.Min(ChunkByteLimit, imageBytes.Length - offset);
            yield return new GameImageChunk
            {
                TransferId = transferId,
                FileName = Path.GetFileName(fileName),
                ContentType = contentType,
                Index = index,
                TotalChunks = total,
                Data = Convert.ToBase64String(imageBytes.Span.Slice(offset, count))
            };
        }
    }

    public bool TryAddChunk(GameImageChunk chunk, string senderName, out SharedGameImage? image)
    {
        image = null;
        ExpireStaleTransfers();
        if (string.IsNullOrWhiteSpace(chunk.TransferId) || chunk.TransferId.Length > 64
            || string.IsNullOrWhiteSpace(chunk.FileName) || chunk.FileName.Length > 128
            || chunk.ContentType is not ("image/png" or "image/jpeg" or "image/bmp" or "image/gif")
            || chunk.TotalChunks is < 1 or > ChunkCountLimit
            || chunk.Index < 0 || chunk.Index >= chunk.TotalChunks
            || chunk.Data.Length > ChunkByteLimit * 4 / 3 + 8)
        {
            return false;
        }

        byte[] bytes;
        try
        {
            bytes = Convert.FromBase64String(chunk.Data);
        }
        catch (FormatException)
        {
            return false;
        }
        if (bytes.Length > ChunkByteLimit)
        {
            return false;
        }

        if (!_transfers.ContainsKey(chunk.TransferId) && _transfers.Count >= 8)
        {
            return false;
        }

        var transfer = _transfers.GetOrAdd(chunk.TransferId, _ => new Transfer
        {
            FileName = Path.GetFileName(chunk.FileName),
            ContentType = chunk.ContentType,
            SenderName = senderName,
            Chunks = new string[chunk.TotalChunks],
            LastUpdatedUtc = DateTime.UtcNow
        });

        lock (transfer)
        {
            if (transfer.Chunks.Length != chunk.TotalChunks
                || transfer.FileName != Path.GetFileName(chunk.FileName)
                || transfer.ContentType != chunk.ContentType
                || transfer.Chunks[chunk.Index] is not null)
            {
                return false;
            }
            transfer.Chunks[chunk.Index] = chunk.Data;
            transfer.ReceivedChunks++;
            transfer.TotalBytes += bytes.Length;
            transfer.LastUpdatedUtc = DateTime.UtcNow;
            if (transfer.TotalBytes > ImageByteLimit)
            {
                _transfers.TryRemove(chunk.TransferId, out _);
                return false;
            }
            if (transfer.ReceivedChunks != transfer.Chunks.Length)
            {
                return true;
            }

            var combined = new byte[transfer.TotalBytes];
            var destinationOffset = 0;
            foreach (var encodedChunk in transfer.Chunks)
            {
                var piece = Convert.FromBase64String(encodedChunk);
                piece.CopyTo(combined, destinationOffset);
                destinationOffset += piece.Length;
            }
            image = new SharedGameImage
            {
                TransferId = chunk.TransferId,
                FileName = transfer.FileName,
                ContentType = transfer.ContentType,
                SenderName = transfer.SenderName,
                Bytes = combined
            };
            _transfers.TryRemove(chunk.TransferId, out _);
        }
        return true;
    }

    public void ExpireStaleTransfers(TimeSpan? lifetime = null)
    {
        var cutoff = DateTime.UtcNow - (lifetime ?? TimeSpan.FromSeconds(30));
        foreach (var entry in _transfers.Where(entry => entry.Value.LastUpdatedUtc < cutoff))
        {
            _transfers.TryRemove(entry.Key, out _);
        }
    }
}
