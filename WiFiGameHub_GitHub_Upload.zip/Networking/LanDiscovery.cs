using System.Net;
using System.Net.Sockets;
using System.Text;
using System.Text.Json;

namespace WiFiGameHub.Networking;

public sealed class LanRoomAnnouncement
{
    public string RoomId { get; set; } = string.Empty;
    public string RoomName { get; set; } = string.Empty;
    public string Game { get; set; } = string.Empty;
    public string HostName { get; set; } = string.Empty;
    public string HostIp { get; set; } = string.Empty;
    public int Port { get; set; }
    public int CurrentPlayers { get; set; }
    public int MaxPlayers { get; set; }
    public string Status { get; set; } = "Waiting";

    public bool IsValid()
    {
        return RoomId.Length is > 0 and <= 64
            && RoomName.Length is > 0 and <= 64
            && (Game == "Ludo" || Game == "TicTacToe" || Game == "Chess" || Game == "Chat" || Game == "Carrom")
            && HostName.Length is > 0 and <= 64
            && IPAddress.TryParse(HostIp, out _)
            && Port is >= 1 and <= 65535
            && CurrentPlayers >= 1
            && MaxPlayers is >= 2 and <= 4
            && CurrentPlayers <= MaxPlayers;
    }
}

public sealed class LanDiscovery : IDisposable
{
    public const int DiscoveryPort = 45455;
    private readonly int _discoveryPort;
    private IPEndPoint BroadcastEndpoint => new(IPAddress.Broadcast, _discoveryPort);
    private UdpClient? _receiver;
    private CancellationTokenSource? _cancellation;

    public event EventHandler<string>? HostDiscovered;
    public event Action<LanRoomAnnouncement>? RoomDiscovered;

    public LanDiscovery(int discoveryPort = DiscoveryPort)
    {
        if (discoveryPort is < 1 or > 65535)
        {
            throw new ArgumentOutOfRangeException(nameof(discoveryPort));
        }
        _discoveryPort = discoveryPort;
    }

    public void StartListening()
    {
        if (_receiver is not null)
        {
            return;
        }

        _cancellation = new CancellationTokenSource();
        _receiver = new UdpClient(AddressFamily.InterNetwork);
        _receiver.Client.SetSocketOption(SocketOptionLevel.Socket, SocketOptionName.ReuseAddress, true);
        _receiver.Client.Bind(new IPEndPoint(IPAddress.Any, _discoveryPort));
        _ = ReceiveLoopAsync(_receiver, _cancellation.Token);
    }

    private async Task ReceiveLoopAsync(UdpClient receiver, CancellationToken cancellationToken)
    {
        while (!cancellationToken.IsCancellationRequested)
        {
            try
            {
                var result = await receiver.ReceiveAsync(cancellationToken);
                var announcement = ParseAnnouncement(Encoding.UTF8.GetString(result.Buffer));
                if (announcement is null)
                {
                    continue;
                }

                if (!IPAddress.TryParse(announcement.HostIp, out _))
                {
                    announcement.HostIp = result.RemoteEndPoint.Address.ToString();
                }
                RoomDiscovered?.Invoke(announcement);
                HostDiscovered?.Invoke(this, JsonSerializer.Serialize(announcement));
            }
            catch (OperationCanceledException) when (cancellationToken.IsCancellationRequested)
            {
                break;
            }
            catch (ObjectDisposedException) when (cancellationToken.IsCancellationRequested)
            {
                break;
            }
            catch (SocketException) when (cancellationToken.IsCancellationRequested)
            {
                break;
            }
            catch (JsonException)
            {
            }
        }
    }

    public static LanRoomAnnouncement? ParseAnnouncement(string json)
    {
        if (string.IsNullOrWhiteSpace(json) || json.Length > 4096)
        {
            return null;
        }

        try
        {
            var announcement = JsonSerializer.Deserialize<LanRoomAnnouncement>(json);
            return announcement is { } && announcement.IsValid() ? announcement : null;
        }
        catch (JsonException)
        {
            return null;
        }
    }

    public void BroadcastHost(LanRoomAnnouncement announcement)
    {
        ArgumentNullException.ThrowIfNull(announcement);
        if (!announcement.IsValid())
        {
            throw new ArgumentException("Room announcement is invalid.", nameof(announcement));
        }

        var buffer = Encoding.UTF8.GetBytes(JsonSerializer.Serialize(announcement));
        using var broadcaster = new UdpClient(AddressFamily.InterNetwork) { EnableBroadcast = true };
        broadcaster.Send(buffer, buffer.Length, BroadcastEndpoint);
    }

    public void BroadcastHost(string roomId, string hostName)
    {
        BroadcastHost(new LanRoomAnnouncement
        {
            RoomId = roomId,
            RoomName = roomId,
            Game = "TicTacToe",
            HostName = hostName,
            HostIp = IPAddress.Loopback.ToString(),
            Port = 9000,
            CurrentPlayers = 1,
            MaxPlayers = 2
        });
    }

    public void StopListening()
    {
        _cancellation?.Cancel();
        _receiver?.Dispose();
        _receiver = null;
        _cancellation?.Dispose();
        _cancellation = null;
    }

    public void Dispose() => StopListening();
}