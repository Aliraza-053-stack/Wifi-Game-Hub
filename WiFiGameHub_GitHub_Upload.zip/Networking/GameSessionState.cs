using WiFiGameHub.Games.TicTacToe;
using WiFiGameHub.Games.Carrom;

namespace WiFiGameHub.Networking;

public sealed class GameActionRequest
{
    public string ActionId { get; set; } = Guid.NewGuid().ToString("N");
    public long ExpectedRevision { get; set; }
    public string Action { get; set; } = string.Empty;
    public int Row { get; set; } = -1;
    public int Column { get; set; } = -1;
    public int TokenIndex { get; set; } = -1;
    public int FromRow { get; set; } = -1;
    public int FromColumn { get; set; } = -1;
    public char Promotion { get; set; } = 'Q';
    public float CarromStrikerX { get; set; }
    public float CarromAimX { get; set; }
    public float CarromAimY { get; set; }
    public float CarromPower { get; set; }
}

public sealed class GameSessionPlayer
{
    public string PlayerId { get; set; } = string.Empty;
    public string Name { get; set; } = string.Empty;
    public string Mark { get; set; } = string.Empty;
    public string Color { get; set; } = string.Empty;
    public bool Connected { get; set; }
}

public sealed class GameSessionState
{
    public string RoomId { get; set; } = string.Empty;
    public string Game { get; set; } = string.Empty;
    public long Revision { get; set; }
    public bool Started { get; set; }
    public List<GameSessionPlayer> Players { get; set; } = new();
    public string CurrentPlayerId { get; set; } = string.Empty;
    public string CurrentPlayerMark { get; set; } = "X";
    public bool IsGameOver { get; set; }
    public bool IsDraw { get; set; }
    public bool IsForfeit { get; set; }
    public string WinnerId { get; set; } = string.Empty;
    public string WinnerMark { get; set; } = string.Empty;
    public string WinnerName { get; set; } = string.Empty;
    public int XScore { get; set; }
    public int OScore { get; set; }
    public TicTacToeMark[] TicTacToeBoard { get; set; } = Array.Empty<TicTacToeMark>();
    public int[] WinningCells { get; set; } = Array.Empty<int>();
    public int[] LudoTokenPositions { get; set; } = Array.Empty<int>();
    public int CurrentLudoPlayerIndex { get; set; }
    public int DiceValue { get; set; }
    public int PendingDiceValue { get; set; }
    public string[] MoveHistory { get; set; } = Array.Empty<string>();
    public string ChessFen { get; set; } = string.Empty;
    public long DepartureSequence { get; set; }
    public string LastDepartedPlayerId { get; set; } = string.Empty;
    public string LastDepartedPlayerName { get; set; } = string.Empty;
    public CarromPieceSnapshot[] CarromPieces { get; set; } = Array.Empty<CarromPieceSnapshot>();
    public int CarromShotNumber { get; set; }
    public int CarromCurrentPlayerIndex { get; set; }
    public int CarromWhiteScore { get; set; }
    public int CarromBlackScore { get; set; }
    public int CarromWhiteFouls { get; set; }
    public int CarromBlackFouls { get; set; }
    public int CarromWhitePocketedCoins { get; set; }
    public int CarromBlackPocketedCoins { get; set; }
    public int CarromCompletedBoards { get; set; }
    public int CarromWhiteTotalPocketedCoins { get; set; }
    public int CarromBlackTotalPocketedCoins { get; set; }
    public int CarromWhiteQueenBonus { get; set; }
    public int CarromBlackQueenBonus { get; set; }
    public int CarromQueenPendingCoverByPlayer { get; set; } = -1;
    public bool CarromQueenClaimed { get; set; }
    public int CarromQueenClaimedByPlayer { get; set; } = -1;
    public bool CarromBoardComplete { get; set; }
    public int CarromMatchWinnerIndex { get; set; } = -1;
    public string CarromLastResult { get; set; } = string.Empty;
    public string CarromLastShotActionId { get; set; } = string.Empty;
    public string CarromLastShotPlayerId { get; set; } = string.Empty;
    public float CarromLastShotStrikerX { get; set; }
    public float CarromLastShotAimX { get; set; }
    public float CarromLastShotAimY { get; set; }
    public float CarromLastShotPower { get; set; }
    public long CarromMatchDurationSeconds { get; set; }
}