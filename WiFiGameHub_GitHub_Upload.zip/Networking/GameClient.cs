using System.Net;
using System.Net.Sockets;
using System.Text;

namespace WiFiGameHub.Networking;

public sealed class GameClient : IDisposable
{
    private TcpClient? _client;
    private StreamWriter? _writer;
    private readonly SemaphoreSlim _writeLock = new(1, 1);
    private CancellationTokenSource? _receiverCancellation;

    public event Action<NetworkMessage>? MessageReceived;
    public event Action<string>? ConnectionClosed;
    public bool IsConnected => _client?.Connected == true;

    public async Task ConnectAsync(string hostName, int port, CancellationToken cancellationToken = default)
    {
        if (string.IsNullOrWhiteSpace(hostName))
        {
            throw new ArgumentException("A host name or IP address is required.", nameof(hostName));
        }

        if (port is < IPEndPoint.MinPort or > IPEndPoint.MaxPort)
        {
            throw new ArgumentOutOfRangeException(nameof(port));
        }

        if (_client is not null)
        {
            throw new InvalidOperationException("This client has already been used. Dispose it before reconnecting.");
        }

        using var timeout = CancellationTokenSource.CreateLinkedTokenSource(cancellationToken);
        timeout.CancelAfter(TimeSpan.FromSeconds(8));
        var client = new TcpClient { NoDelay = true };
        TcpKeepAlive.Configure(client);
        await client.ConnectAsync(hostName, port, timeout.Token);
        _client = client;
        _writer = new StreamWriter(client.GetStream(), new UTF8Encoding(false), leaveOpen: true) { AutoFlush = true };
        _receiverCancellation = new CancellationTokenSource();
        _ = ReceiveLoopAsync(client, _receiverCancellation.Token);
    }

    public async Task SendMessageAsync(NetworkMessage message, CancellationToken cancellationToken = default)
    {
        if (_client?.Connected != true || _writer is null)
        {
            throw new InvalidOperationException("Client is not connected.");
        }

        var json = message.ToJson();
        await _writeLock.WaitAsync(cancellationToken);
        try
        {
            await _writer.WriteLineAsync(json.AsMemory(), cancellationToken);
        }
        finally
        {
            _writeLock.Release();
        }
    }

    public async Task SendMessageAsync(string json, CancellationToken cancellationToken = default)
    {
        var message = NetworkMessage.FromJson(json);
        await SendMessageAsync(message, cancellationToken);
    }

    private async Task ReceiveLoopAsync(TcpClient client, CancellationToken cancellationToken)
    {
        var reason = "Connection closed by host.";
        try
        {
            using var reader = new StreamReader(client.GetStream(), Encoding.UTF8, false, 4096, leaveOpen: true);
            while (!cancellationToken.IsCancellationRequested)
            {
                var line = await reader.ReadLineAsync(cancellationToken);
                if (line is null)
                {
                    break;
                }

                MessageReceived?.Invoke(NetworkMessage.FromJson(line));
            }
        }
        catch (OperationCanceledException)
        {
            reason = "Disconnected.";
        }
        catch (IOException exception)
        {
            reason = exception.Message;
        }
        catch (System.Text.Json.JsonException exception)
        {
            reason = $"Invalid server message: {exception.Message}";
        }
        finally
        {
            ConnectionClosed?.Invoke(reason);
        }
    }

    public void Dispose()
    {
        _receiverCancellation?.Cancel();
        _writer?.Dispose();
        _client?.Dispose();
        _receiverCancellation?.Dispose();
        _writeLock.Dispose();
    }
}