using System.Text.Json;

namespace WiFiGameHub.Networking;

public enum NetworkMessageType
{
    Ping,
    RoomList,
    HostCreated,
    JoinRequest,
    JoinAccepted,
    JoinRejected,
    StartGame,
    RollDiceRequest,
    GameState,
    Move,
    Chat,
    ImageChunk,
    RestartGame,
    NewMatch,
    Disconnect,
    Error
}

public class NetworkMessage
{
    public string MessageId { get; set; } = Guid.NewGuid().ToString("N");
    public string SenderId { get; set; } = string.Empty;
    public string RoomId { get; set; } = string.Empty;
    public string PlayerName { get; set; } = string.Empty;
    public NetworkMessageType Type { get; set; }
    public string Payload { get; set; } = string.Empty;

    public string ToJson()
    {
        Validate();
        return JsonSerializer.Serialize(this);
    }

    public static NetworkMessage FromJson(string json)
    {
        if (string.IsNullOrWhiteSpace(json) || json.Length > 65_536)
        {
            throw new JsonException("Message is empty or exceeds the 64 KiB limit.");
        }

        var message = JsonSerializer.Deserialize<NetworkMessage>(json)
            ?? throw new JsonException("Message body is empty.");
        try
        {
            message.Validate();
        }
        catch (ArgumentException exception)
        {
            throw new JsonException(exception.Message, exception);
        }

        return message;
    }

    public void Validate()
    {
        if (string.IsNullOrWhiteSpace(MessageId) || MessageId.Length > 64)
        {
            throw new ArgumentException("MessageId must contain 1 to 64 characters.", nameof(MessageId));
        }

        if (string.IsNullOrWhiteSpace(SenderId) || SenderId.Length > 128)
        {
            throw new ArgumentException("SenderId must contain 1 to 128 characters.", nameof(SenderId));
        }

        if (RoomId.Length > 64 || PlayerName.Length > 64 || Payload.Length > 60_000)
        {
            throw new ArgumentException("One or more message fields exceed their allowed length.");
        }

        if (!Enum.IsDefined(Type))
        {
            throw new ArgumentException("Message type is not recognized.", nameof(Type));
        }
    }
}
