using WiFiGameHub.Models;

namespace WiFiGameHub.Services;

public static class PlayerService
{
    public static string CurrentPlayerName { get; set; } = "Player";
    public static string CurrentRoomId { get; set; } = string.Empty;

    public static Player CreatePlayer(string name)
    {
        return new Player(name, false);
    }
}
