using System.Text.Json;

namespace WiFiGameHub.Services;

public sealed class AppPreferences
{
    private static readonly string PreferencesPath = Path.Combine(
        Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData),
        "WiFiGameHub",
        "settings.json");

    public static AppPreferences Current { get; private set; } = new();
    public static string? LoadError { get; private set; }

    public string PlayerName { get; set; } = "Player";
    public bool SoundEnabled { get; set; } = true;
    public bool DarkThemeEnabled { get; set; } = true;
    public int NetworkPort { get; set; } = 45456;

    public static void Load()
    {
        if (!File.Exists(PreferencesPath))
        {
            Current = new AppPreferences();
            return;
        }

        try
        {
            var json = File.ReadAllText(PreferencesPath);
            Current = JsonSerializer.Deserialize<AppPreferences>(json) ?? new AppPreferences();
            if (Current.NetworkPort is < 1 or > 65535 || string.IsNullOrWhiteSpace(Current.PlayerName))
            {
                throw new JsonException("Saved player name or network port is invalid.");
            }
            LoadError = null;
        }
        catch (Exception exception) when (exception is IOException or UnauthorizedAccessException or JsonException)
        {
            Current = new AppPreferences();
            LoadError = exception.Message;
        }
    }

    public static void Save()
    {
        Directory.CreateDirectory(Path.GetDirectoryName(PreferencesPath)!);
        var json = JsonSerializer.Serialize(Current, new JsonSerializerOptions { WriteIndented = true });
        File.WriteAllText(PreferencesPath, json);
        LoadError = null;
    }
}