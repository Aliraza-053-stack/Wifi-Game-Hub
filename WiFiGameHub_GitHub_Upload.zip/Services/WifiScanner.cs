using System.Diagnostics;
using System.Text.RegularExpressions;

namespace WiFiGameHub.Services;

public class WifiNetwork
{
    public string Ssid { get; set; } = string.Empty;
    public int SignalStrength { get; set; }
    public string Authentication { get; set; } = "Unknown";
    public bool IsConnected { get; set; }
}

public sealed record WifiScanResult(
    bool? WifiEnabled,
    string ConnectedNetwork,
    IReadOnlyList<WifiNetwork> Networks,
    string? ErrorMessage);

public static partial class WifiScanner
{
    public static async Task<List<WifiNetwork>> ScanNetworksAsync()
    {
        var result = await ScanNetworksDetailedAsync();
        return result.Networks.ToList();
    }

    public static async Task<WifiScanResult> ScanNetworksDetailedAsync()
    {
        try
        {
            var interfaceOutput = await RunCommandAsync("wlan show interfaces");
            if (ContainsUnavailableAdapterMessage(interfaceOutput))
            {
                return new WifiScanResult(false, string.Empty, Array.Empty<WifiNetwork>(), null);
            }
            var networkOutput = await RunCommandAsync("wlan show networks mode=bssid");
            return CreateScanResult(networkOutput, interfaceOutput);
        }
        catch (Exception exception) when (exception is InvalidOperationException
            or IOException
            or UnauthorizedAccessException
            or TimeoutException
            or System.ComponentModel.Win32Exception)
        {
            return new WifiScanResult(null, string.Empty, Array.Empty<WifiNetwork>(), exception.Message);
        }
    }

    public static WifiScanResult CreateScanResult(string networkOutput, string interfaceOutput)
    {
        var commandError = FindCommandError(networkOutput) ?? FindCommandError(interfaceOutput);
        if (commandError is not null)
        {
            return new WifiScanResult(null, string.Empty, Array.Empty<WifiNetwork>(), commandError);
        }

        var disabled = ContainsUnavailableAdapterMessage(networkOutput)
            || ContainsUnavailableAdapterMessage(interfaceOutput);
        if (disabled)
        {
            return new WifiScanResult(false, string.Empty, Array.Empty<WifiNetwork>(), null);
        }

        var networks = ParseNetworksOutput(networkOutput);
        var connected = ParseCurrentConnectedNetwork(interfaceOutput);
        if (!string.IsNullOrWhiteSpace(connected))
        {
            var connectedNetwork = networks.FirstOrDefault(network =>
                string.Equals(network.Ssid, connected, StringComparison.OrdinalIgnoreCase));
            if (connectedNetwork is null)
            {
                connectedNetwork = new WifiNetwork { Ssid = connected };
                networks.Add(connectedNetwork);
            }
            connectedNetwork.IsConnected = true;
        }

        return new WifiScanResult(true, connected, networks, null);
    }

    public static List<WifiNetwork> ParseNetworksOutput(string output)
    {
        var networks = new List<WifiNetwork>();
        string? currentSsid = null;
        var currentSignal = 0;
        var currentAuth = "Unknown";

        void SaveCurrentNetwork()
        {
            if (!string.IsNullOrWhiteSpace(currentSsid))
            {
                networks.Add(new WifiNetwork
                {
                    Ssid = currentSsid,
                    SignalStrength = currentSignal,
                    Authentication = currentAuth
                });
            }
        }

        foreach (var line in output.Split(new[] { "\r\n", "\n" }, StringSplitOptions.RemoveEmptyEntries))
        {
            var trimmed = line.Trim();
            if (trimmed.StartsWith("SSID", StringComparison.OrdinalIgnoreCase)
                && !trimmed.StartsWith("BSSID", StringComparison.OrdinalIgnoreCase))
            {
                var separator = trimmed.IndexOf(':');
                if (separator < 0)
                {
                    continue;
                }

                SaveCurrentNetwork();
                currentSsid = trimmed[(separator + 1)..].Trim();
                currentSignal = 0;
                currentAuth = "Unknown";
            }
            else if (trimmed.StartsWith("Authentication", StringComparison.OrdinalIgnoreCase))
            {
                var separator = trimmed.IndexOf(':');
                if (separator >= 0)
                {
                    var value = trimmed[(separator + 1)..].Trim();
                    currentAuth = string.IsNullOrWhiteSpace(value) ? "Unknown" : value;
                }
            }
            else if (trimmed.StartsWith("Signal", StringComparison.OrdinalIgnoreCase))
            {
                var match = SignalRegex().Match(trimmed);
                if (match.Success && int.TryParse(match.Value.TrimEnd('%'), out var parsedSignal))
                {
                    currentSignal = Math.Max(currentSignal, Math.Clamp(parsedSignal, 0, 100));
                }
            }
        }

        SaveCurrentNetwork();
        return networks.DistinctBy(network => network.Ssid, StringComparer.OrdinalIgnoreCase).ToList();
    }

    public static async Task<string> GetCurrentConnectedNetworkAsync()
    {
        try
        {
            var output = await RunCommandAsync("wlan show interfaces");
            if (string.IsNullOrWhiteSpace(output))
            {
                return string.Empty;
            }

            return ParseCurrentConnectedNetwork(output);
        }
        catch (Exception ex) when (ex is InvalidOperationException
            or IOException
            or UnauthorizedAccessException
            or TimeoutException
            or System.ComponentModel.Win32Exception)
        {
            Console.WriteLine(ex.Message);
        }

        return string.Empty;
    }

    public static async Task<bool> IsWifiEnabledAsync()
    {
        try
        {
            var output = await RunCommandAsync("wlan show interfaces");
            if (output.Contains("not available", StringComparison.OrdinalIgnoreCase) ||
                output.Contains("disabled", StringComparison.OrdinalIgnoreCase) ||
                output.Contains("no wireless interface", StringComparison.OrdinalIgnoreCase) ||
                output.Contains("no wireless adapter", StringComparison.OrdinalIgnoreCase))
            {
                return false;
            }

            return true;
        }
        catch (Exception exception) when (exception is InvalidOperationException
            or IOException
            or UnauthorizedAccessException
            or TimeoutException
            or System.ComponentModel.Win32Exception)
        {
            return false;
        }
    }

    public static string ParseCurrentConnectedNetwork(string output)
    {
        foreach (var line in output.Split(new[] { "\r\n", "\n" }, StringSplitOptions.RemoveEmptyEntries))
        {
            var trimmed = line.TrimStart();
            if (!trimmed.StartsWith("SSID", StringComparison.OrdinalIgnoreCase)
                || trimmed.StartsWith("BSSID", StringComparison.OrdinalIgnoreCase))
            {
                continue;
            }

            var separator = trimmed.IndexOf(':');
            if (separator < 0)
            {
                continue;
            }

            var value = trimmed[(separator + 1)..].Trim();
            if (!string.IsNullOrWhiteSpace(value) && !value.Contains("BSSID", StringComparison.OrdinalIgnoreCase))
            {
                return value;
            }
        }

        return string.Empty;
    }

    private static bool ContainsUnavailableAdapterMessage(string output) =>
        output.Contains("not available", StringComparison.OrdinalIgnoreCase)
        || output.Contains("disabled", StringComparison.OrdinalIgnoreCase)
        || output.Contains("no wireless interface", StringComparison.OrdinalIgnoreCase)
        || output.Contains("no wireless adapter", StringComparison.OrdinalIgnoreCase)
        || output.Contains("there is no wireless interface", StringComparison.OrdinalIgnoreCase);

    private static string? FindCommandError(string output)
    {
        var errorPhrases = new[]
        {
            "The Wireless AutoConfig Service",
            "Access is denied",
            "requires elevation",
            "not recognized as an internal or external command",
            "The system cannot find"
        };
        return errorPhrases.Any(phrase => output.Contains(phrase, StringComparison.OrdinalIgnoreCase))
            ? output.Trim()
            : null;
    }

    private static async Task<string> RunCommandAsync(string arguments)
    {
        using var process = new Process();
        process.StartInfo = new ProcessStartInfo
        {
            FileName = "netsh.exe",
            Arguments = arguments,
            RedirectStandardOutput = true,
            RedirectStandardError = true,
            UseShellExecute = false,
            CreateNoWindow = true
        };

        process.Start();
        using var timeout = new CancellationTokenSource(TimeSpan.FromSeconds(8));
        var outputTask = process.StandardOutput.ReadToEndAsync(timeout.Token);
        var errorTask = process.StandardError.ReadToEndAsync(timeout.Token);
        try
        {
            await process.WaitForExitAsync(timeout.Token);
        }
        catch (OperationCanceledException)
        {
            process.Kill(entireProcessTree: true);
            throw new TimeoutException($"The Windows Wi-Fi command timed out: {arguments}");
        }

        var output = await outputTask;
        var error = await errorTask;

        if (process.ExitCode != 0)
        {
            throw new InvalidOperationException(string.IsNullOrWhiteSpace(error) ? output.Trim() : error.Trim());
        }

        return string.IsNullOrWhiteSpace(output) ? error : output;
    }

    [GeneratedRegex(@"\d{1,3}%")]
    private static partial Regex SignalRegex();
}
