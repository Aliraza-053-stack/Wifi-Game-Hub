using System.Media;

namespace WiFiGameHub.Services;

public static class GameAudio
{
    public static void PlayClick()
    {
        if (AppPreferences.Current.SoundEnabled)
        {
            SystemSounds.Asterisk.Play();
        }
    }

    public static void PlayMove()
    {
        if (AppPreferences.Current.SoundEnabled)
        {
            SystemSounds.Asterisk.Play();
        }
    }

    public static void PlayDice()
    {
        if (AppPreferences.Current.SoundEnabled)
        {
            SystemSounds.Beep.Play();
        }
    }

    public static void PlayWin()
    {
        if (AppPreferences.Current.SoundEnabled)
        {
            SystemSounds.Exclamation.Play();
        }
    }
}