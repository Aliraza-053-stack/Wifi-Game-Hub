# WiFi Game Hub

WiFi Game Hub is a Windows desktop application built with C# and .NET 8 Windows Forms. It includes local Chess, Ludo, Tic-Tac-Toe, playable Carrom, LAN rooms, in-game chat, and Windows Wi-Fi information.

Developer: Ali Raza. Project Supervisor: Sir Muhammad Abdullah.

## Requirements

- Windows 10 or later.
- .NET 8 SDK with Windows desktop targeting support.
- Visual Studio 2022 or VS Code with the C# extension (optional).

## Open, build, and run

Open `WiFiGameHub.sln` in Visual Studio, or run these commands from the project folder in PowerShell:

```powershell
dotnet restore ".\visual project.csproj"
dotnet build ".\visual project.csproj" -c Release
dotnet run --project ".\visual project.csproj"
```

To run the automated tests:

```powershell
dotnet test ".\WiFiGameHub.Tests\WiFiGameHub.Tests.csproj" -c Release
```

## Play locally

1. Start the app and choose a game from **Games** or its Dashboard card.
2. Select **Play Locally** in the game-mode screen.
3. Chess and Tic-Tac-Toe are local two-player games; take turns at the same computer.
4. Ludo supports two to four local players. Choose the player count and pass the device between turns.
5. Carrom is a local two-player match. Position the striker on the baseline, pull back to aim, then release to shoot. The board tracks turns, scoring, Queen cover, fouls, and match results.
6. Use **Back**, **Exit**, or **Return to Dashboard** controls to leave a game.

## Features

- Local two-player Chess and Tic-Tac-Toe.
- Local Ludo for two to four players.
- Local two-player Carrom with striker positioning, aiming, physics, friction, collisions, pockets, scoring, Queen cover, fouls, and match results.
- LAN rooms for Chess, Ludo, Tic-Tac-Toe, Carrom, and Chat Only.
- Room discovery over UDP and game/chat communication over TCP.
- TCP connection attempts time out after 8 seconds; TCP keep-alive probes detect idle broken connections.
- Host-authoritative multiplayer game state.
- Carrom multiplayer shot playback with host snapshot reconciliation and a shared match-result summary.
- Multiplayer departure notices and two-player forfeit results; Ludo keeps connected players in play when another player leaves.
- Local and room chat.
- Nearby Wi-Fi scanning in Network Center, with SSID, signal strength, security type when available, and the connected network indicator. Scanning does not request or display passwords.
- Saved player, port, and sound preferences.

Carrom **Play with Friends** uses the existing LAN room workflow. The host plays White and is authoritative for physics and rules; the joining player plays Black. Players submit only striker/aim/power input. The host validates the player, turn, revision, baseline position, and power, simulates the shot, then broadcasts a settled board and score snapshot. Clients do not submit coin positions or scores.

### Carrom scoring summary

- Pocketing an own-colour coin keeps the turn; otherwise the turn passes. An opponent coin pocketed by the active player is returned to the board and does not score for that player.
- The Queen is shared, may be claimed only after the player has pocketed an own coin, and must be covered by an own coin on the same or immediately following turn. Otherwise, the Queen returns to the board.
- A striker pocket is a foul: pieces pocketed on that shot are returned, the foul is counted, and the turn passes. This implementation does not subtract score points for fouls.
- A board ends when a player clears their assigned coins and any Queen cover is resolved. The board winner scores one point per opponent coin remaining, plus 3 for a covered Queen. Match target is 25 points, with an 8-board limit. Scores are awarded only at board completion.
- Carrom rule values are configurable in `CarromRulesOptions`; local and LAN games use the same rules engine.

## LAN setup

Both computers must be on the same local network and able to communicate directly.

1. On the host, open **Multiplayer Rooms** (or choose **Play in Room** from a game), select the game, enter a player name and TCP port, and choose **Create Room**.
2. Share the displayed room ID with the other player. The room is also announced on the local network.
3. On the joining computer, select the discovered room, or enter the host address, TCP port, room ID, game, and player name and choose **Join by ID**.
4. Confirm both players appear as connected in the room lobby. The host can open the game once another player is connected. Ludo also requires the host to choose **New Match** in Ludo Arena; guests can open Ludo after the match starts. For Carrom, the host plays White and the joining player plays Black.
5. Use the lobby **Chat** tab to exchange messages. Chat Only rooms do not have a game-start button.

The default game TCP port is `45456`; LAN room discovery uses UDP `45455`. Allow the selected TCP port on the host and UDP `45455` on both computers through Windows Defender Firewall. Guest Wi-Fi or router client isolation may block peer-to-peer connections.

Wi-Fi scanning is available from **Network Center**, separate from LAN room discovery. Use its refresh/scan action to update nearby networks; scanning depends on Windows wireless hardware and `netsh wlan` availability. The Dashboard keeps its focus on game navigation and room status.

## Verification status

The automated xUnit suite covers game rules, Carrom scoring/Queen/foul behavior, navigation, UI state, Wi-Fi scan result handling, and loopback TCP session synchronization, including Carrom host validation, shot playback metadata, Queen cover, striker fouls, match completion, and disconnect handling. Loopback testing uses the same computer and does not prove that Wi-Fi discovery or multiplayer works across two physical PCs. Carrom requires the host application to remain connected; reconnecting to an interrupted Carrom match is not supported. Complete the [two-PC test checklist](./Documentation/Multiplayer_Two_PC_Test_Guide.md) before claiming cross-device verification.

The project is Windows-specific because it uses Windows Forms and Windows Wi-Fi commands. Wi-Fi scan automated tests cover parsing and error-state handling; an actual wireless adapter scan was not part of this verification run.
