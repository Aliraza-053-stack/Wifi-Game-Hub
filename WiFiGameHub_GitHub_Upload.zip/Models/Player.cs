namespace WiFiGameHub.Models;

public class Player
{
    public string Id { get; set; } = Guid.NewGuid().ToString("N");
    public string Name { get; set; } = "Guest";
    public bool IsHost { get; set; }
    public string ConnectionIp { get; set; } = "127.0.0.1";

    public Player()
    {
    }

    public Player(string name, bool isHost = false)
    {
        Name = name;
        IsHost = isHost;
    }
}
