namespace WiFiGameHub.Models;

public enum GameType
{
    TicTacToe,
    Ludo,
    Chess,
    Chat,
    Carrom
}

public class GameRoom
{
    public string Id { get; set; } = Guid.NewGuid().ToString("N")[..8];
    public string Name { get; set; } = "New Room";
    public GameType GameType { get; set; }
    public List<Player> Players { get; set; } = new();
    public bool IsPublic { get; set; } = true;
    public string HostIp { get; set; } = "127.0.0.1";
    public int Port { get; set; } = 9000;
    public string Status { get; set; } = "Waiting";

    public int MaxPlayers => GameType == GameType.Ludo ? 4 : 2;
    public bool IsFull => Players.Count >= MaxPlayers;

    public GameRoom()
    {
    }

    public GameRoom(string name, GameType gameType)
    {
        Name = name;
        GameType = gameType;
    }

    public void AddPlayer(Player player)
    {
        if (Players.Any(p => p.Id == player.Id))
        {
            return;
        }

        if (IsFull)
        {
            throw new InvalidOperationException("Room is full.");
        }

        Players.Add(player);
    }
}